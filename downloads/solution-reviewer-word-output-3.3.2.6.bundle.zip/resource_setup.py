"""Create only marked target resources; never take over an unrelated site, list or folder."""

from urllib.parse import urlsplit
from xml.sax.saxutils import escape

from configuration import ROOT, read, require
from target_api import rows


def private_site(api, profile, personal=False):
    user = api.sp("GET", "_api/web/currentuser?$select=Id,Email,LoginName", personal=personal)
    require(user["LoginName"].lower().endswith("|membership|" + api.config["ownerUpn"].lower()),
            "SharePoint identity is not the configured owner.")
    require(user["Email"].lower() in (profile["mail"].lower(), profile["userPrincipalName"].lower()),
            "Unexpected SharePoint owner email.")
    if not personal:
        acl = rows(api.sp("GET", "_api/web/roleassignments?$select=Member/Id,RoleDefinitionBindings/Id,RoleDefinitionBindings/RoleTypeKind"
                         "&$expand=Member,RoleDefinitionBindings"))
        acl = [item for item in acl if not sole_limited_access(item)]
        require(len(acl) == 1 and acl[0]["Member"]["Id"] == user["Id"]
                and any(v["RoleTypeKind"] == 5 for v in rows(acl[0]["RoleDefinitionBindings"])),
                "Target site must already be private with direct Full Control only for the configured owner. No ACL is changed.")
        admins = rows(api.sp("GET", "_api/web/siteusers?$select=Id,Email&$filter=IsSiteAdmin eq true"))
        require(all(v["Id"] == user["Id"] for v in admins), "Unexpected explicit site collection administrator.")
    return user


def sole_limited_access(item):
    roles = rows(item.get("RoleDefinitionBindings", []))
    return (len(roles) == 1 and set(roles[0]) == {"Id", "RoleTypeKind"}
            and roles[0]["Id"] == 1073741825 and roles[0]["RoleTypeKind"] == 1)


def get_list(api, title):
    values = rows(api.sp("GET", "_api/web/lists?$select=Id,Title,Description,BaseTemplate,"
                        "HasUniqueRoleAssignments,EnableVersioning,ListItemEntityTypeFullName,RootFolder/ServerRelativeUrl"
                        "&$expand=RootFolder&$filter=Title eq '" + title + "'"))
    require(len(values) <= 1, "Ambiguous target list name.")
    return values[0] if values else None


def owned_list(api, title, template, marker):
    current = get_list(api, title)
    if current is None:
        api.sp("POST", "_api/web/lists", {"__metadata": {"type": "SP.List"}, "Title": title,
                                        "Description": marker, "BaseTemplate": template, "EnableVersioning": True})
        current = get_list(api, title)
    require(current is not None and current["Description"] == marker and current["BaseTemplate"] == template,
            "Existing unrelated or mismatched list: " + title)
    require(current["EnableVersioning"] and not current["HasUniqueRoleAssignments"],
            "Target lists must version records and inherit the verified private site.")
    return current


def field(api, list_id, name, kind="Text", choices=None, unique=False):
    base = "_api/web/lists(guid'" + list_id + "')"
    query = base + "/fields?$select=Id,InternalName,TypeAsString,Indexed,EnforceUniqueValues" \
            "&$filter=InternalName eq '" + name + "'"
    values = rows(api.sp("GET", query))
    if not values:
        attrs = 'Type="' + kind + '" Name="' + name + '" StaticName="' + name + '" DisplayName="' + name + '"'
        if kind == "Note":
            attrs += ' RichText="FALSE" NumLines="6"'
        if kind == "DateTime":
            attrs += ' Format="DateTime"'
        if unique:
            attrs += ' Indexed="TRUE" EnforceUniqueValues="TRUE"'
        body = "<CHOICES>" + "".join("<CHOICE>" + escape(v) + "</CHOICE>" for v in choices) + "</CHOICES>" if choices else ""
        api.sp("POST", base + "/fields/createfieldasxml", {"parameters": {
            "__metadata": {"type": "SP.XmlSchemaFieldCreationInformation"},
            "SchemaXml": "<Field " + attrs + ">" + body + "</Field>", "Options": 0}})
        values = rows(api.sp("GET", query))
    require(len(values) == 1 and values[0]["TypeAsString"] == kind, "Wrong field schema: " + name)
    require(not unique or (values[0]["Indexed"] and values[0]["EnforceUniqueValues"]),
            "ReviewJobs job key must be indexed and unique.")
    if choices:
        actual = api.sp("GET", base + "/fields/getbyinternalnameortitle('" + name + "')?$select=Choices")
        require(set(rows(actual["Choices"])) == set(choices), "Choice values differ: " + name)


def provision(api, state, profile, storage_only=False):
    c = api.config
    agent_id = state.get("agent", {}).get("id")
    require(storage_only or agent_id, "Import/discover the reviewer before creating its control record.")
    owner = private_site(api, profile)
    marker = "PSR portable installation " + c["installationId"]
    titles = (("libraryName", 101), ("jobsListName", 100), ("controlListName", 100))
    for key, template in titles:
        found = get_list(api, c[key])
        require(found is None or (found["Description"] == marker and found["BaseTemplate"] == template),
                "An unrelated list already has a requested name; no writes performed.")
        if key == "controlListName" and found:
            fields = rows(api.sp("GET", "_api/web/lists(guid'" + found["Id"]
                                + "')/fields?$select=InternalName&$filter=InternalName eq 'PSRMode'"))
            if fields:
                records = rows(api.sp("GET", "_api/web/lists(guid'" + found["Id"]
                                     + "')/items?$select=Title,PSRMode,PSRAllowEmail,PSROwnerObjectId,PSRAgentId"))
                require(not records or (len(records) == 1 and records[0]["Title"] == marker
                                        and records[0]["PSRMode"] == "Disabled" and records[0]["PSRAllowEmail"] is False
                                        and records[0]["PSROwnerObjectId"] == profile["id"]
                                        and records[0]["PSRAgentId"] == agent_id),
                        "Existing controls must be disabled and belong to this exact owner/agent before any resource writes.")
    library, jobs, control = [owned_list(api, c[key], kind, marker) for key, kind in titles]
    control_base = "_api/web/lists(guid'" + control["Id"] + "')/items"
    existing = rows(api.sp("GET", control_base + "?$select=Id,Title,PSRMode,PSRAllowEmail")
                    ) if state.get("bindings", {}).get("CONTROL_ID") else []
    require(not existing or (len(existing) == 1 and existing[0]["Title"] == marker
                            and existing[0]["PSRMode"] == "Disabled" and existing[0]["PSRAllowEmail"] is False),
            "Do not reprovision active or differently owned controls; pause this installation first.")
    schema = read(ROOT / "sharepoint-schema.json")
    for group, kind in (("jobTextFields", "Text"), ("jobNoteFields", "Note"),
                        ("jobNumberFields", "Number"), ("jobDateFields", "DateTime")):
        for name in schema[group]:
            field(api, jobs["Id"], name, kind, unique=name == schema["uniqueIndexedJobKey"])
    field(api, jobs["Id"], "PSRStatus", "Choice", schema["jobStatuses"])
    field(api, jobs["Id"], "PSREmailState", "Choice", schema["emailStates"])
    for group, kind in (("controlTextFields", "Text"), ("controlDateFields", "DateTime"),
                        ("controlBooleanFields", "Boolean")):
        for name in schema[group]:
            field(api, control["Id"], name, kind)
    field(api, control["Id"], "PSRMode", "Choice", schema["controlModes"])
    existing = rows(api.sp("GET", control_base + "?$select=Id,Title,PSRMode,PSRAllowEmail,PSROwnerObjectId,PSRAgentId"))
    if not existing and not storage_only:
        created = api.sp("POST", control_base, {
            "__metadata": {"type": control["ListItemEntityTypeFullName"]}, "Title": marker,
            "PSRMode": "Disabled", "PSRAllowEmail": False, "PSROwnerObjectId": profile["id"],
            "PSROwnerMail": profile["mail"], "PSRAgentId": agent_id,
            "PSRContractVersion": read(ROOT / "install-manifest.json")["controlContractVersion"],
            "PSRActivationUtc": "2099-01-01T00:00:00Z",
        })
        existing = [created]
    require((storage_only and not existing) or (len(existing) == 1 and existing[0]["Title"] == marker
            and existing[0]["PSRMode"] == "Disabled" and existing[0]["PSRAllowEmail"] is False
            and existing[0]["PSROwnerObjectId"] == profile["id"]
            and existing[0]["PSRAgentId"] == agent_id), "Target control record mismatch.")
    library_root = library["RootFolder"]["ServerRelativeUrl"]
    folders = {}
    for name in ("Incoming", "Results", "Working"):
        relative = library_root + "/" + name
        found = rows(api.sp("GET", "_api/web/GetFolderByServerRelativeUrl('" + library_root
                           + "')/Folders?$select=Name,UniqueId,ServerRelativeUrl&$filter=Name eq '" + name + "'"))
        if not found:
            api.sp("POST", "_api/web/folders", {"__metadata": {"type": "SP.Folder"}, "ServerRelativeUrl": relative})
        folder = api.sp("GET", "_api/web/GetFolderByServerRelativeUrl('" + relative + "')?$select=UniqueId,ServerRelativeUrl")
        permission = api.sp("GET", "_api/web/GetFolderByServerRelativeUrl('" + relative
                            + "')/ListItemAllFields?$select=HasUniqueRoleAssignments")
        require(folder["ServerRelativeUrl"] == relative and permission["HasUniqueRoleAssignments"] is False,
                "Target folder scope/privacy differs.")
        folders[name] = folder
    web = api.sp("GET", "_api/web?$select=Id,Url")
    site = api.sp("GET", "_api/site?$select=Id")
    require(web["Url"].rstrip("/") == c["siteUrl"], "Wrong target web.")
    state["bindings"] = {
        **state.get("bindings", {}),
        "OWNER_OID": profile["id"], "OWNER_MAIL": profile["mail"].lower(),
        "OWNER_SP_EMAIL": owner["Email"].lower(), "OWNER_SP_LOGIN": owner["LoginName"].lower(),
        "OWNER_SP_ID": str(owner["Id"]), "SITE_URL": c["siteUrl"],
        "SP_ORIGIN": "https://" + urlsplit(c["siteUrl"]).netloc, "SITE_ID": site["Id"], "WEB_ID": web["Id"],
        "LIBRARY_ID": library["Id"], "LIBRARY_REL": library_root,
        "LIBRARY_SITE_REL": library_root[len(urlsplit(c["siteUrl"]).path):],
        "JOBS_ID": jobs["Id"], "JOBS_ENTITY": jobs["ListItemEntityTypeFullName"],
        "CONTROL_ID": control["Id"], "CONTROL_ENTITY": control["ListItemEntityTypeFullName"],
        **({"CONTROL_ITEM_ID": str(existing[0]["Id"])} if existing else {}),
        **{name.upper() + "_REL": record["ServerRelativeUrl"] for name, record in folders.items()},
    }
    state["resourceMarker"] = marker
    state["storageReady"] = True
    return state


def inbox(api, state, profile, create=True):
    c = api.config
    state["ownerInboxVerified"] = False
    state.pop("ownerInboxUrl", None)
    state.pop("ownerDrive", None)
    proof = api.own_default_drive(profile)
    require(isinstance(proof, dict) and proof.get("ownerObjectId", "").lower() == profile["id"].lower(),
            "An authoritative own/default-drive proof is required before Inbox access.")
    own_item = api.own_inbox_item(proof)
    owner = private_site(api, profile, personal=True)
    root = proof["rootRelativeUrl"]
    relative = root + "/" + c["manualInboxName"]
    found = rows(api.sp("GET", "_api/web/GetFolderByServerRelativeUrl('" + root
                       + "')/Folders?$select=Name,UniqueId&$filter=Name eq '" + c["manualInboxName"] + "'", personal=True))
    folder_api = "_api/web/GetFolderByServerRelativeUrl('" + relative + "')"
    marker_name = "PSR-" + c["installationId"] + ".txt"
    require(bool(found) == (own_item is not None), "Graph default-drive and SharePoint Inbox existence disagree.")
    if not found:
        require(create, "The verified owner-drive Inbox is absent; run explicit setup, not a verification fallback.")
        api.sp("POST", "_api/web/folders", {"__metadata": {"type": "SP.Folder"},
                                          "ServerRelativeUrl": relative}, personal=True)
        own_item = api.own_inbox_item(proof)
        require(own_item is not None, "New folder's default-drive identity is not yet verifiable; no ACL/marker writes.")
        created = api.sp("GET", folder_api + "?$select=UniqueId", personal=True)
        require(created["UniqueId"].lower() == own_item["sharepointIds"]["listItemUniqueId"].lower(),
                "Created SharePoint folder differs from the authenticated default-drive item.")
        api.sp("POST", folder_api + "/ListItemAllFields/breakroleinheritance(copyRoleAssignments=false,clearSubscopes=true)",
               personal=True)
        api.sp("POST", folder_api + "/Files/add(url='" + marker_name + "',overwrite=false)",
               "PSR portable installation " + c["installationId"], headers={"Content-Type": "text/plain"}, personal=True)
    else:
        require(len(found) == 1 and found[0]["UniqueId"].lower() == own_item["sharepointIds"]["listItemUniqueId"].lower(),
                "SharePoint folder and authenticated default-drive item identities differ.")
    marker = rows(api.sp("GET", folder_api + "/Files?$select=Name&$filter=Name eq '" + marker_name + "'", personal=True))
    require(len(marker) == 1, "Existing Inbox is not owned by this installation; nothing was overwritten.")
    acl = api.sp("GET", folder_api + "/ListItemAllFields?$select=HasUniqueRoleAssignments,"
                 "RoleAssignments/Member/Id,RoleAssignments/RoleDefinitionBindings/RoleTypeKind"
                 "&$expand=RoleAssignments/Member,RoleAssignments/RoleDefinitionBindings", personal=True)
    assignments = rows(acl["RoleAssignments"])
    require(acl["HasUniqueRoleAssignments"] is True and len(assignments) == 1
            and assignments[0]["Member"]["Id"] == owner["Id"]
            and any(v["RoleTypeKind"] == 5 for v in rows(assignments[0]["RoleDefinitionBindings"])),
            "The configured Inbox is not private to its owner.")
    state["ownerInboxVerified"] = True
    state["ownerDrive"] = {**proof, "inboxItemId": own_item["id"],
                          "manualInvokerPath": "/" + c["manualInboxName"]}
    state["ownerInboxUrl"] = own_item["webUrl"]
    return state
