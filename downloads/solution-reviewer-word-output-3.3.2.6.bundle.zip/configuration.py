"""Strict portable configuration and token binding; no network operations."""

import hashlib
import json
from pathlib import Path
import re
import shutil
from urllib.parse import urlsplit
from uuid import UUID


APIS = ("shared_sharepointonline", "shared_onedriveforbusiness", "shared_office365users",
        "shared_microsoftcopilotstudio", "shared_office365", "shared_wordonlinebusiness")
TOKEN = re.compile(r"__PSR_([A-Z0-9_]+?)__")
ROOT = Path(__file__).resolve().parent


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=True,
                                     separators=(", ", ": ")).encode()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def write(path, value):
    path = Path(path)
    pending = path.with_name(path.name + ".pending")
    pending.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    pending.replace(path)


def require(test, message):
    if not test:
        raise ValueError(message)


def uuid_text(value):
    result = str(UUID(value))
    require(result != str(UUID(int=0)), "A zero GUID is not a configured target.")
    return result


def validate(config, manifest=None):
    manifest = manifest or read(ROOT / "install-manifest.json")
    required = set(read(ROOT / "target.example.json"))
    require(set(config) == required, "Configuration keys differ from target.example.json.")
    require(not re.search(r"__TARGET_[A-Z0-9_]+__", json.dumps(config)),
            "Replace every nonworking __TARGET_*__ placeholder before target preparation.")
    for name in ("installationId", "tenantId", "environmentId"):
        require(isinstance(config[name], str), name + " must be a GUID string.")
        require(uuid_text(config[name]) == config[name].lower(), name + " must be a complete GUID.")
    require(isinstance(config["agentAccessGroupId"], str), "agentAccessGroupId must be a string.")
    if config["agentAccessGroupId"]:
        require(uuid_text(config["agentAccessGroupId"]) == config["agentAccessGroupId"].lower(),
                "Use an actual target-approved agent access group GUID, or leave blank for no group assignment.")
    require(hashlib.sha256(config["environmentId"].lower().encode()).hexdigest()
            != manifest["sourceEnvironmentIdSha256"], "Refusing the protected source environment.")
    patterns = {
        "dataverseUrl": r"https://[a-z0-9-]+\.crm[0-9]*\.dynamics\.com",
        "siteUrl": r"https://[a-z0-9-]+\.sharepoint\.com/(?:sites|teams)/[A-Za-z0-9_-]+",
        "ownerOneDriveSiteUrl": r"https://[a-z0-9-]+-my\.sharepoint\.com/personal/[A-Za-z0-9_-]+",
        "ownerUpn": r"[A-Za-z0-9._+%-]+@[A-Za-z0-9.-]+",
    }
    for name, pattern in patterns.items():
        require(isinstance(config[name], str) and re.fullmatch(pattern, config[name]) is not None,
                "Missing or unsupported target " + name + ". Commercial-cloud HTTPS and safe ASCII names are required.")
    for name in ("libraryName", "jobsListName", "controlListName", "manualInboxName"):
        require(re.fullmatch(r"[A-Za-z][A-Za-z0-9]{2,39}", config[name] or "") is not None,
                name + " must be an explicit safe 3–40 character resource name.")
    require(len({config[k] for k in ("libraryName", "jobsListName", "controlListName")}) == 3,
            "Library, jobs and control names must be distinct.")
    require(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{1,120}\.docx", config["wordTemplateName"] or "") is not None,
            "wordTemplateName must be the explicit safe filename uploaded to the owner's default drive root.")
    require(set(config["connections"]) == set(APIS), "All six target connector instances are required.")
    for value in config["connections"].values():
        require(isinstance(value, str) and re.fullmatch(r"[A-Za-z0-9_-]{5,200}", value) is not None,
                "Every target connection ID must be explicitly configured.")
    model = config["model"]
    require(set(model) == {"modelNameHint", "availabilityVerifiedInTarget"}, "Unexpected model fields.")
    require(model["availabilityVerifiedInTarget"] is True, "Verify model availability/licensing/DLP in the target first.")
    require(re.fullmatch(r"[A-Za-z0-9._-]{1,80}", model["modelNameHint"] or "") is not None,
            "An actual supported target model identifier is required.")
    for name in ("pacPath", "azureCliPath"):
        require(isinstance(config[name], str) and config[name].strip(), name + " is required.")
    return config


def target_key(config):
    return digest({k: config[k] for k in config if k not in ("pacPath", "azureCliPath")})


def state_for(config, path, create=False):
    if Path(path).exists():
        value = read(path)
        require(value["targetKey"] == target_key(config), "State belongs to another target/configuration.")
        return value
    require(create, "Missing installation state; perform target preflight first.")
    return {"targetKey": target_key(config), "installationId": config["installationId"],
            "tenantId": config["tenantId"], "environmentId": config["environmentId"]}


def safe_work(path):
    path = Path(path)
    require(not path.is_absolute() and ".." not in path.parts and str(path) not in ("", "."),
            "Work directory must be an explicit project-relative descendant, not a temporary/global directory.")
    path.mkdir(parents=True, exist_ok=True)
    return path.resolve()


def bind_tree(value, values):
    if isinstance(value, dict):
        result = {}
        for key, item in value.items():
            bound = bind_tree(key, values)
            require(bound not in result, "Target binding would duplicate an object property.")
            result[bound] = bind_tree(item, values)
        return result
    if isinstance(value, list):
        return [bind_tree(item, values) for item in value]
    if not isinstance(value, str):
        return value
    def replace(match):
        require(match[1] in values, "Unresolved required binding: " + match[1])
        result = str(values[match[1]])
        require(not any(char in result for char in "'\"<>\r\n"), "Unsafe literal in " + match[1])
        return result
    return TOKEN.sub(replace, value)


def flatten(actions):
    result = {}
    for name, action in actions.items():
        require(name not in result, "Duplicate workflow action.")
        result[name] = action
        result.update(flatten(action.get("actions", {})))
        result.update(flatten(action.get("else", {}).get("actions", {})))
    return result


def kernel_of(definition, selector):
    actions = flatten(definition["actions"])
    result = {
        "preparationActions": {name: actions[name] for name in selector["preparation"]},
        "firstEligibility": actions["FirstComponentIfPrepared"]["expression"],
        "repairEligibility": actions["RepairComponentIfNeeded"]["expression"],
        "passIdInput": actions["ComponentPassId"]["inputs"], "phases": {},
    }
    for phase, record in selector["phases"].items():
        actual = actions[record["recordAction"]]["inputs"]["value"]
        result["phases"][phase] = {
            "nativeActions": {name: actions[name] for name in record["actions"]},
            "accountingProjection": {key: actual[key] for key in record["accountingKeys"]},
        }
    if "secondAttemptReasonAction" in selector:
        result["secondAttemptReasonAction"] = actions[selector["secondAttemptReasonAction"]]
    if "messageActions" in selector:
        result["messageActions"] = {name: actions[name] for name in selector["messageActions"]}
    return result


def fixed_values(config, state):
    values = {
        "ENVIRONMENT_ID": config["environmentId"], "TENANT_ID": config["tenantId"],
        "DATAVERSE_URL": config["dataverseUrl"],
        "MODEL_NAME": config["model"]["modelNameHint"], "MANUAL_INBOX_NAME": config["manualInboxName"],
        "MANUAL_INBOX_ROOT": "/" + config["manualInboxName"], "OWNER_UPN": config["ownerUpn"].lower(),
        "INSTALLATION_ID": config["installationId"], "LIBRARY_NAME": config["libraryName"],
    }
    values.update(state.get("bindings", {}))
    if state.get("agent"):
        values.update(AGENT_ID=state["agent"]["id"], AGENT_PICKER=state["agent"].get("picker", ""),
                      AGENT_PUBLISHED_UTC=state["agent"].get("publishedOn") or "")
    return values


def cli(config, key):
    value = shutil.which(config[key])
    if value:
        return value
    require(Path(config[key]).is_file(), "Required CLI is unavailable: " + config[key])
    return str(Path(config[key]).resolve())
