"""Verify an owner-uploaded exact template and bind the actual target Word schema."""

import base64
import hashlib
import json
import re
from urllib.parse import quote, urlencode

from configuration import ROOT, digest, require


TEMPLATE = "current-review-v4.3.1.web.template.docx"
TEMPLATE_SHA256 = "498ee9eb6d1fbd9df4fa719a873fa57237fdbf224fcb6c62c77c96881bac3065"
ROOTS = {"ReviewIdentity": "WORD_KEY_IDENTITY", "ReviewBlocks": "WORD_KEY_BLOCKS",
         "NativeRunStamp": "WORD_KEY_STAMP", "PresentationNotes": "WORD_KEY_NOTES"}
CHILDREN = {"BlockHeading", "LeadText", "BodyText", "NestedText", "CodeText"}


def schema_keys(schema):
    require(isinstance(schema, dict) and schema.get("type") == "array",
            "GetFileSchema did not return the supported native root array schema.")
    item = schema.get("items", {})
    properties = item.get("properties", {})
    require(item.get("type") == "object" and len(properties) == len(ROOTS),
            "The target template must expose exactly four supported root controls.")
    result = {}
    for key, field in properties.items():
        title = field.get("x-ms-summary")
        require(title in ROOTS and title not in result and re.fullmatch(r"[A-Za-z0-9_-]{1,80}", key),
                "Unexpected, duplicate or unsafe target Word root control.")
        if title == "ReviewBlocks":
            children = field.get("items", {})
            require(field.get("type") == "array" and children.get("type") == "object"
                    and set(children.get("properties", {})) == CHILDREN
                    and all(v.get("type") == "string" and v.get("x-ms-summary") == name
                            for name, v in children["properties"].items()),
                    "Word repeat children differ from the supported five literal string controls.")
        else:
            require(field.get("type") == "string", "Word root control must be plain text.")
        result[title] = key
    require(set(result) == set(ROOTS), "Missing required target Word root title.")
    return result


def verify_template(api, state):
    local = ROOT / TEMPLATE
    require(hashlib.sha256(local.read_bytes()).hexdigest() == TEMPLATE_SHA256,
            "The bundled generic Word template changed; do not upload or bind it.")
    proof = api.own_default_drive(state["owner"])
    name = api.config["wordTemplateName"]
    url = "https://graph.microsoft.com/v1.0/me/drive/root:/" + quote(name, safe="") \
          + "?$select=id,name,eTag,size,file,folder,remoteItem,parentReference"
    item = api.request("GET", url, "https://graph.microsoft.com")
    require(item.get("name") == name and item.get("file") is not None
            and "folder" not in item and "remoteItem" not in item
            and item.get("parentReference", {}).get("driveId") == proof["driveId"]
            and item["parentReference"].get("id") == proof["rootItemId"],
            "Upload the exact template as a physical file in the verified owner's default drive root; no shortcuts.")
    drive, file_id = proof["driveId"], item["id"]
    connection = api.config["connections"]["shared_onedriveforbusiness"]
    route = api.runtime("shared_onedriveforbusiness") + "/" + quote(connection, safe="") \
            + "/datasets/default/files/" + quote(quote(drive + "." + file_id, safe=""), safe="")
    content = api.request("GET", route + "/content", "https://apihub.azure.com", binary=True)
    require(isinstance(content, bytes), "Template readback did not return bytes.")
    if not content.startswith(b"PK"):
        envelope = json.loads(content)
        require(isinstance(envelope, dict) and isinstance(envelope.get("$content"), str),
                "Unsupported native binary content envelope.")
        content = base64.b64decode(envelope["$content"], validate=True)
    require(len(content) == item["size"] and hashlib.sha256(content).hexdigest() == TEMPLATE_SHA256,
            "Existing target filename is not the exact approved generic template; nothing was overwritten.")
    word_connection = api.config["connections"]["shared_wordonlinebusiness"]
    schema_url = api.runtime("shared_wordonlinebusiness") + "/" + quote(word_connection, safe="") \
                 + "/api/templates/schema?" + urlencode({"source": "me", "drive": drive, "file": file_id})
    schema = api.request("GET", schema_url, "https://apihub.azure.com")
    keys = schema_keys(schema)
    after = api.request("GET", url, "https://graph.microsoft.com")
    require(item.get("eTag") and all(after.get(key) == item.get(key)
                                    for key in ("id", "name", "eTag", "size", "parentReference")),
            "Target template metadata changed during schema verification.")
    state.setdefault("bindings", {}).update({
        "WORD_SOURCE": "me", "WORD_DRIVE": drive, "WORD_FILE": file_id, "WORD_TEMPLATE_NAME": name,
        **{ROOTS[title]: key for title, key in keys.items()},
    })
    state["wordTemplate"] = {"sha256": TEMPLATE_SHA256, "driveId": drive, "fileId": file_id,
                             "etag": item["eTag"], "schemaSha256": digest(schema), "rootKeys": keys}
    return state["wordTemplate"]
