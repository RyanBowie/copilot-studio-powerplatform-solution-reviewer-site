"""Prepare and configure a portable target installation. Never imports, publishes, uploads or sends."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
from urllib.parse import quote, urlencode
from xml.etree import ElementTree as ET

import yaml

from configuration import (
    ROOT, TOKEN, bind_tree, cli, digest, fixed_values, flatten, kernel_of, read, require,
    safe_work, state_for, uuid_text, validate, write,
)
from resource_setup import inbox, private_site, provision
from target_api import TargetApi, TargetApiError, rows
from word_setup import verify_template


def package(manifest, kind):
    if kind == "word":
        reviewer = package(manifest, "reviewer")
        return {**reviewer, **next(item for item in reviewer["workflows"] if item["kind"] == "word")}
    return next(item for item in manifest["packages"] if item["kind"] == kind)


def marker(config):
    return "PSR portable installation " + config["installationId"]


def solution(api, spec, required=False):
    values = api.dv("GET", "solutions?" + urlencode({
        "$select": "solutionid,uniquename,description,ismanaged",
        "$filter": "uniquename eq '" + spec["solutionName"] + "'"}))["value"]
    require(len(values) <= 1, "Ambiguous target solution.")
    if values:
        require(values[0]["description"] == marker(api.config) and values[0]["ismanaged"] is False,
                "Existing solution is not this target installation; refusing overwrite.")
        return values[0]
    require(not required, "Import the configured " + spec["kind"] + " solution first.")
    return None


def members(api, solution_id):
    return {(row["componenttype"], row["objectid"].lower()) for row in api.dv(
        "GET", "solutioncomponents?" + urlencode({
            "$select": "componenttype,objectid", "$filter": "_solutionid_value eq " + solution_id}))["value"]}


def collision_check(api, spec, state=None, manifest=None):
    existing = solution(api, spec)
    if existing:
        return
    for item in spec.get("workflows", [spec]):
        workflow = api.dv("GET", "workflows?" + urlencode({
            "$select": "workflowid", "$filter": "workflowid eq " + item["workflowId"]}))["value"]
        require(not workflow, "An unrelated target workflow already has the package component ID.")
    settings = read(ROOT / spec["settings"])
    for ref in settings["ConnectionReferences"]:
        found = api.dv("GET", "connectionreferences?" + urlencode({
            "$select": "connectionreferenceid,connectionid,connectorid",
            "$filter": "connectionreferencelogicalname eq '" + ref["LogicalName"] + "'"}))["value"]
        if found:
            require(spec["kind"] == "automation" and state is not None and manifest is not None
                    and state.get("prepared", {}).get("reviewer"),
                    "An unrelated target connection reference already uses " + ref["LogicalName"])
            reviewer = package(manifest, "reviewer")
            allowed = {v["LogicalName"] for v in read(ROOT / reviewer["settings"])["ConnectionReferences"]}
            owned = solution(api, reviewer, required=True)
            connector = ref["ConnectorId"].rsplit("/", 1)[-1]
            require(ref["LogicalName"] in allowed and len(found) == 1
                    and (10165, found[0]["connectionreferenceid"].lower()) in members(api, owned["solutionid"])
                    and (found[0].get("connectorid") or "").rsplit("/", 1)[-1] == connector
                    and (found[0].get("connectionid") or "").rsplit("/", 1)[-1] == api.config["connections"][connector],
                    "Shared reference is not the verified reviewer dependency of this exact installation.")


def discover(api, state, manifest, configure=False):
    spec = package(manifest, "reviewer")
    installed = solution(api, spec, required=True)
    values = api.dv("GET", "bots?" + urlencode({
        "$select": "botid,schemaname,publishedon,authenticationmode,authenticationtrigger,accesscontrolpolicy,configuration,synchronizationstatus",
        "$filter": "schemaname eq '" + manifest["agentSchema"] + "'"}))["value"]
    require(len(values) == 1, "Actual imported agent could not be uniquely resolved.")
    bot = values[0]
    owned = members(api, installed["solutionid"])
    require((10227, bot["botid"].lower()) in owned
            and all((29, item["workflowId"]) in owned for item in spec["workflows"]),
            "Agent/native tool are not members of this imported reviewer solution.")
    auth = (bot["authenticationmode"], bot["authenticationtrigger"], bot["accesscontrolpolicy"])
    if configure and auth != (2, 1, 2):
        api.dv("PATCH", "bots(" + bot["botid"] + ")", {
            "authenticationmode": 2, "authenticationtrigger": 1, "accesscontrolpolicy": 2}, bot["@odata.etag"])
        bot = api.dv("GET", "bots(" + bot["botid"] + ")")
    require((bot["authenticationmode"], bot["authenticationtrigger"], bot["accesscontrolpolicy"]) == (2, 1, 2),
            "Run configure-agent before publishing: authenticated Integrated/Always/GroupMembership is required.")
    config = json.loads(bot["configuration"])
    require(config["publishOnImport"] is False
            and config["recognizer"]["$kind"] == "GenerativeAIRecognizer"
            and config["settings"]["GenerativeActionsEnabled"] is True,
            "Unexpected target harness/orchestration or auto-publication.")
    gpt = api.dv("GET", "botcomponents?" + urlencode({
        "$select": "botcomponentid,data", "$filter": "_parentbotid_value eq " + bot["botid"] + " and componenttype eq 15"}))["value"]
    require(len(gpt) == 1, "Expected one imported GPT component.")
    model = yaml.safe_load(gpt[0]["data"])["aISettings"]["model"]
    require(model == {"modelNameHint": api.config["model"]["modelNameHint"]},
            "Imported model differs from the explicitly verified target selection.")
    state["agent"] = {"id": bot["botid"], "schema": bot["schemaname"], "publishedOn": bot.get("publishedon"),
                      "solutionId": installed["solutionid"], "model": model}
    return bot


def actual_picker(api, bot):
    require(bot.get("publishedon"), "Publish the actual target agent before preparing automation.")
    sync = json.loads(bot["synchronizationstatus"])
    require(sync["currentSynchronizationState"]["state"] == "Synchronized"
            and sync["lastFinishedPublishOperation"]["status"] == "Succeeded", "Target publication is not synchronized.")
    connection = api.config["connections"]["shared_microsoftcopilotstudio"]
    url = api.runtime("shared_microsoftcopilotstudio") + "/" + quote(connection, safe="") \
          + "/powervirtualagents/dataverse-backed/copilots"
    response = api.request("GET", url, "https://apihub.azure.com")
    if isinstance(response, dict) and "body" in response:
        response = response["body"]
    if isinstance(response, str):
        response = json.loads(response)
    entries = [{str(k).lower(): v for k, v in item.items()} for item in response.get("copilotsList", [])]
    matching = [item for item in entries if str(item.get("id", "")).lower() == bot["botid"].lower()
                and item.get("schemaname") == bot["schemaname"]]
    require(len(matching) == 1, "The authenticated target connector does not expose the actual imported published agent.")
    return matching[0]["schemaname"]


def prepare(config, state, manifest, kind, work, api):
    spec = package(manifest, kind)
    collision_check(api, spec, state, manifest)
    verify_template(api, state)
    if kind == "reviewer":
        require(state.get("storageReady"), "Run setup-storage before preparing the reviewer Word helper.")
        bots = api.dv("GET", "bots?" + urlencode({
            "$select": "botid", "$filter": "schemaname eq '" + manifest["agentSchema"] + "'"}))["value"]
        require(not bots or solution(api, spec) is not None, "Unrelated agent schema collision.")
    else:
        bot = discover(api, state, manifest)
        require(state.get("bindings") and state.get("ownerInboxVerified"),
                "Provision target resources and verify the owner's Inbox before preparing automation.")
        state["agent"]["picker"] = actual_picker(api, bot)
        verify_resources(api, state)
    values = fixed_values(config, state)
    require(all(key in values and str(values[key]) for key in spec["requiredTokens"]),
            "A required discovered target binding is missing.")
    source = ROOT / spec["file"]
    require(hashlib.sha256(source.read_bytes()).hexdigest() == spec["sha256"], "Portable template hash differs.")
    folder = work / (kind + "-source")
    require(not folder.exists(), "Prepared source folder already exists; choose a fresh work directory.")
    require(os.name != "nt" or max(len(str(folder / item["file"])) for item in spec["sourceFiles"]) < 260,
            "Native PAC output path is too long. Use a shorter project/work directory; metadata must not be dropped.")
    subprocess.run([cli(config, "pacPath"), "solution", "unpack", "--zipfile", str(source),
                    "--folder", str(folder), "--packagetype", "Unmanaged", "--errorlevel", "Warning"], check=True)
    files = {str(file.relative_to(folder)): file for file in folder.rglob("*") if file.is_file()}
    require(set(files) == {item["file"] for item in spec["sourceFiles"]}, "Unexpected package dependency/file set.")
    for item in spec["sourceFiles"]:
        file = files[item["file"]]
        text = file.read_text(encoding="utf-8-sig")
        require(set(TOKEN.findall(text)) == set(item["tokens"]), "Unexpected binding placeholders in " + item["file"])
        result = bind_tree(text, values)
        require(not TOKEN.search(result), "Unresolved target binding.")
        file.write_text(result, encoding="utf-8")
    definition = read(folder / spec["workflowFile"])["properties"]["definition"]
    if kind == "automation":
        require(digest(kernel_of(definition, read(ROOT / manifest["kernelSelector"]))) == manifest["kernelSha256"],
                "Target binding changed the accepted admission kernel.")
        require(definition["parameters"][manifest["activationParameter"]]["defaultValue"] is False,
                "Automation must remain activation-latched off in the prepared package.")
    for item in spec["workflows"]:
        metadata = ET.parse(str(folder / item["workflowFile"]) + ".data.xml").getroot()
        require(metadata.findtext("StateCode") == "0" and metadata.findtext("StatusCode") == "1",
                "Every target workflow package must remain disabled.")
    archive = work / (spec["solutionName"] + ".target.zip")
    subprocess.run([cli(config, "pacPath"), "solution", "pack", "--zipfile", str(archive),
                    "--folder", str(folder), "--packagetype", "Unmanaged", "--errorlevel", "Warning"], check=True)
    settings = read(ROOT / spec["settings"])
    for ref in settings["ConnectionReferences"]:
        connector = ref["ConnectorId"].rsplit("/", 1)[-1]
        ref["ConnectionId"] = config["connections"][connector]
    if kind == "reviewer" and config["agentAccessGroupId"]:
        settings["CopilotAgents"] = [{"Name": manifest["agentSchema"], "AadGroupId": config["agentAccessGroupId"]}]
    else:
        settings.pop("CopilotAgents", None)
    settings_path = work / (kind + ".settings.json")
    write(settings_path, settings)
    definition_path = work / (kind + ".definition.json")
    write(definition_path, definition)
    state.setdefault("prepared", {})[kind] = {
        "archive": str(archive), "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
        "settings": str(settings_path), "definition": str(definition_path), "definitionSha256": digest(definition)}
    if kind == "reviewer":
        word = package(manifest, "word")
        word_definition = read(folder / word["workflowFile"])["properties"]["definition"]
        word_path = work / "word.definition.json"
        write(word_path, word_definition)
        state["prepared"]["word"] = {**state["prepared"][kind], "definition": str(word_path),
                                     "definitionSha256": digest(word_definition)}
    return {"archive": str(archive), "settings": str(settings_path),
            "importCommand": [config["pacPath"], "solution", "import", "--environment", config["dataverseUrl"],
                              "--path", str(archive), "--settings-file", str(settings_path)],
            "importsPerformedByHelper": 0, "activation": "Do not add --activate-plugins or --publish-changes."}


def workflow(api, state, manifest, kind):
    spec = package(manifest, kind)
    installed = solution(api, spec, required=True)
    require((29, spec["workflowId"]) in members(api, installed["solutionid"]), "Target workflow is not owned by this installation.")
    record = api.dv("GET", "workflows(" + spec["workflowId"] + ")")
    require(record["modernflowtype"] == (0 if kind == "automation" else 1), "Unexpected native flow type.")
    data = json.loads(record["clientdata"])
    expected = read(state["prepared"][kind]["definition"])
    if kind == "automation" and state.get("activationLatchEnabled"):
        expected["parameters"][manifest["activationParameter"]]["defaultValue"] = True
    elif kind == "automation" and state.get("pendingActivationLatch"):
        activated = json.loads(json.dumps(expected))
        activated["parameters"][manifest["activationParameter"]]["defaultValue"] = True
        if data["properties"]["definition"] == activated:
            require(record["statecode"] == 0, "A pending activation mutation must still be stopped before recovery.")
            expected = activated
            state["activationLatchEnabled"] = True
            state.pop("pendingActivationLatch")
    require(data["properties"]["definition"] == expected, "Imported flow definition changed; refusing mutation.")
    mode = "invoker" if kind == "reviewer" else "embedded"
    require({v["runtimeSource"].lower() for v in data["properties"]["connectionReferences"].values()} == {mode},
            "Invoker/automation identity boundary differs.")
    for ref in read(ROOT / spec["settings"])["ConnectionReferences"]:
        found = api.dv("GET", "connectionreferences?" + urlencode({
            "$select": "connectionreferenceid,connectionid,connectorid",
            "$filter": "connectionreferencelogicalname eq '" + ref["LogicalName"] + "'"}))["value"]
        connector = ref["ConnectorId"].rsplit("/", 1)[-1]
        require(len(found) == 1
                and (10165, found[0]["connectionreferenceid"].lower()) in members(api, installed["solutionid"])
                and (found[0].get("connectionid") or "").rsplit("/", 1)[-1] == api.config["connections"][connector]
                and (found[0].get("connectorid") or "").rsplit("/", 1)[-1] == connector,
                "Imported connection reference differs from the preflight-verified target owner binding.")
    return record, data


def verify_resources(api, state):
    profile = state["owner"]
    inbox(api, state, profile, create=False)
    owner = private_site(api, profile)
    b = state["bindings"]
    require(str(owner["Id"]) == b["OWNER_SP_ID"], "Owner principal changed.")
    for key in ("LIBRARY_ID", "JOBS_ID", "CONTROL_ID"):
        item = api.sp("GET", "_api/web/lists(guid'" + b[key] + "')?$select=Description,HasUniqueRoleAssignments,EnableVersioning")
        require(item["Description"] == marker(api.config) and not item["HasUniqueRoleAssignments"] and item["EnableVersioning"],
                "Target resource ownership/privacy changed.")
    unique = api.sp("GET", "_api/web/lists(guid'" + b["JOBS_ID"] + "')/fields/getbyinternalnameortitle('PSRJobKey')"
                    "?$select=Indexed,EnforceUniqueValues")
    require(unique["Indexed"] and unique["EnforceUniqueValues"], "Unique job key is not enforced.")
    control = api.sp("GET", control_uri(state))
    require(control["PSROwnerObjectId"] == state["owner"]["id"]
            and control["PSROwnerMail"].lower() == state["owner"]["mail"].lower()
            and control["PSRAgentId"] == state["agent"]["id"] and control["Title"] == marker(api.config),
            "Target control identity differs.")
    return control


def control_uri(state):
    b = state["bindings"]
    return "_api/web/lists(guid'" + b["CONTROL_ID"] + "')/items(" + b["CONTROL_ITEM_ID"] + ")"


def set_control(api, state, changes):
    verify_resources(api, state)
    api.sp("POST", control_uri(state), {"__metadata": {"type": state["bindings"]["CONTROL_ENTITY"]}, **changes},
           headers={"X-HTTP-Method": "MERGE", "IF-MATCH": "*"})
    actual = api.sp("GET", control_uri(state))
    def same(key, value):
        returned = actual.get(key)
        if key.endswith("Utc") and value and returned:
            return datetime.fromisoformat(returned.replace("Z", "+00:00")) == datetime.fromisoformat(value.replace("Z", "+00:00"))
        return returned == value
    require(all(same(key, value) for key, value in changes.items()), "Control read-back mismatch.")


def no_active_runs(api, workflow_id):
    page = api.flow("GET", "flows/" + workflow_id + "/runs?api-version=2016-11-01&$top=100")
    require(isinstance(page.get("value"), list), "Missing typed target run history; refusing mutation.")
    require(not (page.get("nextLink") or page.get("@odata.nextLink")),
            "Run history is paginated; verify no active runs before changing this installation.")
    terminal = {"Succeeded", "Failed", "Cancelled", "Canceled", "TimedOut", "Skipped", "Aborted"}
    require(all(v.get("properties", {}).get("status") in terminal for v in page.get("value", [])),
            "An active target run prevents mutation.")


def patch_workflow(api, record, changes):
    route = "workflows(" + record["workflowid"] + ")"
    try:
        api.dv("PATCH", route, changes, record["@odata.etag"])
    except TargetApiError as error:
        if error.status != 412:
            raise
        current = api.dv("GET", route)
        require(current["statecode"] == record["statecode"]
                and json.loads(current["clientdata"]) == json.loads(record["clientdata"]),
                "The owned target flow changed during update; refusing an ETag retry.")
        api.dv("PATCH", route, changes, current["@odata.etag"])
    actual = api.dv("GET", route)
    for key, value in changes.items():
        require((json.loads(actual[key]) == json.loads(value)) if key == "clientdata" else actual[key] == value,
                "Saved target flow read-back differs: " + key)
    return actual


def verify_flow_state(api, workflow_id, expected):
    properties = api.flow("GET", "flows/" + workflow_id + "?api-version=2016-11-01")["properties"]
    require(properties["state"] == expected, "Flow management state differs from the requested target state.")
    return properties


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("plan", "preflight", "setup-storage", "verify-word-template", "prepare-reviewer", "configure-agent",
        "setup", "enable-manual", "prepare-automation", "verify", "arm-test", "approve-source",
        "inspect-incoming", "approve-email-source", "accept-test", "activate", "pause"))
    parser.add_argument("--config", required=True)
    parser.add_argument("--state", default="psr-target-state.json")
    parser.add_argument("--work", default="psr-target-build")
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--confirm-environment")
    parser.add_argument("--source-id")
    parser.add_argument("--version")
    parser.add_argument("--job-id")
    args = parser.parse_args()
    manifest = read(ROOT / "install-manifest.json")
    config = validate(read(args.config), manifest)
    if args.command == "plan":
        print(json.dumps({"targetEnvironment": config["environmentId"], "targetSite": config["siteUrl"],
                          "importsOrWrites": 0, "defaults": "Disabled; no email; explicit owner test then activation."}, indent=2))
        return
    mutating = args.command in ("configure-agent", "setup-storage", "setup", "enable-manual", "arm-test", "approve-source",
                                "approve-email-source", "activate", "pause")
    require(not mutating or (args.apply and args.confirm_environment == config["environmentId"]),
            "Target writes require --apply and exact --confirm-environment.")
    state = state_for(config, args.state, create=args.command == "preflight")
    api = TargetApi(config)
    state["owner"] = api.preflight()
    result = {"command": args.command, "targetEnvironment": config["environmentId"]}
    if args.command.startswith("prepare-"):
        result.update(prepare(config, state, manifest, args.command.split("-", 1)[1], safe_work(args.work), api))
    elif args.command == "setup-storage":
        require(not solution(api, package(manifest, "reviewer"))
                and not solution(api, package(manifest, "automation")),
                "Bootstrap storage is only for a new installation; use setup for an imported owned installation.")
        provision(api, state, state["owner"], storage_only=True)
        inbox(api, state, state["owner"])
    elif args.command == "verify-word-template":
        result["wordTemplate"] = verify_template(api, state)
    elif args.command == "configure-agent":
        discover(api, state, manifest, configure=True)
    elif args.command == "setup":
        discover(api, state, manifest)
        if solution(api, package(manifest, "automation")):
            require(state.get("prepared", {}).get("automation"),
                    "Existing owned automation requires its saved installation state before resource setup.")
            current, _ = workflow(api, state, manifest, "automation")
            require(current["statecode"] == 0, "Pause the owned automation before resource setup.")
            no_active_runs(api, current["workflowid"])
        provision(api, state, state["owner"])
        inbox(api, state, state["owner"])
    elif args.command == "enable-manual":
        discover(api, state, manifest)
        require(state.get("ownerInboxVerified"), "Verify the owner Inbox first.")
        verify_resources(api, state)
        verify_template(api, state)
        checked = [(mode, workflow(api, state, manifest, kind)[0])
                   for kind, mode in (("reviewer", "Invoker"), ("word", "Embedded"))]
        for _, record in checked:
            no_active_runs(api, record["workflowid"])
        for mode, record in checked:
            if record["statecode"] != 1:
                record = patch_workflow(api, record, {"statecode": 1, "statuscode": 2})
            properties = verify_flow_state(api, record["workflowid"], "Started")
            require({r["source"] for r in properties["connectionReferences"].values()} == {mode},
                    "Manual source/output connection identity boundary differs.")
    elif args.command in ("verify", "inspect-incoming", "arm-test", "approve-source", "approve-email-source", "accept-test", "activate", "pause"):
        bot = discover(api, state, manifest)
        state["agent"]["picker"] = actual_picker(api, bot)
        control = verify_resources(api, state)
        if args.command != "pause":
            verify_template(api, state)
        record, data = workflow(api, state, manifest, "automation")
        if mutating:
            no_active_runs(api, record["workflowid"])
        if args.command == "inspect-incoming":
            source_files = api.sp("GET", "_api/web/GetFolderByServerRelativeUrl('" + state["bindings"]["INCOMING_REL"]
                                  + "')/Files?$select=Name,UniqueId,UIVersionLabel&$top=50")
            result["incomingFilesFirst50"] = rows(source_files)
        elif args.command == "arm-test":
            set_control(api, state, {"PSRMode": "SyntheticValidation", "PSRAllowEmail": False,
                "PSRActivationUtc": datetime.now(timezone.utc).isoformat(),
                "PSRAllowedSourceUniqueId": None, "PSRAllowedSourceVersion": None})
            if not state.get("activationLatchEnabled"):
                require(record["statecode"] == 0, "Activation latch can only be configured on the owned stopped flow.")
                data["properties"]["definition"]["parameters"][manifest["activationParameter"]]["defaultValue"] = True
                state["pendingActivationLatch"] = True
                write(args.state, state)
                record = patch_workflow(api, record, {"clientdata": json.dumps(data)})
                state["activationLatchEnabled"] = True
                state.pop("pendingActivationLatch", None)
                write(args.state, state)
            if record["statecode"] != 1:
                record = patch_workflow(api, record, {"statecode": 1, "statuscode": 2})
            verify_flow_state(api, record["workflowid"], "Started")
            require(verify_resources(api, state)["PSRAllowEmail"] is False, "Email must remain off when arming validation.")
        elif args.command in ("approve-source", "approve-email-source"):
            require(control["PSRMode"] == "SyntheticValidation" and args.version, "Arm exact-source validation first.")
            identity = uuid_text(args.source_id)
            file = api.sp("GET", "_api/web/GetFileById(guid'" + identity + "')?$select=UniqueId,UIVersionLabel,ServerRelativeUrl")
            require(file["UIVersionLabel"] == args.version
                    and file["ServerRelativeUrl"].startswith(state["bindings"]["INCOMING_REL"] + "/"),
                    "Approved source is not the exact current configured Incoming version.")
            set_control(api, state, {"PSRAllowedSourceUniqueId": identity, "PSRAllowedSourceVersion": args.version,
                                   "PSRAllowEmail": args.command == "approve-email-source"})
        elif args.command == "accept-test":
            identity = uuid_text(args.job_id)
            jobs = rows(api.sp("GET", "_api/web/lists(guid'" + state["bindings"]["JOBS_ID"] + "')/items"
                              "?$filter=PSRJobId eq '" + identity + "'"))
            require(len(jobs) == 1 and jobs[0]["PSRStatus"] in ("ReviewSucceeded", "ReviewPartial", "EmailSent")
                    and jobs[0]["PSRSourceUniqueId"] == control["PSRAllowedSourceUniqueId"]
                    and jobs[0]["PSRSourceVersion"] == control["PSRAllowedSourceVersion"],
                    "A completed exact-source owner test was not verified.")
            coverage = api.sp("GET", "_api/web/GetFileByServerRelativeUrl('" + state["bindings"]["RESULTS_REL"]
                              + "/" + identity + "-coverage.json')/$value")
            counts = coverage["counts"]
            require(coverage["mainReviewValid"] is True and counts["savedDetailedSourceAssessments"] > 0
                    and counts["failedDetailedSourceAssessments"] == 0
                    and counts["savedDetailedSourceAssessments"] == counts["sourceExcerptsSupplied"],
                    "Owner test did not complete its declared source scope.")
            state["acceptedOwnerTest"] = {"jobId": identity, "definitionSha256": digest(data["properties"]["definition"]),
                                          "agentPublishedOn": bot["publishedon"], "partialCoveragePreserved": coverage["outcome"]}
        elif args.command == "activate":
            proof = state.get("acceptedOwnerTest", {})
            require(proof.get("definitionSha256") == digest(data["properties"]["definition"])
                    and proof.get("agentPublishedOn") == bot["publishedon"], "Accept an actual owner-scoped test of this exact revision first.")
            set_control(api, state, {"PSRMode": "Enabled", "PSRAllowEmail": False})
            if record["statecode"] != 1:
                record = patch_workflow(api, record, {"statecode": 1, "statuscode": 2})
            verify_flow_state(api, record["workflowid"], "Started")
        elif args.command == "pause":
            set_control(api, state, {"PSRMode": "Disabled", "PSRAllowEmail": False})
            if record["statecode"] != 0:
                record = patch_workflow(api, record, {"statecode": 0, "statuscode": 1})
            verify_flow_state(api, record["workflowid"], "Stopped")
        result.update({"agentId": state["agent"]["id"], "controlModeBefore": control["PSRMode"],
                       "emailBefore": control["PSRAllowEmail"], "actualTestOrEmailInvocationsByHelper": 0})
    write(args.state, state)
    result.update({"state": args.state, "imports": 0, "publishes": 0, "uploads": 0, "emailsSent": 0})
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
