# 3.3.2.6

Publication packaging revision r2 preserves the prior sealed candidate and all
native solution/template bytes. It uses nonworking target-configuration tokens,
rejects unresolved tokens before preparation, and keeps offline test fixtures
outside the public archive without reducing validation coverage. The unused
zero-group import-settings stub is omitted; an actual group assignment is emitted
only when explicitly configured for the reviewer.

- Adds the accepted v4.3.1 reader-layout Word helper, action and formatter from an
  authentic current reviewer **draft** export; retains the existing collector and
  all 19 agent components/native dependencies.
- Explicitly derives automatic Word review from the native 3.3.2.5 export plus the
  sealed local 3.3.2.6 candidate. Automatic native Word execution remains untested.
- Ships the exact generic template and verifies owner-uploaded bytes and the
  actual target GetFileSchema before binding; no source-tenant template IDs remain.
- Adds the Word connector's explicit owner binding, distinct source Invoker versus
  output Embedded verification, complete multi-workflow preparation and safe
  shared-reference membership checks.
- Resolves pre-import storage setup without a guessed agent/control record.
  Preserves stopped imports, no automatic publication, activation latch, exact
  source guards, supported ParseJson Secure Inputs only and 21/500 action budgets.
- Preserves report-only Read in configured Results, source/audit privacy, safe
  filename-derived folders and unique native-run DOCX names. Only exact sole
  Limited Access traversal is excluded from root content-access checks.
- Uses the actual GPT5Chat model-selection shape and removes historical
  Reasoning-model deployment labels from configurable metadata.

Local PAC/configuration and source-native manual Word proof are separate evidence.
This release does not claim a cross-tenant import/runtime pass and does not change
the source tenant's published agent or deployed automatic flow. Existing c102
3.3.1.102 and prior native reports/templates/seals are preserved.
