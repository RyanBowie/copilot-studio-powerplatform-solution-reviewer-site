"""Tenant-explicit, narrowly scoped target API client. Tokens stay in memory."""

import base64
import gzip
import json
import subprocess
from urllib.error import HTTPError
from urllib.parse import quote, unquote, urlencode, urlsplit
from urllib.request import Request, urlopen

from configuration import APIS, cli, require


class TargetApiError(RuntimeError):
    def __init__(self, method, status):
        self.status = status
        super().__init__("Target API " + method + " failed with HTTP " + str(status))


class TargetApi:
    def __init__(self, config):
        self.config = config
        self.tokens = {}
        self.metadata = {}

    def token(self, resource):
        if resource not in self.tokens:
            value = subprocess.check_output([
                cli(self.config, "azureCliPath"), "account", "get-access-token", "--tenant", self.config["tenantId"],
                "--resource", resource, "--query", "accessToken", "-o", "tsv",
            ], text=True).strip()
            encoded = value.split(".")[1]
            claims = json.loads(base64.urlsafe_b64decode(encoded + "=" * (-len(encoded) % 4)))
            require(claims.get("tid", "").lower() == self.config["tenantId"].lower(),
                    "Azure CLI returned a token for the wrong tenant.")
            self.tokens[resource] = value
        return self.tokens[resource]

    def request(self, method, url, resource, body=None, etag=None, binary=False):
        headers = {"Authorization": "Bearer " + self.token(resource), "Content-Type": "application/json",
                   "Accept": "application/json", "Prefer": "return=representation"}
        if etag:
            headers["If-Match"] = etag
        request = Request(url, method=method, headers=headers,
                          data=None if body is None else json.dumps(body).encode())
        try:
            with urlopen(request, timeout=120) as response:
                raw = response.read()
                if raw.startswith(b"\x1f\x8b"):
                    raw = gzip.decompress(raw)
                return raw if binary else (json.loads(raw) if raw else None)
        except HTTPError as error:
            # Do not print response payloads: a platform error can contain private or signed links.
            raise TargetApiError(method, error.code) from None

    def dv(self, method, path, body=None, etag=None):
        require(not path.startswith(("http:", "https:")) and ".." not in path, "Invalid Dataverse route.")
        return self.request(method, self.config["dataverseUrl"] + "/api/data/v9.2/" + path,
                            self.config["dataverseUrl"], body, etag)

    def flow(self, method, path, body=None):
        base = "https://api.flow.microsoft.com/providers/Microsoft.ProcessSimple/environments/"
        return self.request(method, base + self.config["environmentId"] + "/" + path,
                            "https://service.flow.microsoft.com/", body)

    def runtime(self, connector):
        require(connector in APIS, "Unsupported connector.")
        if connector not in self.metadata:
            data = self.flow("GET", "apis/" + connector + "?api-version=2016-11-01")["properties"]
            url = data["primaryRuntimeUrl"].rstrip("/")
            host = urlsplit(url).hostname or ""
            require(host.endswith((".azure-apihub.net", ".azure-apim.net")), "Unexpected connector runtime host.")
            self.metadata[connector] = url
        return self.metadata[connector]

    def sp(self, method, uri, body=None, headers=None, personal=False):
        require(method in ("GET", "POST") and uri.startswith("_api/") and ".." not in uri,
                "Only constrained site-scoped SharePoint operations are supported.")
        site = self.config["ownerOneDriveSiteUrl"] if personal else self.config["siteUrl"]
        connection = self.config["connections"]["shared_sharepointonline"]
        url = self.runtime("shared_sharepointonline") + "/" + quote(connection, safe="") \
            + "/datasets/" + quote(quote(site, safe=""), safe="") + "/httprequest"
        payload = {"method": method, "uri": uri, "headers": {
            "Accept": "application/json;odata=nometadata", **(headers or {})}}
        if body is not None:
            payload["body"] = body if isinstance(body, str) else json.dumps(body)
            payload["headers"].setdefault("Content-Type", "application/json;odata=verbose")
        value = self.request("POST", url, "https://apihub.azure.com", payload)
        if isinstance(value, dict) and "body" in value:
            value = value["body"]
        if isinstance(value, str):
            try:
                value = json.loads(value)
            except ValueError:
                return value
        return value.get("d", value) if isinstance(value, dict) else value

    def preflight(self):
        c = self.config
        environment = self.request("GET", "https://api.powerapps.com/providers/Microsoft.PowerApps/environments/"
                                   + c["environmentId"] + "?api-version=2016-11-01",
                                   "https://service.powerapps.com/")
        require(environment["name"].lower() == c["environmentId"].lower(), "Wrong target environment.")
        linked = environment["properties"]["linkedEnvironmentMetadata"]["instanceUrl"]
        require(linked.rstrip("/").lower() == c["dataverseUrl"].lower(), "Dataverse/environment mismatch.")
        profile = self.request("GET", "https://graph.microsoft.com/v1.0/me?$select=id,mail,userPrincipalName,userType",
                               "https://graph.microsoft.com")
        require(profile.get("userType") == "Member"
                and profile["userPrincipalName"].lower() == c["ownerUpn"].lower()
                and bool(profile.get("mail")), "Installer must run as the declared licensed target owner/service user.")
        for api in c["connections"]:
            self.verify_connection(api)
        self.own_default_drive(profile)
        return profile

    def verify_connection(self, connector):
        require(connector in APIS, "Unsupported target connection.")
        c = self.config
        url = "https://api.powerapps.com/providers/Microsoft.PowerApps/apis/" + connector + "/connections/" \
              + quote(c["connections"][connector], safe="") + "?" + urlencode({
                  "api-version": "2016-11-01", "$filter": "environment eq '" + c["environmentId"] + "'"})
        properties = self.request("GET", url, "https://service.powerapps.com/")["properties"]
        require(properties["environment"]["name"].lower() == c["environmentId"].lower()
                and properties["accountName"].lower() == c["ownerUpn"].lower()
                and any(v.get("status") == "Connected" for v in properties["statuses"]),
                "Wrong/disconnected target owner or environment for " + connector)

    def own_default_drive(self, profile):
        self.verify_connection("shared_onedriveforbusiness")
        graph = "https://graph.microsoft.com"
        try:
            current = self.request("GET", graph + "/v1.0/me?$select=id,userPrincipalName,userType", graph)
            require(isinstance(current, dict) and current.get("userType") == "Member"
                    and current.get("id") and current["id"].lower() == profile["id"].lower()
                    and current.get("userPrincipalName", "").lower() == self.config["ownerUpn"].lower(),
                    "Own-drive proof: authenticated Graph user differs from the configured runtime owner.")
            listed = self.request("GET", graph + "/v1.0/me/drives?$select=id,driveType,owner&$top=20", graph)
            require(isinstance(listed, dict) and isinstance(listed.get("value"), list)
                    and not listed.get("@odata.nextLink"), "Own-drive proof: missing or incomplete existing-drive list.")
            owned = {d["id"] for d in listed["value"] if isinstance(d, dict) and d.get("id")
                     and d.get("driveType") == "business"
                     and ((d.get("owner") or {}).get("user") or {}).get("id", "").lower() == current["id"].lower()}
            # /me/drive can auto-provision. Do not call it without an existing owned business drive.
            require(owned, "Own-drive proof unavailable/unprovisioned. Open the owner's OneDrive first; no ACL fallback.")
            drive = self.request("GET", graph + "/v1.0/me/drive?$select=id,driveType,owner,webUrl", graph)
            require(isinstance(drive, dict) and drive.get("id") in owned and drive.get("driveType") == "business"
                    and ((drive.get("owner") or {}).get("user") or {}).get("id", "").lower() == current["id"].lower(),
                    "Own-drive proof: authenticated default drive is not the configured owner's existing drive.")
            item = self.request("GET", graph + "/v1.0/me/drive/root"
                                "?$select=id,webUrl,parentReference,folder,root,remoteItem,sharepointIds", graph)
        except TargetApiError as error:
            raise ValueError("Own-drive proof unavailable (HTTP " + str(error.status)
                             + "). No grants, automatic setup, or ACL-only fallback are performed.") from None
        require(isinstance(item, dict) and item.get("id") and isinstance(item.get("folder"), dict)
                and isinstance(item.get("root"), dict) and item.get("remoteItem") is None
                and (item.get("parentReference") or {}).get("driveId") == drive["id"],
                "Own-drive proof: default root is missing, remote, or belongs to a different drive.")
        spids = item.get("sharepointIds") or {}
        require(spids.get("tenantId", "").lower() == self.config["tenantId"].lower()
                and site_url(spids.get("siteUrl")) == site_url(self.config["ownerOneDriveSiteUrl"]),
                "Own-drive proof: configured personal site/tenant does not own the authenticated default drive.")
        root_url = site_url(item.get("webUrl"))
        require(root_url == site_url(drive.get("webUrl"))
                and root_url.startswith(site_url(self.config["ownerOneDriveSiteUrl"]) + "/"),
                "Own-drive proof: default library root does not match the authenticated personal site.")
        return {
            "driveId": drive["id"], "ownerObjectId": current["id"], "rootItemId": item["id"],
            "siteUrl": site_url(spids["siteUrl"]), "rootUrl": root_url,
            "rootRelativeUrl": unquote(urlsplit(root_url).path),
            "connectionId": self.config["connections"]["shared_onedriveforbusiness"],
            "connectionAccount": current["userPrincipalName"], "association": "Microsoft Graph authenticated /me/drive",
        }

    def own_inbox_item(self, proof):
        name = self.config["manualInboxName"]
        graph = "https://graph.microsoft.com"
        try:
            item = self.request("GET", graph + "/v1.0/me/drive/root:/" + quote(name, safe="")
                                + "?$select=id,name,webUrl,parentReference,folder,remoteItem,sharepointIds", graph)
        except TargetApiError as error:
            if error.status == 404:
                return None
            raise ValueError("Own Inbox identity proof unavailable; no folder/ACL fallback.") from None
        parent = (item.get("parentReference") or {}) if isinstance(item, dict) else {}
        spids = (item.get("sharepointIds") or {}) if isinstance(item, dict) else {}
        require(isinstance(item, dict) and item.get("id") and item.get("name") == name
                and isinstance(item.get("folder"), dict) and item.get("remoteItem") is None
                and parent.get("driveId") == proof["driveId"] and parent.get("id") == proof["rootItemId"]
                and spids.get("tenantId", "").lower() == self.config["tenantId"].lower()
                and site_url(spids.get("siteUrl")) == proof["siteUrl"] and spids.get("listItemUniqueId")
                and site_url(item.get("webUrl")) == proof["rootUrl"] + "/" + name,
                "Own Inbox must be a physical direct folder in the verified default drive; shortcuts and mismatches are rejected.")
        return item


def site_url(value):
    require(isinstance(value, str) and value, "Own-drive proof is missing a required authoritative URL.")
    parsed = urlsplit(value)
    path = unquote(parsed.path).rstrip("/")
    require(parsed.scheme == "https" and parsed.hostname and parsed.hostname.endswith("-my.sharepoint.com")
            and not parsed.username and not parsed.password and not parsed.port and not parsed.query and not parsed.fragment
            and path.startswith("/personal/") and not any(c in path for c in "'\"<>\\%")
            and not any(ord(c) < 32 for c in path),
            "Unsupported or unsafe authoritative personal-drive URL.")
    return "https://" + parsed.hostname.lower() + quote(path, safe="/-_.~")


def rows(value):
    return value if isinstance(value, list) else value.get("value", value.get("results", []))
