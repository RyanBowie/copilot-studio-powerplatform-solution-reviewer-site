"""Post-import PSR setup. No pack/import/upload/publish/run/send operations exist here."""

import argparse
from copy import deepcopy
from datetime import datetime, timezone
import json
from pathlib import Path
from urllib.parse import quote
from uuid import uuid4

from configuration import (
    MODEL, ROOT, consent, digest, invalidate, ledger_for, read, require,
    target_identity, target_key, uuid_text, validate, write,
)
from release import Release, discover, owned, query, unpack_json, verify_workflow
from resource_setup import (
    inbox, inspect_resources, provision, set_control, verify_resources,
)
from target_api import TargetApi, rows
from word_setup import verify_template


MUTATING = {"setup", "publication-prerequisite", "enable-manual", "record-manual-smoke", "arm-test",
            "approve-source", "accept-test", "activate", "authorize-email-source", "pause"}
READ_ONLY = {"plan", "verify-import", "verify", "inspect-incoming"}


def current_value(entry):
    return (entry["current"] or {}).get("value") or ""


def assert_claim(snapshot, state, config):
    marker = snapshot["variables"]["psr_INSTALLATION_ID"]
    value = current_value(marker)
    if state is None:
        require(not value, "Native installation marker exists without its local ledger; no silent adoption/recovery.")
        require(all(not current_value(v) for v in snapshot["variables"].values()),
                "Fresh unclaimed release contains current values. Clear/reimport deliberately, never silently adopt.")
    else:
        require(state.get("identity") == target_identity(config), "Installation ledger target differs.")
        require(value in ("", config["installationId"]), "Native installation marker belongs to another installation.")
        if value:
            require(marker["current"]["environmentvariablevalueid"] == state["markerValueId"],
                    "Native installation-marker identity differs from the ledger.")
        else:
            require(not state.get("claimed"), "Claimed installation lost its native marker; no automatic re-claim.")


def save_variable(api, entry, value, value_id):
    require(isinstance(value, str), "Native current values must be strings.")
    before = entry["current"]
    if before and before.get("value") == value:
        return before
    api.atomic_current_value(entry["definition"], before, value, value_id)
    did = entry["definition"]["environmentvariabledefinitionid"]
    actual = query(api, "environmentvariablevalues", "_environmentvariabledefinitionid_value eq " + did)
    require(len(actual) == 1 and actual[0].get("value") == value
            and actual[0]["environmentvariablevalueid"] == (before["environmentvariablevalueid"] if before else value_id),
            "Current-value readback/collision differs. Stop; never accept a second competing current value.")
    return actual[0]


def claim(api, release, snapshot, profile, config, path, state=None):
    api.assert_write()
    assert_claim(snapshot, state, config)
    require(all(w["statecode"] == 0 and w["statuscode"] == 1 for w in snapshot["workflows"].values())
            and not snapshot["agent"].get("publishedon"), "Claim only a verified stopped unpublished release.")
    require(not unpack_json(snapshot["workflows"]["automation"]["clientdata"])["properties"]["definition"]
            ["parameters"]["psrDeploymentReady"]["defaultValue"], "Fresh claim must remain readiness=false.")
    if state is None:
        existing = snapshot["variables"]["psr_INSTALLATION_ID"]["current"]
        state = {"identity": target_identity(config), "targetKey": target_key(config),
                 "releaseFingerprint": release.fingerprint,
                 "markerValueId": existing["environmentvariablevalueid"] if existing else str(uuid4()),
                 "claimed": False, "setupComplete": False, "ready": False}
    require(state["releaseFingerprint"] == release.fingerprint, "Ledger belongs to another canonical release.")
    state.update(owner=profile, agent={"id": snapshot["agent"]["botid"], "schema": release.agent_schema})
    # A crash after the remote CAS is recoverable ONLY with this saved claim intent.
    write(path, state)
    save_variable(api, snapshot["variables"]["psr_INSTALLATION_ID"], config["installationId"], state["markerValueId"])
    state["claimed"] = True
    write(path, state)
    return state


def target_values(config, state, release):
    values = {
        "INSTALLATION_ID": config["installationId"], "ENVIRONMENT_ID": config["environmentId"],
        "TENANT_ID": config["tenantId"], "DATAVERSE_URL": config["dataverseUrl"],
        "OWNER_UPN": config["ownerUpn"].lower(), "MODEL_NAME": MODEL,
        "LIBRARY_NAME": config["libraryName"], "MANUAL_INBOX_NAME": config["manualInboxName"],
        "MANUAL_INBOX_ROOT": "/" + config["manualInboxName"],
        "AGENT_ID": state["agent"]["id"], "AGENT_PICKER": "", "AGENT_PUBLISHED_UTC": "",
        **state["bindings"],
    }
    result = {}
    for schema, spec in release.variables.items():
        token = spec["token"]
        require(token in values, "Unsupported target variable; no guessed binding: " + token)
        value = str(values[token])
        require(not any(char in value for char in "'\"<>\r\n"), "Unsafe target binding: " + token)
        require(value or token in ("AGENT_PICKER", "AGENT_PUBLISHED_UTC"), "Missing target binding: " + token)
        result[schema] = value
    return result


def bind_references(api, release, snapshot, profile):
    for name, spec in release.references.items():
        api.verify_connection(spec["connector"], profile)
        record = snapshot["references"][name]
        target = api.config["connections"][spec["connector"]]
        if (record.get("connectionid") or "").rsplit("/", 1)[-1] == target:
            continue
        require(not record.get("connectionid"), "No silent reference takeover.")
        route = "connectionreferences(" + record["connectionreferenceid"] + ")"
        api.dv("PATCH", route, {"connectionid": target}, record["@odata.etag"])
        actual = api.dv("GET", route)
        owned(actual, profile, name)
        require(actual.get("connectionid", "").rsplit("/", 1)[-1] == target
                and actual.get("connectorid") == record.get("connectorid"), "Connection binding readback differs.")


def validate_saved_values(snapshot, state):
    expected = state.get("values", {})
    pending = state.get("pendingValues", {})
    for name, entry in snapshot["variables"].items():
        value = current_value(entry)
        if name == "psr_INSTALLATION_ID":
            require(value == state["identity"]["installationId"], "Native installation ownership marker changed.")
        else:
            require(value in {expected.get(name, ""), pending.get(name, "")},
                    "Native configuration drift/collision, not a trusted local change: " + name)


def apply_values(api, release, snapshot, state, values, path):
    validate_saved_values(snapshot, state)
    invalidate(state)
    state["pendingValues"] = values
    state.setdefault("valueIds", {})
    for name, entry in snapshot["variables"].items():
        state["valueIds"].setdefault(name, (entry["current"] or {}).get("environmentvariablevalueid") or str(uuid4()))
    write(path, state)
    for name, value in values.items():
        if name != "psr_INSTALLATION_ID":
            save_variable(api, snapshot["variables"][name], value, state["valueIds"][name])
    state["values"] = values
    state.pop("pendingValues", None)
    write(path, state)


def install(api, release, config, path, state=None):
    api.assert_write()
    if state and state.get("targetKey") != target_key(config):
        invalidate(state)
        state["targetKey"] = target_key(config)
        write(path, state)
    profile = api.preflight()
    snapshot = discover(api, release, profile)
    assert_claim(snapshot, state, config)
    if state:
        require(state["releaseFingerprint"] == release.fingerprint, "Canonical release differs from saved ledger.")
        validate_saved_values(snapshot, state)
    candidate = deepcopy(state or {})
    candidate.update(owner=profile, agent={"id": snapshot["agent"]["botid"], "schema": release.agent_schema})
    verify_template(api, candidate)
    inspect_resources(api, candidate)
    # Re-read authoritative ownership/definitions after potentially slow resource/schema reads.
    snapshot = discover(api, release, profile)
    state = claim(api, release, snapshot, profile, config, path, state)
    invalidate(state)
    state.update(bindings=candidate.get("bindings", {}), wordTemplate=candidate["wordTemplate"])
    write(path, state)
    provision(api, state, release.manifest["controlContractVersion"])
    inbox(api, state, profile)
    verify_template(api, state)
    snapshot = discover(api, release, profile)
    bind_references(api, release, snapshot, profile)
    snapshot = discover(api, release, profile, bound=True)
    apply_values(api, release, snapshot, state, target_values(config, state, release), path)
    final = discover(api, release, profile, bound=True)
    require(all(current_value(final["variables"][k]) == v for k, v in state["values"].items()),
            "Native configured values differ from intended target.")
    control = verify_resources(api, state)
    require(control["PSRMode"] == "Disabled" and control["PSRAllowEmail"] is False,
            "Installation must finish Disabled/no-email.")
    state.update(setupComplete=True, ready=False, targetKey=target_key(config),
                 configuredAt=datetime.now(timezone.utc).isoformat(),
                 configurationFingerprint=configuration_fingerprint(config, release, state, final))
    write(path, state)
    return state


def configuration_fingerprint(config, release, state, snapshot):
    return digest({
        "targetKey": target_key(config), "release": release.fingerprint, "values": {
            k: current_value(v) for k, v in snapshot["variables"].items()},
        "references": {k: {"id": v["connectionreferenceid"], "connectionid": v.get("connectionid"),
                            "owner": v.get("_ownerid_value")} for k, v in snapshot["references"].items()},
        "components": {k: v["botcomponentid"] for k, v in snapshot["components"].items()},
        "agent": snapshot["agent"]["botid"], "template": state["wordTemplate"],
        "owner": {k: state["owner"][k] for k in ("id", "systemUserId", "userPrincipalName", "mail")},
        "bindings": state["bindings"],
    })


def checked(api, release, config, state, path=None):
    require(state and state.get("claimed") and state.get("setupComplete"), "Complete post-import setup first.")
    if state["targetKey"] != target_key(config):
        if path is not None:
            invalidate(state)
            write(path, state)
        raise ValueError("Configuration changed; all prior acceptance/authorization is invalid. Pause/unpublish and rerun setup.")
    profile = api.preflight()
    require(profile["id"] == state["owner"]["id"] and profile["systemUserId"] == state["owner"]["systemUserId"],
            "Authenticated owner identity changed.")
    snapshot = discover(api, release, profile, ready=state.get("ready") is True, stopped=False, unpublished=False, bound=True)
    assert_claim(snapshot, state, config)
    require(release.fingerprint == state["releaseFingerprint"], "Canonical release changed; existing acceptance is invalid.")
    require(all(current_value(v) == state["values"].get(k) for k, v in snapshot["variables"].items()),
            "Native current configuration changed; acceptance/authorization is invalid.")
    control = verify_resources(api, state)
    verify_template(api, state)
    require(configuration_fingerprint(config, release, state, snapshot) == state["configurationFingerprint"],
            "Owner/resource/template/native binding changed; acceptance is invalid.")
    return snapshot, control


def no_active_runs(api, workflow_id):
    values = rows(api.flow("GET", "flows/" + workflow_id + "/runs?api-version=2016-11-01&$top=100"))
    require(all(v.get("properties", {}).get("status") in
                {"Succeeded", "Failed", "Cancelled", "Canceled", "TimedOut", "Skipped", "Aborted"} for v in values),
            "Active/unknown runs prevent this mutation.")


def patch_workflow(api, record, changes):
    api.assert_write()
    no_active_runs(api, record["workflowid"])
    route = "workflows(" + record["workflowid"] + ")"
    api.dv("PATCH", route, changes, record["@odata.etag"])
    actual = api.dv("GET", route)
    require(all((unpack_json(actual[k]) == unpack_json(v)) if k == "clientdata" else actual[k] == v
                for k, v in changes.items()), "Workflow readback differs; never retry stale ETags.")
    return actual


def switch_flow(api, record, enabled):
    desired = 1 if enabled else 0
    if record["statecode"] != desired:
        record = patch_workflow(api, record, {"statecode": desired, "statuscode": 2 if enabled else 1})
    properties = api.flow("GET", "flows/" + record["workflowid"] + "?api-version=2016-11-01")["properties"]
    require(properties["state"] == ("Started" if enabled else "Stopped"), "Flow state not yet confirmed; stop and inspect.")
    return record


def set_readiness(api, release, state, record, ready, path):
    require(record["statecode"] == 0, "Deliberate readiness mutation requires the stopped automatic flow.")
    data = verify_workflow(record, release.workflows["automation"], state.get("ready") is True)
    data["properties"]["definition"]["parameters"]["psrDeploymentReady"]["defaultValue"] = ready
    state["pendingReadiness"] = ready
    write(path, state)
    result = patch_workflow(api, record, {"clientdata": json.dumps(data)})
    state["ready"] = ready
    state.pop("pendingReadiness", None)
    write(path, state)
    return result


def publication_prerequisite(api, release, config, state, path, snapshot, control):
    require(all(w["statecode"] == 0 for w in snapshot["workflows"].values()) and not state["ready"]
            and control["PSRMode"] == "Disabled" and control["PSRAllowEmail"] is False,
            "Publication metadata binding requires all flows stopped, readiness=false and control Disabled/no-email.")
    bot = snapshot["agent"]
    require(bot.get("publishedon"), "Publish the reviewed target agent separately in Copilot Studio; helper never publishes.")
    sync = unpack_json(bot.get("synchronizationstatus") or "{}")
    require(sync.get("currentSynchronizationState", {}).get("state") == "Synchronized"
            and sync.get("lastFinishedPublishOperation", {}).get("status") == "Succeeded",
            "Target publication is not successfully synchronized.")
    connection = config["connections"]["shared_microsoftcopilotstudio"]
    response = api.request("GET", api.runtime("shared_microsoftcopilotstudio") + "/" + quote(connection, safe="")
                           + "/powervirtualagents/dataverse-backed/copilots", "https://apihub.azure.com")
    response = unpack_json(response.get("body", response))
    entries = [{str(k).lower(): v for k, v in e.items()} for e in response.get("copilotsList", [])]
    matches = [e for e in entries if str(e.get("id", "")).lower() == bot["botid"].lower()
               and e.get("schemaname") == release.agent_schema]
    require(len(matches) == 1, "Published target agent is not uniquely available through the verified owner connector.")
    values = {**state["values"], "psr_AGENT_PICKER": release.agent_schema, "psr_AGENT_PUBLISHED_UTC": bot["publishedon"]}
    require(set(values) == set(release.variables), "Publication parameters are not part of this canonical release.")
    apply_values(api, release, snapshot, state, values, path)
    snapshot = discover(api, release, state["owner"], unpublished=False, bound=True)
    state["publication"] = {"agentId": bot["botid"], "publishedOn": bot["publishedon"]}
    state["setupComplete"] = True
    state["configuredAt"] = datetime.now(timezone.utc).isoformat()
    state["configurationFingerprint"] = configuration_fingerprint(config, release, state, snapshot)
    write(path, state)


def proof_revision(state, snapshot):
    return digest({"configuration": state["configurationFingerprint"], "publication": snapshot["agent"].get("publishedon"),
                   "definition": unpack_json(snapshot["workflows"]["automation"]["clientdata"])["properties"]["definition"]})


def exact_source(api, state, source_id, version):
    identity = uuid_text(source_id)
    require(isinstance(version, str) and version and len(version) < 40, "Exact source version is required.")
    item = api.sp("GET", "_api/web/GetFileById(guid'" + identity
                  + "')?$select=UniqueId,UIVersionLabel,ServerRelativeUrl,Length,ETag")
    require(item["UniqueId"].lower() == identity and item["UIVersionLabel"] == version
            and item["ServerRelativeUrl"].startswith(state["bindings"]["INCOMING_REL"] + "/")
            and "/" not in item["ServerRelativeUrl"][len(state["bindings"]["INCOMING_REL"]) + 1:]
            and item["ServerRelativeUrl"].lower().endswith((".zip", ".msapp")),
            "Source must be the exact current trusted-package version directly inside configured Incoming.")
    return {"id": identity, "version": version, "path": item["ServerRelativeUrl"], "etag": item.get("ETag")}


def successful_run(api, workflow_id, run_id, after):
    require(isinstance(run_id, str) and run_id.isalnum() and len(run_id) <= 150, "Invalid actual native run ID.")
    result = api.flow("GET", "flows/" + workflow_id + "/runs/" + run_id + "?api-version=2016-11-01")
    properties = result.get("properties", {})
    require(result.get("name") == run_id and properties.get("status") == "Succeeded",
            "Actual native run did not succeed.")
    require(properties.get("startTime") and datetime.fromisoformat(properties["startTime"].replace("Z", "+00:00"))
            >= datetime.fromisoformat(after.replace("Z", "+00:00")), "Native run predates this configuration/authorization.")


def review_evidence(path):
    require(path, "Human Word/result item security review evidence is required.")
    evidence = read(path)
    expected = {"syntheticOnly", "wordContentReviewed", "requesterReadOnlyVerified", "noSharingNotificationVerified", "noEmail"}
    require(isinstance(evidence, dict) and set(evidence) == expected and all(v is True for v in evidence.values()),
            "Required human-reviewed Word/security evidence is incomplete.")
    return evidence


def lifecycle(command, api, release, config, path, state, args):
    api.assert_write()
    try:
        snapshot, control = checked(api, release, config, state, path)
    except (ValueError, KeyError):
        if state:
            invalidate(state)
            write(path, state)
        raise
    if command == "publication-prerequisite":
        publication_prerequisite(api, release, config, state, path, snapshot, control)
        return state
    if command == "enable-manual":
        require(not state["ready"] and snapshot["workflows"]["automation"]["statecode"] == 0
                and control["PSRMode"] == "Disabled" and control["PSRAllowEmail"] is False,
                "Manual enablement must not authorize automation or email.")
        for kind in ("reviewer", "word"):
            switch_flow(api, snapshot["workflows"][kind], True)
    elif command == "record-manual-smoke":
        require(args.confirm_harmless_test, "Explicit harmless synthetic manual-test confirmation is required.")
        require(args.collector_run and args.word_run, "Both actual native collector and Word run IDs are required.")
        for kind, run_id in (("reviewer", args.collector_run), ("word", args.word_run)):
            successful_run(api, release.workflows[kind]["workflowId"], run_id, state["configuredAt"])
        evidence = review_evidence(args.evidence)
        state["manualSmoke"] = {"configuration": state["configurationFingerprint"],
                                "collectorRun": args.collector_run, "wordRun": args.word_run,
                                "observations": evidence, "nativeAutomaticAccepted": False}
    elif command == "arm-test":
        require(args.confirm_harmless_test, "Explicit harmless synthetic automatic-test confirmation is required.")
        require(state.get("manualSmoke", {}).get("configuration") == state["configurationFingerprint"],
                "Record an authorized harmless manual smoke for this exact configuration first.")
        require(state.get("publication") == {"agentId": snapshot["agent"]["botid"],
                                            "publishedOn": snapshot["agent"].get("publishedon")},
                "Bind verified publication as a separate prerequisite first.")
        require(control["PSRMode"] == "Disabled" and control["PSRAllowEmail"] is False and not state["ready"]
                and snapshot["workflows"]["automation"]["statecode"] == 0, "Automatic test must start from disabled state.")
        for key in ("acceptedOwnerTest", "sourceAuthorization", "emailAuthorization", "activationAuthorized"):
            state.pop(key, None)
        write(path, state)
        set_control(api, state, {"PSRMode": "SyntheticValidation", "PSRAllowEmail": False,
                                "PSRActivationUtc": datetime.now(timezone.utc).isoformat(),
                                "PSRAllowedSourceUniqueId": None, "PSRAllowedSourceVersion": None}, expected=control)
        record = set_readiness(api, release, state, snapshot["workflows"]["automation"], True, path)
        switch_flow(api, record, True)
    elif command in ("approve-source", "authorize-email-source"):
        require(args.confirm_harmless_test and control["PSRMode"] == "SyntheticValidation" and state["ready"],
                "Only an explicitly authorized exact harmless source in SyntheticValidation mode can be approved.")
        source = exact_source(api, state, args.source_id, args.version)
        email = command == "authorize-email-source"
        if email:
            require(state.get("acceptedOwnerTest", {}).get("revision") == proof_revision(state, snapshot)
                    and args.confirm_email_recipient == state["owner"]["mail"],
                    "Separate explicit exact-source email consent and accepted automatic revision are required.")
        else:
            state.pop("acceptedOwnerTest", None)
            state.pop("emailAuthorization", None)
        source["revision"] = proof_revision(state, snapshot)
        source["authorizedAt"] = datetime.now(timezone.utc).isoformat()
        state["emailAuthorization" if email else "sourceAuthorization"] = source
        write(path, state)
        set_control(api, state, {"PSRAllowedSourceUniqueId": source["id"], "PSRAllowedSourceVersion": source["version"],
                                "PSRAllowEmail": email}, expected=control)
    elif command == "accept-test":
        require(control["PSRMode"] == "SyntheticValidation" and control["PSRAllowEmail"] is False,
                "Initial automatic acceptance must be an exact-source no-email test.")
        authorization = state.get("sourceAuthorization", {})
        require(authorization.get("revision") == proof_revision(state, snapshot), "Exact-source authorization revision changed.")
        require(authorization.get("id") == control["PSRAllowedSourceUniqueId"]
                and authorization.get("version") == control["PSRAllowedSourceVersion"], "Control source authorization changed.")
        identity = uuid_text(args.job_id)
        jobs = rows(api.sp("GET", "_api/web/lists(guid'" + state["bindings"]["JOBS_ID"]
                          + "')/items?$filter=PSRJobId eq '" + identity + "'"))
        require(len(jobs) == 1 and jobs[0]["PSRStatus"] in ("ReviewSucceeded", "ReviewPartial")
                and jobs[0]["PSRSourceUniqueId"] == authorization["id"]
                and jobs[0]["PSRSourceVersion"] == authorization["version"]
                and jobs[0]["PSREmailState"] == "NotAttempted", "Completed exact-source no-email job was not verified.")
        successful_run(api, release.workflows["automation"]["workflowId"], jobs[0].get("PSRFlowRunId"),
                       state["configuredAt"])
        coverage = api.sp("GET", "_api/web/GetFileByServerRelativeUrl('" + state["bindings"]["RESULTS_REL"]
                          + "/" + identity + "-coverage.json')/$value")
        counts = coverage["counts"]
        require(coverage["mainReviewValid"] is True and counts["savedDetailedSourceAssessments"] > 0
                and counts["failedDetailedSourceAssessments"] == 0
                and counts["savedDetailedSourceAssessments"] == counts["sourceExcerptsSupplied"],
                "Native automatic test did not complete declared source scope.")
        evidence = review_evidence(args.evidence)
        no_active_runs(api, release.workflows["automation"]["workflowId"])
        state["acceptedOwnerTest"] = {"jobId": identity, "revision": proof_revision(state, snapshot),
                                      "source": authorization, "coverageSha256": digest(coverage), "observations": evidence}
    elif command == "activate":
        require(state.get("acceptedOwnerTest", {}).get("revision") == proof_revision(state, snapshot),
                "Accept an actual exact-source native automatic run of this configuration/revision first.")
        require(state["ready"] and snapshot["workflows"]["automation"]["statecode"] == 1
                and control["PSRMode"] == "SyntheticValidation" and control["PSRAllowEmail"] is False,
                "Activation must follow authorized no-email validation, not native configuration alone.")
        no_active_runs(api, release.workflows["automation"]["workflowId"])
        set_control(api, state, {"PSRMode": "Enabled", "PSRAllowEmail": False,
                                "PSRAllowedSourceUniqueId": None, "PSRAllowedSourceVersion": None}, expected=control)
        state["activationAuthorized"] = proof_revision(state, snapshot)
        state.pop("emailAuthorization", None)
    elif command == "pause":
        set_control(api, state, {"PSRMode": "Disabled", "PSRAllowEmail": False,
                                "PSRAllowedSourceUniqueId": None, "PSRAllowedSourceVersion": None}, expected=control)
        for kind, record in snapshot["workflows"].items():
            record = switch_flow(api, record, False)
            if kind == "automation" and state["ready"]:
                set_readiness(api, release, state, record, False, path)
        for key in ("acceptedOwnerTest", "sourceAuthorization", "emailAuthorization", "activationAuthorized"):
            state.pop(key, None)
    write(path, state)
    return state


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=sorted(MUTATING | READ_ONLY))
    parser.add_argument("--manifest", default=str(ROOT / "release-manifest.json"))
    parser.add_argument("--config", required=True)
    parser.add_argument("--state", default="psr-target-state.json")
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--confirm-environment")
    parser.add_argument("--confirm-harmless-test", action="store_true")
    parser.add_argument("--confirm-email-recipient")
    parser.add_argument("--source-id")
    parser.add_argument("--version")
    parser.add_argument("--job-id")
    parser.add_argument("--collector-run")
    parser.add_argument("--word-run")
    parser.add_argument("--evidence")
    args = parser.parse_args(argv)
    manifest = read(args.manifest)
    config = validate(read(args.config), manifest)
    if args.command in MUTATING:
        consent(config, args.apply, args.confirm_environment)
    release = Release(args.manifest)
    if args.command == "plan":
        print(json.dumps({"environmentId": config["environmentId"], "version": release.manifest["version"],
                          "order": "Import reviewer; import automation; verify-import; setup; separate deliberate acceptance",
                          "nativeAutomaticImportOrRuntimeAccepted": False, "writes": 0, "networkRequests": 0}, indent=2))
        return
    state = ledger_for(config, args.state)
    api = TargetApi(config, args.apply, args.confirm_environment)
    if args.command == "setup":
        state = install(api, release, config, args.state, state)
    elif args.command == "verify-import":
        profile = api.preflight()
        snapshot = discover(api, release, profile)
        assert_claim(snapshot, state, config)
    elif args.command in MUTATING:
        state = lifecycle(args.command, api, release, config, args.state, state, args)
    else:
        snapshot, control = checked(api, release, config, state)
        if args.command == "inspect-incoming":
            files = rows(api.sp("GET", "_api/web/GetFolderByServerRelativeUrl('" + state["bindings"]["INCOMING_REL"]
                               + "')/Files?$select=Name,UniqueId,UIVersionLabel&$top=50"))
            print(json.dumps({"incoming": files}, indent=2))
    print(json.dumps({"command": args.command, "environmentId": config["environmentId"],
                      "setupComplete": bool(state and state.get("setupComplete")),
                      "imports": 0, "publishes": 0, "uploads": 0, "invocations": 0, "emailsSentByHelper": 0,
                      "nativeAutomaticImportOrRuntimeAccepted": bool(state and state.get("acceptedOwnerTest"))}, indent=2))


if __name__ == "__main__":
    main()
