"""Owner-private, installation-marked resources; no unrelated adoption or broad grants."""

from urllib.parse import urlsplit
from xml.sax.saxutils import escape

from configuration import ROOT, read, require
from target_api import rows


def marker(config):
    return "PSR import-first installation " + config["installationId"]


def sole_limited_access(item):
    roles = rows(item.get("RoleDefinitionBindings", []))
    return (len(roles) == 1 and set(roles[0]) == {"Id", "RoleTypeKind"}
            and roles[0]["Id"] == 1073741825 and roles[0]["RoleTypeKind"] == 1)


def private_site(api, profile, personal=False):
    user = api.sp("GET", "_api/web/currentuser?$select=Id,Email,LoginName", personal=personal)
    require(user["LoginName"].lower().endswith("|membership|" + api.config["ownerUpn"].lower())
            and user["Email"].lower() in (profile["mail"].lower(), profile["userPrincipalName"].lower()),
            "SharePoint identity differs from the configured owner.")
    if not personal:
        acl = rows(api.sp("GET", "_api/web/roleassignments?$select=Member/Id,RoleDefinitionBindings/Id,RoleDefinitionBindings/RoleTypeKind"
                         "&$expand=Member,RoleDefinitionBindings"))
        acl = [item for item in acl if not sole_limited_access(item)]
        require(len(acl) == 1 and acl[0]["Member"]["Id"] == user["Id"]
                and any(v["RoleTypeKind"] == 5 for v in rows(acl[0]["RoleDefinitionBindings"])),
                "Site must already be private with direct Full Control only for the owner; no root ACL changes.")
        admins = rows(api.sp("GET", "_api/web/siteusers?$select=Id,Email&$filter=IsSiteAdmin eq true"))
        require(all(v["Id"] == user["Id"] for v in admins), "Unexpected explicit site collection administrator.")
    return user


def get_list(api, title):
    values = rows(api.sp("GET", "_api/web/lists?$select=Id,Title,Description,BaseTemplate,HasUniqueRoleAssignments,"
                        "EnableVersioning,ListItemEntityTypeFullName,RootFolder/ServerRelativeUrl&$expand=RootFolder"
                        "&$filter=Title eq '" + title + "'"))
    require(len(values) <= 1, "Ambiguous target resource name.")
    return values[0] if values else None


def inspect_resources(api, state):
    """Read all collisions before claiming or writing any resources."""
    profile, c = state["owner"], api.config
    private_site(api, profile)
    found = {}
    for key, template in (("libraryName", 101), ("jobsListName", 100), ("controlListName", 100)):
        current = get_list(api, c[key])
        require(current is None or (current["Description"] == marker(c) and current["BaseTemplate"] == template
                and current["EnableVersioning"] is True and current["HasUniqueRoleAssignments"] is False),
                "Existing unrelated, unversioned or differently scoped resource: " + c[key])
        found[key] = current
    control = found["controlListName"]
    if control:
        fields = rows(api.sp("GET", "_api/web/lists(guid'" + control["Id"]
                            + "')/fields?$select=InternalName&$filter=InternalName eq 'PSRMode'"))
        if fields:
            records = rows(api.sp("GET", "_api/web/lists(guid'" + control["Id"]
                                 + "')/items?$select=Title,PSRMode,PSRAllowEmail,PSROwnerObjectId,PSRAgentId"))
            require(not records or (len(records) == 1 and records[0]["Title"] == marker(c)
                    and records[0]["PSRMode"] == "Disabled" and records[0]["PSRAllowEmail"] is False
                    and records[0]["PSROwnerObjectId"] == profile["id"]
                    and records[0]["PSRAgentId"] == state["agent"]["id"]),
                    "Existing controls must be disabled/no-email and belong to this exact owner/agent.")
    proof = api.own_default_drive(profile)
    if api.own_inbox_item(proof):
        inbox(api, state, profile, create=False)
    return found


def owned_list(api, title, template):
    current = get_list(api, title)
    if current is None:
        api.assert_write()
        api.sp("POST", "_api/web/lists", {"__metadata": {"type": "SP.List"}, "Title": title,
                                        "Description": marker(api.config), "BaseTemplate": template, "EnableVersioning": True})
        current = get_list(api, title)
    require(current and current["Description"] == marker(api.config) and current["BaseTemplate"] == template,
            "Existing unrelated or mismatched list: " + title)
    require(current["EnableVersioning"] and not current["HasUniqueRoleAssignments"],
            "Target list must be versioned and inherit the verified private site.")
    return current


def field(api, list_id, name, kind="Text", choices=None, unique=False):
    base = "_api/web/lists(guid'" + list_id + "')"
    query = base + "/fields?$select=Id,InternalName,TypeAsString,Indexed,EnforceUniqueValues&$filter=InternalName eq '" + name + "'"
    values = rows(api.sp("GET", query))
    if not values:
        attrs = 'Type="' + kind + '" Name="' + name + '" StaticName="' + name + '" DisplayName="' + name + '"'
        if kind == "Note":
            attrs += ' RichText="FALSE" NumLines="6"'
        if kind == "DateTime":
            attrs += ' Format="DateTime"'
        if unique:
            attrs += ' Indexed="TRUE" EnforceUniqueValues="TRUE"'
        body = "<CHOICES>" + "".join("<CHOICE>" + escape(v) + "</CHOICE>" for v in choices) + "</CHOICES>" if choices else ""
        api.sp("POST", base + "/fields/createfieldasxml", {"parameters": {
            "__metadata": {"type": "SP.XmlSchemaFieldCreationInformation"},
            "SchemaXml": "<Field " + attrs + ">" + body + "</Field>", "Options": 0}})
        values = rows(api.sp("GET", query))
    require(len(values) == 1 and values[0]["TypeAsString"] == kind, "Wrong field schema: " + name)
    require(not unique or (values[0]["Indexed"] and values[0]["EnforceUniqueValues"]), "Job key must be unique/indexed.")
    if choices:
        actual = api.sp("GET", base + "/fields/getbyinternalnameortitle('" + name + "')?$select=Choices")
        require(set(rows(actual["Choices"])) == set(choices), "Choice values differ: " + name)


def provision(api, state, contract_version):
    api.assert_write()
    require(state.get("claimed") and state.get("agent", {}).get("id"),
            "Canonical imported component validation and installation claim must precede resource setup.")
    c, profile = api.config, state["owner"]
    inspect_resources(api, state)
    owner = private_site(api, profile)
    library, jobs, control = [owned_list(api, c[key], kind) for key, kind in
                              (("libraryName", 101), ("jobsListName", 100), ("controlListName", 100))]
    schema = read(ROOT / "sharepoint-schema.json")
    for group, kind in (("jobTextFields", "Text"), ("jobNoteFields", "Note"),
                        ("jobNumberFields", "Number"), ("jobDateFields", "DateTime")):
        for name in schema[group]:
            field(api, jobs["Id"], name, kind, unique=name == schema["uniqueIndexedJobKey"])
    field(api, jobs["Id"], "PSRStatus", "Choice", schema["jobStatuses"])
    field(api, jobs["Id"], "PSREmailState", "Choice", schema["emailStates"])
    for group, kind in (("controlTextFields", "Text"), ("controlDateFields", "DateTime"), ("controlBooleanFields", "Boolean")):
        for name in schema[group]:
            field(api, control["Id"], name, kind)
    field(api, control["Id"], "PSRMode", "Choice", schema["controlModes"])
    base = "_api/web/lists(guid'" + control["Id"] + "')/items"
    existing = rows(api.sp("GET", base + "?$select=Id,Title,PSRMode,PSRAllowEmail,PSROwnerObjectId,PSRAgentId"))
    if not existing:
        api.sp("POST", base, {
            "__metadata": {"type": control["ListItemEntityTypeFullName"]}, "Title": marker(c),
            "PSRMode": "Disabled", "PSRAllowEmail": False, "PSROwnerObjectId": profile["id"],
            "PSROwnerMail": profile["mail"], "PSRAgentId": state["agent"]["id"],
            "PSRContractVersion": contract_version, "PSRActivationUtc": "2099-01-01T00:00:00Z",
        })
        existing = rows(api.sp("GET", base + "?$select=Id,Title,PSRMode,PSRAllowEmail,PSROwnerObjectId,PSRAgentId"))
    require(len(existing) == 1 and existing[0]["Title"] == marker(c) and existing[0]["PSRMode"] == "Disabled"
            and existing[0]["PSRAllowEmail"] is False and existing[0]["PSROwnerObjectId"] == profile["id"]
            and existing[0]["PSRAgentId"] == state["agent"]["id"], "Target control collision/mismatch.")
    library_root = library["RootFolder"]["ServerRelativeUrl"]
    require(library_root.startswith(urlsplit(c["siteUrl"]).path + "/")
            and not any(char in library_root for char in "'\"<>\\\r\n"), "Unsafe target library path.")
    folders = {}
    for name in ("Incoming", "Results", "Working"):
        relative = library_root + "/" + name
        found = rows(api.sp("GET", "_api/web/GetFolderByServerRelativeUrl('" + library_root
                           + "')/Folders?$select=Name,UniqueId,ServerRelativeUrl&$filter=Name eq '" + name + "'"))
        require(len(found) <= 1, "Ambiguous target folder.")
        if not found:
            api.sp("POST", "_api/web/folders", {"__metadata": {"type": "SP.Folder"}, "ServerRelativeUrl": relative})
        folder = api.sp("GET", "_api/web/GetFolderByServerRelativeUrl('" + relative + "')?$select=UniqueId,ServerRelativeUrl")
        permissions = api.sp("GET", "_api/web/GetFolderByServerRelativeUrl('" + relative
                             + "')/ListItemAllFields?$select=HasUniqueRoleAssignments")
        require(folder["ServerRelativeUrl"] == relative and permissions["HasUniqueRoleAssignments"] is False,
                "Target folder scope/privacy differs.")
        folders[name] = folder
    web, site = api.sp("GET", "_api/web?$select=Id,Url"), api.sp("GET", "_api/site?$select=Id")
    require(web["Url"].rstrip("/") == c["siteUrl"], "Wrong target web.")
    state["bindings"] = {**state.get("bindings", {}),
        "OWNER_OID": profile["id"], "OWNER_MAIL": profile["mail"].lower(), "OWNER_SP_EMAIL": owner["Email"].lower(),
        "OWNER_SP_LOGIN": owner["LoginName"].lower(), "OWNER_SP_ID": str(owner["Id"]), "SITE_URL": c["siteUrl"],
        "SP_ORIGIN": "https://" + urlsplit(c["siteUrl"]).netloc, "SITE_ID": site["Id"], "WEB_ID": web["Id"],
        "LIBRARY_ID": library["Id"], "LIBRARY_REL": library_root,
        "LIBRARY_SITE_REL": library_root[len(urlsplit(c["siteUrl"]).path):],
        "JOBS_ID": jobs["Id"], "JOBS_ENTITY": jobs["ListItemEntityTypeFullName"],
        "CONTROL_ID": control["Id"], "CONTROL_ENTITY": control["ListItemEntityTypeFullName"],
        "CONTROL_ITEM_ID": str(existing[0]["Id"]),
        **{name.upper() + "_REL": record["ServerRelativeUrl"] for name, record in folders.items()},
    }
    return state


def inbox(api, state, profile, create=True):
    c = api.config
    proof = api.own_default_drive(profile)
    require(proof.get("ownerObjectId", "").lower() == profile["id"].lower(), "Authoritative default-drive owner required.")
    own_item = api.own_inbox_item(proof)
    owner = private_site(api, profile, personal=True)
    root, relative = proof["rootRelativeUrl"], proof["rootRelativeUrl"] + "/" + c["manualInboxName"]
    found = rows(api.sp("GET", "_api/web/GetFolderByServerRelativeUrl('" + root
                       + "')/Folders?$select=Name,UniqueId&$filter=Name eq '" + c["manualInboxName"] + "'", personal=True))
    folder_api, marker_name = "_api/web/GetFolderByServerRelativeUrl('" + relative + "')", "PSR-" + c["installationId"] + ".txt"
    require(bool(found) == (own_item is not None), "Graph default-drive/SharePoint Inbox existence disagree.")
    if not found:
        require(create and state.get("claimed"), "Inbox absent; explicit claimed setup is required.")
        api.sp("POST", "_api/web/folders", {"__metadata": {"type": "SP.Folder"}, "ServerRelativeUrl": relative}, personal=True)
        own_item = api.own_inbox_item(proof)
        require(own_item, "New folder default-drive identity is not verifiable; no ACL/marker writes.")
        created = api.sp("GET", folder_api + "?$select=UniqueId", personal=True)
        require(created["UniqueId"].lower() == own_item["sharepointIds"]["listItemUniqueId"].lower(),
                "Created folder differs from authenticated default-drive item.")
        api.sp("POST", folder_api + "/ListItemAllFields/breakroleinheritance(copyRoleAssignments=false,clearSubscopes=true)",
               personal=True)
        api.sp("POST", folder_api + "/Files/add(url='" + marker_name + "',overwrite=false)", marker(c),
               headers={"Content-Type": "text/plain"}, personal=True)
    else:
        require(len(found) == 1 and found[0]["UniqueId"].lower() == own_item["sharepointIds"]["listItemUniqueId"].lower(),
                "SharePoint/Graph Inbox identities differ.")
    markers = rows(api.sp("GET", folder_api + "/Files?$select=Name&$filter=Name eq '" + marker_name + "'", personal=True))
    require(len(markers) == 1, "Existing Inbox is unrelated; nothing was overwritten.")
    contents = api.sp("GET", folder_api + "/Files('" + marker_name + "')/$value", personal=True)
    require(contents == marker(c), "Inbox marker content differs; no silent adoption.")
    acl = api.sp("GET", folder_api + "/ListItemAllFields?$select=HasUniqueRoleAssignments,RoleAssignments/Member/Id,"
                 "RoleAssignments/RoleDefinitionBindings/RoleTypeKind&$expand=RoleAssignments/Member,RoleAssignments/RoleDefinitionBindings",
                 personal=True)
    assignments = rows(acl["RoleAssignments"])
    require(acl["HasUniqueRoleAssignments"] is True and len(assignments) == 1
            and assignments[0]["Member"]["Id"] == owner["Id"]
            and any(v["RoleTypeKind"] == 5 for v in rows(assignments[0]["RoleDefinitionBindings"])),
            "The caller Inbox is not private to its owner.")
    state["ownerInboxVerified"] = True
    state["ownerDrive"] = {**proof, "inboxItemId": own_item["id"], "manualInvokerPath": "/" + c["manualInboxName"]}
    return state


def control_uri(state):
    b = state["bindings"]
    return "_api/web/lists(guid'" + b["CONTROL_ID"] + "')/items(" + b["CONTROL_ITEM_ID"] + ")"


def verify_resources(api, state):
    owner = private_site(api, state["owner"])
    inbox(api, state, state["owner"], create=False)
    b = state["bindings"]
    require(str(owner["Id"]) == b["OWNER_SP_ID"], "Owner principal changed.")
    for key in ("LIBRARY_ID", "JOBS_ID", "CONTROL_ID"):
        item = api.sp("GET", "_api/web/lists(guid'" + b[key] + "')?$select=Description,HasUniqueRoleAssignments,EnableVersioning")
        require(item["Description"] == marker(api.config) and not item["HasUniqueRoleAssignments"] and item["EnableVersioning"],
                "Resource ownership/privacy changed.")
    unique = api.sp("GET", "_api/web/lists(guid'" + b["JOBS_ID"]
                    + "')/fields/getbyinternalnameortitle('PSRJobKey')?$select=Indexed,EnforceUniqueValues")
    require(unique["Indexed"] and unique["EnforceUniqueValues"], "Unique job key is no longer enforced.")
    for key in ("INCOMING_REL", "RESULTS_REL", "WORKING_REL"):
        folder = api.sp("GET", "_api/web/GetFolderByServerRelativeUrl('" + b[key] + "')/ListItemAllFields?$select=HasUniqueRoleAssignments")
        require(folder.get("HasUniqueRoleAssignments") is False, "Folder privacy changed.")
    control = api.sp("GET", control_uri(state))
    require(control["PSROwnerObjectId"] == state["owner"]["id"]
            and control["PSROwnerMail"].lower() == state["owner"]["mail"].lower()
            and control["PSRAgentId"] == state["agent"]["id"] and control["Title"] == marker(api.config),
            "Target control identity differs.")
    return control


def set_control(api, state, changes, expected=None):
    control = verify_resources(api, state)
    etag = control.get("@odata.etag") or control.get("odata.etag") or control.get("__metadata", {}).get("etag")
    require(etag and etag != "*", "Exact control ETag required; no wildcard MERGE.")
    require(expected is not None, "A checked control snapshot is required.")
    old_etag = expected.get("@odata.etag") or expected.get("odata.etag") or expected.get("__metadata", {}).get("etag")
    require(old_etag == etag, "Control changed since authorization; no automatic retry.")
    api.sp("POST", control_uri(state), {"__metadata": {"type": state["bindings"]["CONTROL_ENTITY"]}, **changes},
           headers={"X-HTTP-Method": "MERGE", "IF-MATCH": etag})
    actual = api.sp("GET", control_uri(state))
    for key, value in changes.items():
        if key.endswith("Utc") and value:
            from datetime import datetime
            require(datetime.fromisoformat(actual[key].replace("Z", "+00:00"))
                    == datetime.fromisoformat(value.replace("Z", "+00:00")), "Control timestamp readback differs.")
        else:
            require(actual.get(key) == value, "Control readback differs: " + key)
