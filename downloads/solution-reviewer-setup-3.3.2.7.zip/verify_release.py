"""Offline integration check of a finalized manifest and its canonical native ZIPs."""

import argparse
import json

from release import Release
from configuration import flatten


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest")
    args = parser.parse_args()
    release = Release(args.manifest)
    print(json.dumps({
        "version": release.manifest["version"], "offlineCanonicalValidation": True,
        "workflowActionCounts": {kind: len(flatten(w["definition"]["actions"])) for kind, w in release.workflows.items()},
        "agentComponents": len(release.components), "logicalReferences": len(release.references),
        "environmentDefinitions": len(release.variables), "networkRequests": 0, "targetMutations": 0,
        "nativeImportAccepted": False, "nativeRuntimeAccepted": False,
    }, indent=2))


if __name__ == "__main__":
    main()
