"""Verify exact owner-uploaded template bytes and the immutable native Word schema."""

import base64
import hashlib
import json
from urllib.parse import quote, urlencode

from configuration import ROOT, digest, require


TEMPLATE = "current-review-v4.3.1.web.template.docx"
TEMPLATE_SHA256 = "498ee9eb6d1fbd9df4fa719a873fa57237fdbf224fcb6c62c77c96881bac3065"
ROOT_KEYS = {"ReviewIdentity": "940007", "ReviewBlocks": "940008",
             "NativeRunStamp": "940009", "PresentationNotes": "940010"}
CHILDREN = ("BlockHeading", "LeadText", "BodyText", "NestedText", "CodeText")
EXPECTED_SCHEMA = {
    "type": "array", "items": {"type": "object", "properties": {
        "940007": {"type": "string", "x-ms-summary": "ReviewIdentity"},
        "940008": {"type": "array", "x-ms-summary": "ReviewBlocks", "items": {
            "type": "object", "properties": {name: {"type": "string", "x-ms-summary": name} for name in CHILDREN}}},
        "940009": {"type": "string", "x-ms-summary": "NativeRunStamp"},
        "940010": {"type": "string", "x-ms-summary": "PresentationNotes"},
    }},
}


def schema_keys(schema):
    def shape(value, property_map=False):
        require(isinstance(value, dict), "Unexpected Word schema structure.")
        if property_map:
            return {k: shape(v) for k, v in value.items()}
        require(set(value) <= {"type", "items", "properties", "x-ms-summary", "title", "description"},
                "Unknown Word schema structural metadata; stop rather than adapting the renderer.")
        result = {}
        for key, item in value.items():
            if key in ("title", "description"):
                require(isinstance(item, str), "Invalid schema descriptive metadata.")
                continue
            result[key] = shape(item, key == "properties") if isinstance(item, dict) else item
        return result
    require(shape(schema) == EXPECTED_SCHEMA,
            "Target Word schema differs from exact 940007/940008/940009/940010 keys and five-child repeat structure. STOP.")
    return dict(ROOT_KEYS)


def verify_template(api, state):
    require(hashlib.sha256((ROOT / TEMPLATE).read_bytes()).hexdigest() == TEMPLATE_SHA256,
            "Bundled template bytes changed; do not upload or bind.")
    proof = api.own_default_drive(state["owner"])
    name, graph = api.config["wordTemplateName"], "https://graph.microsoft.com"
    url = graph + "/v1.0/me/drive/root:/" + quote(name, safe="") \
          + "?$select=id,name,eTag,size,file,folder,remoteItem,parentReference"
    item = api.request("GET", url, graph)
    require(item.get("name") == name and isinstance(item.get("file"), dict) and "folder" not in item
            and "remoteItem" not in item and item.get("parentReference", {}).get("driveId") == proof["driveId"]
            and item["parentReference"].get("id") == proof["rootItemId"],
            "Template must be an existing physical file in the verified owner's default drive root, never a shortcut.")
    drive, file_id = proof["driveId"], item["id"]
    connection = api.config["connections"]["shared_onedriveforbusiness"]
    route = api.runtime("shared_onedriveforbusiness") + "/" + quote(connection, safe="") \
            + "/datasets/default/files/" + quote(quote(drive + "." + file_id, safe=""), safe="")
    content = api.request("GET", route + "/content", "https://apihub.azure.com", binary=True)
    require(isinstance(content, bytes), "Template readback must return bytes.")
    if not content.startswith(b"PK"):
        envelope = json.loads(content)
        require(isinstance(envelope, dict) and isinstance(envelope.get("$content"), str), "Unsupported binary envelope.")
        content = base64.b64decode(envelope["$content"], validate=True)
    require(len(content) == item["size"] and hashlib.sha256(content).hexdigest() == TEMPLATE_SHA256,
            "Target template is not the byte-exact approved file. No upload/overwrite/repair is performed.")
    connection = api.config["connections"]["shared_wordonlinebusiness"]
    schema_url = api.runtime("shared_wordonlinebusiness") + "/" + quote(connection, safe="") \
                 + "/api/templates/schema?" + urlencode({"source": "me", "drive": drive, "file": file_id})
    schema = api.request("GET", schema_url, "https://apihub.azure.com")
    schema_keys(schema)
    after = api.request("GET", url, graph)
    require(item.get("eTag") and all(after.get(k) == item.get(k)
                                    for k in ("id", "name", "eTag", "size", "parentReference")),
            "Target template changed during verification.")
    state.setdefault("bindings", {}).update(WORD_DRIVE=drive, WORD_FILE=file_id)
    state["wordTemplate"] = {"sha256": TEMPLATE_SHA256, "driveId": drive, "fileId": file_id, "etag": item["eTag"],
                             "schemaSha256": digest(schema), "rootKeys": dict(ROOT_KEYS)}
    return state["wordTemplate"]
