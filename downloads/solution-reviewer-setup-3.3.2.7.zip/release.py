"""Canonical native-package validation and fail-closed post-import discovery."""

from copy import deepcopy
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
from urllib.parse import urlencode
from xml.etree import ElementTree as ET
import zipfile

import yaml

from configuration import (
    APIS, MODEL, RELEASE_DESCRIPTION, ROOT, SOURCE_ENVIRONMENT_SHA256, VERSION,
    digest, flatten, kernel_of, read, require, uuid_text,
)
from target_api import rows


KERNEL_SHA256 = "df94f86db9401751cb3d3746301b42f71c24e880e39e4c7334c6e93eedcde2c2"
COMPONENT_TYPES = {"workflow": 29, "bot": 10227, "botcomponent": 10229,
                   "connectionreference": 10165, "environmentvariabledefinition": 380}
EXPECTED_COUNTS = {"reviewer": 225, "word": 21, "automation": 500}


def unpack_json(value):
    return json.loads(value) if isinstance(value, str) else value


def safe_name(value):
    require(isinstance(value, str) and re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_.-]*", value),
            "Unsafe canonical schema/name.")
    return value


def query(api, table, filter_text, fields=None):
    params = {"$filter": filter_text}
    if fields:
        params["$select"] = fields
    return rows(api.dv("GET", table + "?" + urlencode(params)))


def unique(values, message):
    require(len(values) == 1, message)
    return values[0]


def owned(record, profile, label):
    require(record.get("_ownerid_value", "").lower() == profile["systemUserId"].lower(),
            "Foreign/missing component owner: " + label)
    require(record.get("ismanaged") is not True, "Managed component cannot be configured: " + label)
    require(record.get("@odata.etag") and record["@odata.etag"] != "*", "Missing component ETag: " + label)


def xml_fields(node):
    result = {}
    for child in node:
        if len(child) or child.tag in ("timezoneruleversionnumber", "iscustomizable"):
            continue
        value = child.text or ""
        if child.tag in ("authenticationmode", "authenticationtrigger", "accesscontrolpolicy", "language",
                         "runtimeprovider", "componenttype", "statecode", "statuscode"):
            value = int(value)
        result[child.tag] = value
    return result


class Release:
    def __init__(self, manifest_path):
        self.path = Path(manifest_path).resolve()
        self.manifest = read(self.path)
        m = self.manifest
        require(m.get("version") == VERSION, "Unsupported release version; expected " + VERSION)
        require(m.get("releaseDescription", RELEASE_DESCRIPTION) == RELEASE_DESCRIPTION,
                "Canonical release description must be static, not installation-stamped.")
        require(m.get("sourceEnvironmentIdSha256") == SOURCE_ENVIRONMENT_SHA256, "Protected-source guard differs.")
        require(m.get("activationParameter") == "psrDeploymentReady" and m.get("kernelSha256") == KERNEL_SHA256,
                "Release readiness/safety-kernel contract differs.")
        self.agent_schema = safe_name(m["agentSchema"])
        self.packages, self.workflows, self.references, self.variables = {}, {}, {}, {}
        self.bot, self.components = None, {}
        require(len(m["packages"]) == 2, "Exactly the reviewer and automatic native packages are required.")
        for spec in m["packages"]:
            self._package(spec)
        require(set(self.workflows) == set(EXPECTED_COUNTS), "Missing/extra native workflow.")
        require(self.bot and len(self.components) == 19, "The complete 19-component authentic reviewer is required.")
        require(len(self.references) == 8 and {r["connector"] for r in self.references.values()} == set(APIS),
                "Expected eight logical references over six connectors.")
        declared = {e["schemaName"]: e for e in m["environmentVariables"]}
        require(len(declared) == len(m["environmentVariables"]) and set(declared) == set(self.variables),
                "Native environment-variable inventory differs from the manifest.")
        for name, spec in self.variables.items():
            entry = declared[name]
            require(name == "psr_" + entry["token"] and spec["type"] == 100000000
                    and entry["type"] in ("String", "string", 100000000),
                    "Expected ordinary native String environment-variable definitions.")
            spec["token"] = entry["token"]
        require("psr_INSTALLATION_ID" in self.variables, "Missing native installation marker definition.")
        parameter_names = {name for workflow in self.workflows.values()
                           for name in workflow["definition"].get("parameters", {}) if name.startswith("psr_")}
        require(parameter_names <= set(self.variables), "A native flow parameter has no matching environment definition.")
        automatic = self.workflows["automation"]["definition"]
        selector = read(ROOT / "kernel-selector.json")
        require(digest(kernel_of(automatic, selector)) == KERNEL_SHA256,
                "Original strict rawSource/admission safety kernel was changed.")
        self.fingerprint = digest({"manifest": m, "packages": {k: p["sha256"] for k, p in self.packages.items()}})

    def _package(self, spec):
        kind = spec["kind"]
        require(kind in ("reviewer", "automation") and kind not in self.packages, "Duplicate/unknown package kind.")
        safe_name(spec["solutionName"])
        archive = self.path.parent / spec["file"]
        require(archive.resolve().parent == self.path.parent, "Solution ZIP must be beside the release manifest.")
        require(hashlib.sha256(archive.read_bytes()).hexdigest() == spec["sha256"], "Canonical ZIP hash differs.")
        package = {**spec, "expected": set(), "references": set(), "variables": set()}
        self.packages[kind] = package
        with zipfile.ZipFile(archive) as z:
            names = z.namelist()
            require(len(names) == len(set(names)), "Duplicate ZIP entries are not supported.")
            require(all(not PurePosixPath(n).is_absolute() and ".." not in PurePosixPath(n).parts for n in names),
                    "Unsafe canonical ZIP paths.")
            solution = ET.fromstring(z.read("solution.xml"))
            require(solution.findtext(".//SolutionManifest/UniqueName") == spec["solutionName"]
                    and solution.findtext(".//SolutionManifest/Version") == VERSION
                    and solution.findtext(".//SolutionManifest/Managed") == "0",
                    "Native solution identity/version/managed state differs.")
            descriptions = solution.findall(".//SolutionManifest/Descriptions/Description")
            require(descriptions and all(d.get("description") == RELEASE_DESCRIPTION for d in descriptions),
                    "Canonical solution description must not carry target installation identity.")
            custom = ET.fromstring(z.read("customizations.xml"))
            native_flows = {uuid_text(n.get("WorkflowId").strip("{}")): n for n in custom.findall(".//Workflows/Workflow")}
            require(set(native_flows) == {w["workflowId"] for w in spec["workflows"]}, "Native workflow inventory differs.")
            for workflow in spec["workflows"]:
                wkind = workflow["kind"]
                require(wkind in EXPECTED_COUNTS and wkind not in self.workflows, "Unknown/duplicate native workflow.")
                source = json.loads(z.read(workflow["workflowFile"].replace("\\", "/").lstrip("/")))
                definition = source["properties"]["definition"]
                compact = hashlib.sha256(json.dumps(definition, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
                require(workflow.get("definitionSha256") in (digest(definition), compact),
                        "Canonical workflow definition hash differs.")
                require(len(flatten(definition["actions"])) == workflow["actionCount"] == EXPECTED_COUNTS[wkind],
                        "Native action count differs; renderer/collector/automatic path must remain complete.")
                metadata = native_flows[workflow["workflowId"]]
                require(metadata.findtext("StateCode") == "0" and metadata.findtext("StatusCode") == "1",
                        "Canonical import must leave every workflow stopped.")
                expected_mode = "invoker" if wkind == "reviewer" else "embedded"
                references = source["properties"]["connectionReferences"]
                require(workflow["runtimeSource"].lower() == expected_mode
                        and references and all(r["runtimeSource"].lower() == expected_mode for r in references.values()),
                        "Canonical invoker/embedded boundary differs.")
                for name, parameter in definition.get("parameters", {}).items():
                    if name.startswith("psr_"):
                        require(parameter.get("type") == "String" and parameter.get("defaultValue") == ""
                                and parameter.get("metadata", {}).get("schemaName") == name,
                                "Native environment parameters must use identical schemaName, String and empty default.")
                if wkind == "automation":
                    require(definition["parameters"]["psrDeploymentReady"] == {"type": "Bool", "defaultValue": False}
                            and definition["parameters"]["psrDeploymentReady"]["defaultValue"] is False,
                            "Automatic readiness must be a false Boolean default.")
                self.workflows[wkind] = {**workflow, "package": kind, "definition": definition,
                                         "references": references, "modernflowtype": 0 if wkind == "automation" else 1}
                package["expected"].add((29, workflow["workflowId"]))
            for node in custom.findall(".//connectionreferences/connectionreference"):
                name = safe_name(node.get("connectionreferencelogicalname"))
                connector = node.findtext("connectorid").rsplit("/", 1)[-1]
                value = {"connector": connector}
                require(connector in APIS and (name not in self.references or self.references[name] == value),
                        "Connection-reference connector conflicts between native packages.")
                self.references[name] = value
                package["references"].add(name)
            for name in names:
                if name.startswith("bots/") and name.endswith("/bot.xml"):
                    require(self.bot is None, "Multiple canonical bots.")
                    node = ET.fromstring(z.read(name))
                    require(node.get("schemaname") == self.agent_schema, "Unexpected canonical bot schema.")
                    self.bot = {"fields": xml_fields(node), "package": kind,
                                "configuration": json.loads(z.read(str(PurePosixPath(name).parent / "configuration.json")))}
                elif name.startswith("botcomponents/") and name.endswith("/botcomponent.xml"):
                    node = ET.fromstring(z.read(name))
                    schema = safe_name(node.get("schemaname"))
                    require(schema not in self.components and node.findtext("parentbotid/schemaname") == self.agent_schema,
                            "Duplicate/foreign canonical bot component.")
                    data = z.read(str(PurePosixPath(name).parent / "data")).decode("utf-8-sig")
                    self.components[schema] = {"fields": xml_fields(node), "data": yaml.safe_load(data), "package": kind}
                elif name.lower().endswith("/environmentvariabledefinition.xml"):
                    self._environment(ET.fromstring(z.read(name)), package)
            for node in custom.findall(".//environmentvariabledefinition"):
                self._environment(node, package)
            # Known root IDs not resolved by schema below still have to be present.
            for root in solution.findall(".//RootComponents/RootComponent"):
                typ = int(root.get("type"))
                require(typ in set(COMPONENT_TYPES.values()), "Unsupported root component type; do not silently omit it.")
                if root.get("id") and typ == 29:
                    require((typ, uuid_text(root.get("id").strip("{}"))) in package["expected"],
                            "Unexpected structural workflow root.")
        if self.bot:
            require(self.bot["configuration"].get("publishOnImport") is False, "Automatic agent publication is forbidden.")
        for component in self.components.values():
            if component["fields"]["componenttype"] == 15:
                require(component["data"]["aISettings"]["model"] == {"modelNameHint": MODEL},
                        "The canonical bot must use constant GPT5Chat.")

    def _environment(self, node, package):
        name = safe_name(node.get("schemaname"))
        value = {"type": int(node.findtext("type")), "defaultvalue": node.findtext("defaultvalue") or ""}
        require(value["defaultvalue"] == "", "Target-specific environment defaults must be empty.")
        require(name not in self.variables or self.variables[name] == value, "Conflicting native environment definitions.")
        self.variables[name] = value
        package["variables"].add(name)


def verify_workflow(record, canonical, ready=False):
    data = unpack_json(record["clientdata"])
    expected = deepcopy(canonical["definition"])
    if canonical["kind"] == "automation" and ready:
        expected["parameters"]["psrDeploymentReady"]["defaultValue"] = True
    require(digest(data["properties"]["definition"]) == digest(expected), "Canonical workflow definition drift.")
    actual_refs = data["properties"]["connectionReferences"]
    require(set(actual_refs) == set(canonical["references"]), "Native workflow reference set drift.")
    for key, expected_ref in canonical["references"].items():
        actual = actual_refs[key]
        require(actual.get("runtimeSource", "").lower() == expected_ref["runtimeSource"].lower()
                and actual.get("connection", {}).get("connectionReferenceLogicalName")
                == expected_ref["connection"]["connectionReferenceLogicalName"]
                and actual.get("api", {}).get("name") == expected_ref["api"]["name"],
                "Native runtime identity/reference drift; no maker fallback is allowed.")
        require(set(actual.get("connection", {})) <= {"connectionReferenceLogicalName", "connectionName"}
                and not actual.get("source"), "Unexpected connection fallback in workflow.")
    require(record.get("modernflowtype") == canonical["modernflowtype"] and record.get("category") == 5,
            "Native workflow kind/category differs.")
    return data


def discover(api, release, profile, *, ready=False, stopped=True, unpublished=True, bound=False):
    snapshot = {"solutions": {}, "workflows": {}, "references": {}, "variables": {}, "components": {}}
    expected_members, actual_members = {}, {}
    for kind, spec in release.packages.items():
        solution = unique(query(api, "solutions", "uniquename eq '" + spec["solutionName"] + "'"),
                          "Import the unique canonical " + kind + " solution first; unrelated solutions are never adopted.")
        require(solution.get("version") == VERSION and solution.get("description") == RELEASE_DESCRIPTION
                and solution.get("ismanaged") is False, "Imported solution version/description/management differs.")
        sid = uuid_text(solution["solutionid"])
        snapshot["solutions"][kind] = solution
        records = query(api, "solutioncomponents", "_solutionid_value eq " + sid, "componenttype,objectid")
        actual_members[kind] = {(r["componenttype"], r["objectid"].lower()) for r in records}
        expected_members[kind] = set(spec["expected"])
    for kind, spec in release.workflows.items():
        record = api.dv("GET", "workflows(" + spec["workflowId"] + ")")
        owned(record, profile, kind)
        require(record["workflowid"].lower() == spec["workflowId"], "Wrong structural workflow ID.")
        verify_workflow(record, spec, ready)
        if stopped:
            require(record.get("statecode") == 0 and record.get("statuscode") == 1, "Unexpected active imported workflow.")
        properties = api.flow("GET", "flows/" + spec["workflowId"] + "?api-version=2016-11-01")["properties"]
        require(properties.get("state") == ("Stopped" if record["statecode"] == 0 else "Started"),
                "Native/management flow state disagreement.")
        if stopped:
            runs = rows(api.flow("GET", "flows/" + spec["workflowId"] + "/runs?api-version=2016-11-01&$top=100"))
            require(all(r.get("properties", {}).get("status") in
                        {"Succeeded", "Failed", "Cancelled", "Canceled", "TimedOut", "Skipped", "Aborted"} for r in runs),
                    "Active/unknown run prevents setup.")
        snapshot["workflows"][kind] = record
    bot = unique(query(api, "bots", "schemaname eq '" + release.agent_schema + "'"), "Imported bot schema is missing/ambiguous.")
    owned(bot, profile, "agent")
    for key, expected in release.bot["fields"].items():
        require(digest(bot.get(key)) == digest(expected), "Canonical agent field differs: " + key)
    require(digest(unpack_json(bot["configuration"])) == digest(release.bot["configuration"]), "Canonical bot configuration drift.")
    require((bot.get("authenticationmode"), bot.get("authenticationtrigger"), bot.get("accesscontrolpolicy")) == (2, 1, 2),
            "Integrated/Always/GroupMembership authentication is required; no automatic auth weakening.")
    if unpublished:
        require(not bot.get("publishedon"), "Unexpected published imported agent; fresh setup requires unpublished draft.")
        sync = unpack_json(bot.get("synchronizationstatus") or "{}")
        require(not sync.get("lastFinishedPublishOperation"), "Previous agent publication prevents fresh adoption.")
    bot_id = uuid_text(bot["botid"])
    expected_members[release.bot["package"]].add((10227, bot_id))
    snapshot["agent"] = bot
    components = query(api, "botcomponents", "_parentbotid_value eq " + bot_id)
    require(len(components) == len(release.components)
            and {c["schemaname"] for c in components} == set(release.components), "Imported bot component inventory differs.")
    for record in components:
        schema = record["schemaname"]
        spec = release.components[schema]
        owned(record, profile, schema)
        require(record.get("_parentbotid_value", "").lower() == bot_id, "Foreign parent bot.")
        require(all(digest(record.get(k)) == digest(v) for k, v in spec["fields"].items()), "Canonical botcomponent metadata drift.")
        require(digest(yaml.safe_load(record["data"])) == digest(spec["data"]), "Canonical botcomponent executable data drift.")
        expected_members[spec["package"]].add((10229, uuid_text(record["botcomponentid"])))
        snapshot["components"][schema] = record
    for name, spec in release.references.items():
        record = unique(query(api, "connectionreferences", "connectionreferencelogicalname eq '" + name + "'"),
                        "Imported reference is missing/ambiguous: " + name)
        owned(record, profile, name)
        require((record.get("connectorid") or "").rsplit("/", 1)[-1] == spec["connector"], "Wrong reference connector.")
        binding = (record.get("connectionid") or "").rsplit("/", 1)[-1]
        target = api.config["connections"][spec["connector"]]
        require(binding in ("", target) and (not bound or binding == target),
                "Imported reference has a foreign/missing target binding; no silent adoption.")
        for kind, package in release.packages.items():
            if name in package["references"]:
                expected_members[kind].add((10165, uuid_text(record["connectionreferenceid"])))
        snapshot["references"][name] = record
    for name, spec in release.variables.items():
        record = unique(query(api, "environmentvariabledefinitions", "schemaname eq '" + name + "'"),
                        "Imported environment definition is missing/ambiguous: " + name)
        owned(record, profile, name)
        require(record.get("type") == spec["type"] and not record.get("defaultvalue"),
                "Native environment definition type/default drift.")
        did = uuid_text(record["environmentvariabledefinitionid"])
        values = query(api, "environmentvariablevalues", "_environmentvariabledefinitionid_value eq " + did)
        require(len(values) <= 1, "Ambiguous current values: " + name)
        for value in values:
            owned(value, profile, name + " current value")
        for kind, package in release.packages.items():
            if name in package["variables"]:
                expected_members[kind].add((380, did))
        snapshot["variables"][name] = {"definition": record, "current": values[0] if values else None}
    require(actual_members == expected_members, "Imported component membership differs from the full canonical inventory.")
    allowed_ids = {s["solutionid"].lower() for s in snapshot["solutions"].values()}
    checked = set()
    for membership in expected_members.values():
        for typ, oid in membership - checked:
            checked.add((typ, oid))
            memberships = query(api, "solutioncomponents", "objectid eq " + oid + " and componenttype eq " + str(typ),
                                "_solutionid_value")
            for member in memberships:
                sid = member["_solutionid_value"].lower()
                if sid not in allowed_ids:
                    other = api.dv("GET", "solutions(" + sid + ")?$select=uniquename,isvisible")
                    require(other.get("uniquename") in ("Active", "Default") and other.get("isvisible") is False,
                            "Component belongs to an unrelated solution; do not silently take it over.")
    return snapshot
