"""Explicit-target API transport; importing this module never authenticates or connects."""

import base64
import gzip
import json
import subprocess
from urllib.error import HTTPError
from urllib.parse import quote, unquote, urlencode, urlsplit
from urllib.request import Request, urlopen
from uuid import uuid4

from configuration import APIS, cli, consent, require


class TargetApiError(RuntimeError):
    def __init__(self, method, status):
        self.status = status
        super().__init__("Target API " + method + " failed with HTTP " + str(status))


def rows(value):
    if isinstance(value, list):
        return value
    require(isinstance(value, dict), "Expected a typed collection.")
    require(not any(value.get(k) for k in ("@odata.nextLink", "odata.nextLink", "nextLink", "__next")),
            "Incomplete/paginated evidence; refine the query. No partial ownership/ACL proof is accepted.")
    return value.get("value", value.get("results", []))


def site_url(value):
    require(isinstance(value, str) and value, "Missing authoritative personal-drive URL.")
    parsed = urlsplit(value)
    path = unquote(parsed.path).rstrip("/")
    require(parsed.scheme == "https" and parsed.hostname and parsed.hostname.endswith("-my.sharepoint.com")
            and not parsed.username and not parsed.password and not parsed.port and not parsed.query and not parsed.fragment
            and path.startswith("/personal/") and not any(c in path for c in "'\"<>\\%")
            and not any(ord(c) < 32 for c in path), "Unsafe authoritative personal-drive URL.")
    return "https://" + parsed.hostname.lower() + quote(path, safe="/-_.~")


class TargetApi:
    def __init__(self, config, apply=False, confirm_environment=None):
        self.config, self.apply, self.confirm_environment = config, apply, confirm_environment
        self.tokens, self.metadata = {}, {}

    def assert_write(self):
        consent(self.config, self.apply, self.confirm_environment)

    def token(self, resource):
        if resource not in self.tokens:
            value = subprocess.check_output([
                cli(self.config, "azureCliPath"), "account", "get-access-token", "--tenant", self.config["tenantId"],
                "--resource", resource, "--query", "accessToken", "-o", "tsv",
            ], text=True).strip()
            encoded = value.split(".")[1]
            claims = json.loads(base64.urlsafe_b64decode(encoded + "=" * (-len(encoded) % 4)))
            require(claims.get("tid", "").lower() == self.config["tenantId"], "Token tenant differs from target.")
            require(claims.get("oid"), "Delegated target identity is missing.")
            if self.tokens:
                require(self.object_id == claims["oid"].lower(), "Tokens belong to different target identities.")
            self.object_id = claims["oid"].lower()
            self.tokens[resource] = value
        return self.tokens[resource]

    def request(self, method, url, resource, body=None, etag=None, binary=False,
                read_operation=False, content_type="application/json"):
        if method not in ("GET", "HEAD") and not read_operation:
            self.assert_write()
        if method in ("PATCH", "DELETE"):
            require(etag and etag != "*", "An exact ETag is mandatory; wildcard updates are forbidden.")
        headers = {"Authorization": "Bearer " + self.token(resource), "Content-Type": content_type,
                   "Accept": "application/json", "Prefer": "return=representation"}
        if etag:
            headers["If-Match"] = etag
        data = body if isinstance(body, bytes) else (None if body is None else json.dumps(body).encode())
        request = Request(url, method=method, headers=headers, data=data)
        try:
            with urlopen(request, timeout=120) as response:
                raw = response.read()
                if raw.startswith(b"\x1f\x8b"):
                    raw = gzip.decompress(raw)
                return raw if binary else (json.loads(raw) if raw else None)
        except HTTPError as error:
            # Responses can include credentials, signed URLs, or private evidence.
            raise TargetApiError(method, error.code) from None

    def dv(self, method, path, body=None, etag=None):
        require(not path.startswith(("http:", "https:")) and ".." not in path, "Invalid Dataverse route.")
        return self.request(method, self.config["dataverseUrl"] + "/api/data/v9.2/" + path,
                            self.config["dataverseUrl"], body, etag)

    def atomic_current_value(self, definition, existing, value, value_id):
        """Compare-and-swap the definition and value in ONE transactional changeset.

        Locking the shared definition row prevents concurrent first-value creations.
        No token is stored in this client-generated batch or its response.
        """
        self.assert_write()
        def_id, etag = definition["environmentvariabledefinitionid"], definition.get("@odata.etag")
        require(etag and etag != "*", "Definition ETag is required for a current-value write.")
        operations = [("PATCH", "environmentvariabledefinitions(" + def_id + ")", etag,
                       {"defaultvalue": definition.get("defaultvalue") or ""})]
        if existing:
            require(existing.get("@odata.etag") and existing["@odata.etag"] != "*", "Current-value ETag is missing.")
            operations.append(("PATCH", "environmentvariablevalues(" + existing["environmentvariablevalueid"] + ")",
                               existing["@odata.etag"], {"value": value}))
        else:
            operations.append(("POST", "environmentvariablevalues", None, {
                "environmentvariablevalueid": value_id, "value": value,
                "EnvironmentVariableDefinitionId@odata.bind": "/environmentvariabledefinitions(" + def_id + ")",
            }))
        batch, change = "batch_" + uuid4().hex, "changeset_" + uuid4().hex
        chunks = ["--" + batch, "Content-Type: multipart/mixed; boundary=" + change, ""]
        for index, (method, path, match, payload) in enumerate(operations, 1):
            chunks += ["--" + change, "Content-Type: application/http", "Content-Transfer-Encoding: binary",
                       "Content-ID: " + str(index), "", method + " /api/data/v9.2/" + path + " HTTP/1.1",
                       "Content-Type: application/json"]
            if match:
                chunks += ["If-Match: " + match]
            chunks += ["", json.dumps(payload), ""]
        chunks += ["--" + change + "--", "--" + batch + "--", ""]
        reply = self.request("POST", self.config["dataverseUrl"] + "/api/data/v9.2/$batch",
                             self.config["dataverseUrl"], "\r\n".join(chunks).encode(), binary=True,
                             content_type="multipart/mixed; boundary=" + batch)
        import re
        statuses = [int(s) for s in re.findall(rb"HTTP/1\.[01] (\d{3})", reply)]
        require(len(statuses) == 2 and all(200 <= s < 300 for s in statuses),
                "Transactional current-value CAS failed; no ETag retries/adoption. Reinspect target and ledger.")

    def flow(self, method, path, body=None):
        require(method == "GET", "This client never invokes flow-management mutations or runs.")
        return self.request(method, "https://api.flow.microsoft.com/providers/Microsoft.ProcessSimple/environments/"
                            + self.config["environmentId"] + "/" + path, "https://service.flow.microsoft.com/", body)

    def runtime(self, connector):
        require(connector in APIS, "Unsupported connector.")
        if connector not in self.metadata:
            data = self.flow("GET", "apis/" + connector + "?api-version=2016-11-01")["properties"]
            url = data["primaryRuntimeUrl"].rstrip("/")
            host = urlsplit(url).hostname or ""
            require(urlsplit(url).scheme == "https" and host.endswith((".azure-apihub.net", ".azure-apim.net")),
                    "Unexpected connector runtime host.")
            self.metadata[connector] = url
        return self.metadata[connector]

    def sp(self, method, uri, body=None, headers=None, personal=False):
        require(method in ("GET", "POST") and uri.startswith("_api/") and ".." not in uri,
                "Only constrained site-scoped SharePoint operations are supported.")
        if method != "GET":
            self.assert_write()
        headers = headers or {}
        if headers.get("X-HTTP-Method") == "MERGE":
            require(headers.get("IF-MATCH") and headers["IF-MATCH"] != "*", "Exact SharePoint ETag required.")
        site = self.config["ownerOneDriveSiteUrl"] if personal else self.config["siteUrl"]
        url = self.runtime("shared_sharepointonline") + "/" \
              + quote(self.config["connections"]["shared_sharepointonline"], safe="") \
              + "/datasets/" + quote(quote(site, safe=""), safe="") + "/httprequest"
        payload = {"method": method, "uri": uri, "headers": {"Accept": "application/json;odata=nometadata", **headers}}
        if body is not None:
            payload["body"] = body if isinstance(body, str) else json.dumps(body)
            payload["headers"].setdefault("Content-Type", "application/json;odata=verbose")
        value = self.request("POST", url, "https://apihub.azure.com", payload, read_operation=method == "GET")
        if isinstance(value, dict) and "body" in value:
            value = value["body"]
        if isinstance(value, str):
            try:
                value = json.loads(value)
            except ValueError:
                return value
        return value.get("d", value) if isinstance(value, dict) else value

    def preflight(self):
        c = self.config
        environment = self.request("GET", "https://api.powerapps.com/providers/Microsoft.PowerApps/environments/"
                                   + c["environmentId"] + "?api-version=2016-11-01", "https://service.powerapps.com/")
        require(environment["name"].lower() == c["environmentId"], "Wrong target environment.")
        linked = environment["properties"]["linkedEnvironmentMetadata"]["instanceUrl"]
        require(linked.rstrip("/").lower() == c["dataverseUrl"].lower(), "Dataverse/environment mismatch.")
        graph = "https://graph.microsoft.com"
        profile = self.request("GET", graph + "/v1.0/me?$select=id,mail,userPrincipalName,userType", graph)
        require(profile.get("userType") == "Member" and profile.get("id", "").lower() == self.object_id
                and profile["userPrincipalName"].lower() == c["ownerUpn"].lower() and profile.get("mail"),
                "Installer must be the declared target owner/service user.")
        who = self.dv("GET", "WhoAmI")
        user = self.dv("GET", "systemusers(" + who["UserId"] + ")?$select=systemuserid,azureactivedirectoryobjectid,isdisabled")
        require(user.get("isdisabled") is False
                and user.get("azureactivedirectoryobjectid", "").lower() == profile["id"].lower(),
                "Dataverse owner and authenticated Entra identity differ.")
        profile["systemUserId"] = user["systemuserid"].lower()
        for connector in APIS:
            self.verify_connection(connector, profile)
        self.own_default_drive(profile)
        return profile

    def verify_connection(self, connector, profile=None):
        require(connector in APIS, "Unsupported target connection.")
        c = self.config
        url = "https://api.powerapps.com/providers/Microsoft.PowerApps/apis/" + connector + "/connections/" \
              + quote(c["connections"][connector], safe="") + "?" + urlencode({
                  "api-version": "2016-11-01", "$filter": "environment eq '" + c["environmentId"] + "'"})
        value = self.request("GET", url, "https://service.powerapps.com/")
        p = value["properties"]
        require(value.get("name") == c["connections"][connector]
                and p["environment"]["name"].lower() == c["environmentId"]
                and p["accountName"].lower() == c["ownerUpn"].lower()
                and p.get("apiId", value.get("id", "").split("/connections/")[0]).rsplit("/", 1)[-1] == connector
                and p.get("statuses") and all(v.get("status") == "Connected" for v in p["statuses"]),
                "Wrong/disconnected connector account, instance or environment: " + connector)
        creator = p.get("createdBy", {})
        require(creator.get("id", "").lower() == (profile or {}).get("id", getattr(self, "object_id", "")).lower(),
                "Target connection owner differs from the authenticated owner: " + connector)
        return value

    def own_default_drive(self, profile):
        self.verify_connection("shared_onedriveforbusiness", profile)
        graph = "https://graph.microsoft.com"
        try:
            current = self.request("GET", graph + "/v1.0/me?$select=id,userPrincipalName,userType", graph)
            require(current.get("userType") == "Member" and current.get("id", "").lower() == profile["id"].lower()
                    and current.get("userPrincipalName", "").lower() == self.config["ownerUpn"].lower(),
                    "Own-drive authenticated identity differs.")
            listed = rows(self.request("GET", graph + "/v1.0/me/drives?$select=id,driveType,owner&$top=20", graph))
            owned = {d["id"] for d in listed if d.get("driveType") == "business"
                     and ((d.get("owner") or {}).get("user") or {}).get("id", "").lower() == current["id"].lower()}
            require(owned, "Existing owned business drive is required. No automatic provisioning or ACL fallback.")
            drive = self.request("GET", graph + "/v1.0/me/drive?$select=id,driveType,owner,webUrl", graph)
            require(drive.get("id") in owned and drive.get("driveType") == "business"
                    and ((drive.get("owner") or {}).get("user") or {}).get("id", "").lower() == current["id"].lower(),
                    "Default drive is not the owner's existing business drive.")
            item = self.request("GET", graph + "/v1.0/me/drive/root"
                                "?$select=id,webUrl,parentReference,folder,root,remoteItem,sharepointIds", graph)
        except TargetApiError as error:
            raise ValueError("Own-drive proof unavailable (HTTP " + str(error.status) + "); no fallback.") from None
        require(item.get("id") and isinstance(item.get("folder"), dict) and isinstance(item.get("root"), dict)
                and item.get("remoteItem") is None and (item.get("parentReference") or {}).get("driveId") == drive["id"],
                "Default root is missing, remote, or belongs to a different drive.")
        spids = item.get("sharepointIds") or {}
        require(spids.get("tenantId", "").lower() == self.config["tenantId"]
                and site_url(spids.get("siteUrl")) == site_url(self.config["ownerOneDriveSiteUrl"]),
                "Configured personal site/tenant does not own the default drive.")
        root_url = site_url(item.get("webUrl"))
        require(root_url == site_url(drive.get("webUrl"))
                and root_url.startswith(site_url(self.config["ownerOneDriveSiteUrl"]) + "/"),
                "Default library root does not match the authenticated personal site.")
        return {"driveId": drive["id"], "ownerObjectId": current["id"], "rootItemId": item["id"],
                "siteUrl": site_url(spids["siteUrl"]), "rootUrl": root_url,
                "rootRelativeUrl": unquote(urlsplit(root_url).path),
                "connectionId": self.config["connections"]["shared_onedriveforbusiness"]}

    def own_inbox_item(self, proof):
        name, graph = self.config["manualInboxName"], "https://graph.microsoft.com"
        try:
            item = self.request("GET", graph + "/v1.0/me/drive/root:/" + quote(name, safe="")
                                + "?$select=id,name,webUrl,parentReference,folder,remoteItem,sharepointIds", graph)
        except TargetApiError as error:
            if error.status == 404:
                return None
            raise ValueError("Own Inbox identity proof unavailable; no folder/ACL fallback.") from None
        parent, spids = item.get("parentReference") or {}, item.get("sharepointIds") or {}
        require(item.get("id") and item.get("name") == name and isinstance(item.get("folder"), dict)
                and item.get("remoteItem") is None and parent.get("driveId") == proof["driveId"]
                and parent.get("id") == proof["rootItemId"] and spids.get("tenantId", "").lower() == self.config["tenantId"]
                and site_url(spids.get("siteUrl")) == proof["siteUrl"] and spids.get("listItemUniqueId")
                and site_url(item.get("webUrl")) == proof["rootUrl"] + "/" + name,
                "Inbox must be a physical direct folder in the verified default drive, never a shortcut.")
        return item
