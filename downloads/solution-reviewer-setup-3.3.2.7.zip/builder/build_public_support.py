"""Reproducible public-support projection of the sealed, fully tested support ZIP.

This changes distribution membership and documentation only. It never edits the
solution ZIPs, runtime modules, private tests, or private validation guards.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path
import zipfile


SOURCE_SHA256 = "39a24e5b64269a3bb81cd2e1e4acebadb2b74cc310670f05ae1d6bdede14b7fe"
EXCLUDED = {
    "builder/test_builder.py": "Private synthetic regression tests",
    "builder/validate_candidates.py": "Author-only private-pattern validation scanner",
    "tests/test_import_first.py": "Private synthetic target and connection fixtures",
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=True) + "\n").encode()


def replace_once(data, before, after):
    text = data.decode()
    if "\r\n" in text:
        before = before.replace("\n", "\r\n")
        after = after.replace("\n", "\r\n")
    require(text.count(before) == 1, "Documentation context changed")
    return text.replace(before, after, 1).encode()


def project(source, solutions):
    require(sha(source) == SOURCE_SHA256, "Sealed source support hash mismatch")
    with zipfile.ZipFile(io.BytesIO(source)) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)), "Duplicate source member")
        original = {name: archive.read(name) for name in names}
    index = json.loads(original["FILES.json"])
    require({item["file"] for item in index["files"]} == set(original) - {"FILES.json"},
            "Source file inventory mismatch")
    for item in index["files"]:
        data = original[item["file"]]
        require(sha(data) == item["sha256"] and len(data) == item["bytes"],
                "Source indexed member changed")
    manifest = json.loads(original["release-manifest.json"])
    solution_hashes = []
    for package in manifest["packages"]:
        name = package["file"]
        require(Path(name).name == name, "Solution filename must be a basename")
        require(sha((solutions / name).read_bytes()) == package["sha256"],
                "Immutable solution ZIP hash mismatch")
        solution_hashes.append({"file": name, "sha256": package["sha256"]})
    require(set(EXCLUDED) <= set(original), "Public exclusion policy no longer matches source")
    entries = {name: data for name, data in original.items()
               if name not in EXCLUDED and name != "FILES.json"}
    entries["builder/BUILD.md"] = replace_once(
        entries["builder/BUILD.md"],
        'python -m unittest discover -s . -p "test_*.py" -v\n'
        'python expression_equivalence.py --help\n'
        'python validate_candidates.py --help',
        'python expression_equivalence.py --help')
    entries["builder/BUILD.md"] = replace_once(
        entries["builder/BUILD.md"],
        "The identity scanner consumes a private audit pattern set but emits only counts,",
        "The synthetic regression suites and author-only identity scanner are retained\n"
        "in the private authoring source, not distributed in this public-support ZIP.\n"
        "The unchanged private suites and their retained reports cover the public runtime\n"
        "modules too; the public bundle does not claim to include those test fixtures.\n"
        "The author-only identity scanner consumes a private audit pattern set but emits only counts,")
    entries["INSTALL.md"] = replace_once(
        entries["INSTALL.md"],
        "From the extracted support directory:\n\n```powershell\n"
        '$env:PYTHONDONTWRITEBYTECODE = "1"\n'
        'python -m unittest discover -s .\\tests -p "test_*.py" -v\n'
        "```\n\nTests block real network/auth entry points. Their synthetic fixtures do not claim\n"
        "native service acceptance. Packaging must additionally call `Release` against the\n",
        "This public-support ZIP intentionally excludes synthetic regression fixtures and\n"
        "the author-only privacy scanner. Both remain unchanged in private authoring\n"
        "source with the full validation reports. Runtime ownership, target identity,\n"
        "configuration and activation guards have not been removed or weakened.\n\n"
        "Private tests block real network/auth entry points and do not claim native\n"
        "service acceptance. Packaging must additionally call `Release` against the\n")
    entries["builder/build_public_support.py"] = Path(__file__).read_bytes()
    modified = sorted(name for name in entries if name in original and entries[name] != original[name])
    require(modified == ["INSTALL.md", "builder/BUILD.md"], "Unexpected retained member modification")
    require(all(entries[name] == data for name, data in original.items()
                if name in entries and name.endswith(".py")), "Retained Python code changed")
    policy = {
        "version": "3.3.2.7",
        "revision": "public-r2",
        "sourceSupportSha256": SOURCE_SHA256,
        "excludedMembers": [{"file": name, "reason": reason} for name, reason in sorted(EXCLUDED.items())],
        "documentationAdjusted": modified,
        "allRetainedPythonMembersByteIdentical": True,
        "runtimePrivacyAndAuthorizationGuardsUnchanged": True,
        "privateSourcesAndReportsRetained": True,
        "solutionArchivesReadOnlyAndHashVerified": solution_hashes,
        "approvedPublicDistribution": False,
        "nativeImportAcceptanceClaim": False,
    }
    entries["PUBLIC-SUPPORT-POLICY.json"] = json_bytes(policy)
    entries["FILES.json"] = json_bytes({
        "version": "3.3.2.7", "revision": "public-r2",
        "status": "PUBLIC_REVIEW_CANDIDATE_NO_APPROVAL",
        "files": [{"file": name, "sha256": sha(data), "bytes": len(data)}
                  for name, data in sorted(entries.items())],
    })
    require(not any(name.startswith("tests/") or Path(name).name.startswith("test_") for name in entries),
            "Synthetic tests present in public projection")
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w") as archive:
        for name, data in sorted(entries.items()):
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            info.create_system = 0
            info.external_attr = 0x20
            archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    return buffer.getvalue(), policy, len(entries)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, type=Path, help="Sealed full private support ZIP")
    parser.add_argument("--solutions", required=True, type=Path, help="Immutable solution ZIP directory")
    parser.add_argument("--output", required=True, type=Path, help="New public-support ZIP; never overwritten")
    args = parser.parse_args()
    data, policy, count = project(args.source.read_bytes(), args.solutions)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("xb") as output:
        output.write(data)
    print(json.dumps({"file": args.output.name, "sha256": sha(data), "bytes": len(data),
                      "members": count, "policy": policy}, indent=2))


if __name__ == "__main__":
    main()
