"""Offline-only PSR 3.3.2.7 import-first builder.

No authentication or network operations. All private source paths are explicit CLI
inputs and are never emitted into distributable files. PAC is used only for local
solution unpack/pack/create-settings. Native dynamic-table serialization is retained.
"""
import argparse
import copy
import ctypes
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
from urllib.parse import quote
from xml.etree import ElementTree as ET
import zipfile

import yaml

VERSION = "3.3.2.7"
DESCRIPTION = "PSR import-first release " + VERSION
SOURCE_HASHES = {
    "reviewer": "6ffe125f8459b2ec343cf1a31a8f2e41e0cad8d72a5be46b83daa2c565d39c50",
    "automation": "7eccd5c7c64ea7472de908f7e97ea7d08ba03a4bc1742a956f74993914d735b3",
}
OVERLAY_SHA = "acea5101fb52bf4a00af86ba51c5e14631b142b9c6177ae72b19da2c10b428b6"
TEMPLATE_SHA = "498ee9eb6d1fbd9df4fa719a873fa57237fdbf224fcb6c62c77c96881bac3065"
PRIOR_BUNDLE_SHA = "26540297fcd6590845f4b1f32ab7a7278233a74c420c8c9843d6075e237cc849"
TOKEN = re.compile(r"__PSR_([A-Z0-9_]+?)__")
CONSTANTS = {
    "MODEL_NAME": "GPT5Chat",
    "MANUAL_INBOX_NAME": "PowerPlatformSolutionReviewInbox",
    "WORD_SOURCE": "me",
    "WORD_KEY_IDENTITY": "940007",
    "WORD_KEY_BLOCKS": "940008",
    "WORD_KEY_STAMP": "940009",
    "WORD_KEY_NOTES": "940010",
}


def require(test, message):
    if not test:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(value):
    return sha(json.dumps(value, sort_keys=True, ensure_ascii=True).encode())


def write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")


def flatten(actions):
    result = {}
    for name, action in actions.items():
        require(name not in result, "Duplicate action name")
        result[name] = action
        for slot in ("actions", "else", "default", "cases"):
            value = action.get(slot, {})
            groups = [value] if slot == "actions" else (
                [case.get("actions", {}) for case in value.values()] if slot == "cases"
                else [value.get("actions", {})])
            for group in groups:
                child = flatten(group)
                require(not result.keys() & child.keys(), "Duplicate nested action name")
                result.update(child)
    return result


def tree_map(value, transform):
    if isinstance(value, dict):
        return {transform(key): tree_map(item, transform) for key, item in value.items()}
    if isinstance(value, list):
        return [tree_map(item, transform) for item in value]
    return transform(value) if isinstance(value, str) else value


def constants(text):
    return TOKEN.sub(lambda m: CONSTANTS.get(m[1], m[0]), text)


def literal(text):
    return "'" + text.replace("'", "''") + "'"


def concat(parts):
    require(bool(parts), "Empty expression")
    return parts[0] if len(parts) == 1 else "concat(" + ",".join(parts) + ")"


def token_parts(text, used):
    """Convert a literal to expression fragments, with no target values embedded."""
    parts, start = [], 0
    for match in TOKEN.finditer(text):
        if match.start() > start:
            parts.append(literal(text[start:match.start()]))
        used.add(match[1])
        parts.append("parameters('psr_" + match[1] + "')")
        start = match.end()
    if start < len(text):
        parts.append(literal(text[start:]))
    return parts or [literal("")]


def expression(text, used):
    """Rewrite WDL quoted literals only. Doubled apostrophes are decoded correctly."""
    output, i = [], 0
    while i < len(text):
        if text[i] != "'":
            require(not text.startswith("__PSR_", i), "Token outside WDL literal")
            output.append(text[i])
            i += 1
            continue
        begin = i
        i += 1
        chars = []
        while i < len(text):
            if text[i] == "'":
                if i + 1 < len(text) and text[i + 1] == "'":
                    chars.append("'")
                    i += 2
                    continue
                i += 1
                break
            chars.append(text[i])
            i += 1
        else:
            raise ValueError("Unclosed WDL literal")
        value = "".join(chars)
        output.append(concat(token_parts(value, used)) if TOKEN.search(value) else text[begin:i])
    return "".join(output)


def bind_string(text, used):
    """Turn template VALUES into native env-var parameters, never property names."""
    if not TOKEN.search(text):
        return text
    if text.startswith("@") and not text.startswith("@{") and not text.startswith("@@"):
        return "@" + expression(text[1:], used)
    parts, i, begin = [], 0, 0
    while i < len(text):
        if not text.startswith("@{", i):
            i += 1
            continue
        if begin < i:
            parts.extend(token_parts(text[begin:i], used))
        i += 2
        start, quoted, depth = i, False, 1
        while i < len(text) and depth:
            char = text[i]
            if char == "'":
                if quoted and i + 1 < len(text) and text[i + 1] == "'":
                    i += 2
                    continue
                quoted = not quoted
            elif not quoted:
                if char == "{":
                    depth += 1
                elif char == "}":
                    depth -= 1
            i += 1
        require(depth == 0 and not quoted, "Unclosed WDL interpolation")
        parts.append("string(" + expression(text[start:i-1], used) + ")")
        begin = i
    if begin < len(text):
        parts.extend(token_parts(text[begin:], used))
    return "@" + concat(parts)


def bind_tree(value, used, changes, path=""):
    if isinstance(value, dict):
        require(not any(TOKEN.search(k) for k in value), "Unrestored schema key at " + path)
        return {k: bind_tree(v, used, changes, path + "/" + k) for k, v in value.items()}
    if isinstance(value, list):
        return [bind_tree(v, used, changes, path + "/" + str(i)) for i, v in enumerate(value)]
    if isinstance(value, str):
        target = bind_string(value, used)
        if target != value:
            changes.append({"path": path, "beforeSha256": sha(value.encode()),
                            "afterSha256": sha(target.encode()), "tokens": sorted(set(TOKEN.findall(value))),
                            "transformation": "WDL literal/interpolation to native environment-variable parameter"})
        return target
    return value


def prior_normalize(data, private_map, site, flow_kind):
    """Replay the historical audited source-binding transform; no arbitrary edits."""
    variants = {}
    for old, name in private_map.items():
        for value in (old, quote(old, safe=""), quote(quote(old, safe=""), safe="")):
            variants[value] = "__PSR_" + name + "__"

    def transform(text):
        for old, replacement in sorted(variants.items(), key=lambda x: -len(x[0])):
            text = re.sub(re.escape(old), lambda _: replacement, text, flags=re.I)
        return text

    transformed = tree_map(data, transform)
    definition = transformed["properties"]["definition"]
    actions = flatten(definition["actions"])
    if flow_kind == "automation":
        changes = 0
        for action in actions.values():
            value = action.get("expression")
            if not isinstance(value, str):
                continue
            for prefix in ("?['Member']?['Id'],", "?['AuthorId'],"):
                old = prefix + str(site["verifiedOwner"]["siteUserId"]) + ")"
                changes += value.count(old)
                value = value.replace(old, prefix + "int('__PSR_OWNER_SP_ID__'))")
            action["expression"] = value
        require(changes == 5, "Source principal guard drift")
        for name in ("GetControl", "GetEmailControl"):
            params = actions[name]["inputs"]["parameters"]
            old = "/items(" + str(site["control"]["itemId"]) + ")"
            require(old in params["parameters/uri"], "Native control item drift")
            params["parameters/uri"] = params["parameters/uri"].replace(old, "/items(__PSR_CONTROL_ITEM_ID__)")
        for name, expression_old, expression_new in (
                ("ValidateDirectoryUser", "body('ResolveUploader')?['mail'],'')),'__PSR_OWNER_UPN__'",
                 "body('ResolveUploader')?['mail'],'')),'__PSR_OWNER_MAIL__'"),
                ("ValidateUploaderClaim", "body('LookupUploader')?['Email'],'')),'__PSR_OWNER_UPN__'",
                 "body('LookupUploader')?['Email'],'')),'__PSR_OWNER_SP_EMAIL__'")):
            actions[name]["expression"] = actions[name]["expression"].replace(expression_old, expression_new)
        actions["ResolveUploader"]["inputs"]["parameters"]["id"] = "__PSR_OWNER_UPN__"
        for action in actions.values():
            inputs = action.get("inputs")
            params = inputs.get("parameters", {}) if isinstance(inputs, dict) else {}
            if "Copilot" in params:
                params["Copilot"] = "__PSR_AGENT_PICKER__"
        actions["CoverageDocument"]["inputs"]["agentPublishedOnAtDeployment"] = "__PSR_AGENT_PUBLISHED_UTC__"
        definition["parameters"]["psrDeploymentReady"] = {"type": "Bool", "defaultValue": False}
        definition["triggers"]["WhenNewPackageCreated"]["conditions"].append({
            "expression": "@equals(parameters('psrDeploymentReady'),true)"})
    if flow_kind in ("automation", "word"):
        populate = actions["PopulateCurrentReviewWord"]
        params = populate["inputs"]["parameters"]
        params["source"] = "__PSR_WORD_SOURCE__"
        for field, name in (("940007", "WORD_KEY_IDENTITY"), ("940008", "WORD_KEY_BLOCKS"),
                            ("940009", "WORD_KEY_STAMP"), ("940010", "WORD_KEY_NOTES")):
            params["dynamicFileSchema/__PSR_" + name + "__"] = params.pop("dynamicFileSchema/" + field)
        for key in list(populate.get("metadata", {})):
            if key == "__PSR_WORD_FILE__":
                populate["metadata"][key] = "__PSR_WORD_TEMPLATE_NAME__"
    return transformed


def safe_extract(archive, destination):
    with zipfile.ZipFile(archive) as z:
        for name in z.namelist():
            require(not Path(name).is_absolute() and ".." not in Path(name).parts, "Unsafe archive member")
        z.extractall(destination)


def deterministic_zip(archive):
    """Normalize only ZIP container metadata, preserving every PAC member byte."""
    with zipfile.ZipFile(archive) as source:
        entries = {name: source.read(name) for name in source.namelist()}
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
        for name, data in sorted(entries.items()):
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 0
            info.external_attr = 0x20
            target.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    archive.write_bytes(buffer.getvalue())
    with zipfile.ZipFile(archive) as target:
        require(entries == {n: target.read(n) for n in target.namelist()}, "ZIP member bytes altered")


def env_definition(folder, name):
    schema = "psr_" + name
    root = ET.Element("environmentvariabledefinition", schemaname=schema)
    description = ("Post-import installation ownership. Set only by validated setup; not authorization."
                   if name == "INSTALLATION_ID"
                   else "Target configuration: " + name + ". Configure after import; not authorization.")
    for tag, value in (("description", description), ("displayname", "PSR " + name.replace("_", " "))):
        el = ET.SubElement(root, tag, default=value)
        ET.SubElement(el, "label", description=value, languagecode="1033")
    for tag, value in (("introducedversion", VERSION), ("iscustomizable", "1"), ("isrequired", "0"),
                       ("secretstore", "0"), ("type", "100000000")):
        ET.SubElement(root, tag).text = value
    path = folder / "environmentvariabledefinitions" / schema / "environmentvariabledefinition.xml"
    path.parent.mkdir(parents=True, exist_ok=True)
    ET.indent(root)
    # Native source-control record files are XML element fragments. A leading
    # XmlDeclaration is a different DOM node and cannot be appended as a child
    # element by record importers. Preserve the native declaration-free shape.
    ET.ElementTree(root).write(path, encoding="utf-8", xml_declaration=False)


def run_pac(pac, *args):
    def cli_path(value):
        if not isinstance(value, Path):
            return str(value)
        path = value.resolve()
        if os.name != "nt":
            return str(path)
        suffix = []
        while not path.exists():
            suffix.insert(0, path.name)
            path = path.parent
        buffer = ctypes.create_unicode_buffer(32768)
        result = ctypes.windll.kernel32.GetShortPathNameW(str(path), buffer, len(buffer))
        require(result > 0, "Windows short-path lookup failed")
        return str(Path(buffer.value).joinpath(*suffix))
    command = [cli_path(Path(pac)), "solution", *map(cli_path, args)]
    if Path(pac).suffix.lower() in (".cmd", ".bat"):
        # Windows invokes this explicit installed CLI wrapper; never changes auth.
        command = subprocess.list2cmdline(command)
    result = subprocess.run(command, text=True, capture_output=True)
    require(result.returncode == 0 and not re.search(r"(?im)^Error:", result.stdout + result.stderr),
            "Local PAC failed:\n" + result.stdout + result.stderr)
    return result.stdout


def normalized_xml(data):
    root = ET.fromstring(data)
    def node(el):
        return [el.tag, dict(el.attrib), (el.text or "").strip(), [node(c) for c in el]]
    return node(root)


def existing_short_path(path):
    """Use an alias for this same directory, never a junction outside the worktree."""
    if os.name != "nt":
        return path
    buffer = ctypes.create_unicode_buffer(32768)
    result = ctypes.windll.kernel32.GetShortPathNameW(str(path.resolve()), buffer, len(buffer))
    require(result > 0, "Windows path alias unavailable")
    return Path(buffer.value)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prior-bundle", required=True, type=Path)
    parser.add_argument("--native-exports", required=True, type=Path)
    parser.add_argument("--overlay", required=True, type=Path)
    parser.add_argument("--private-token-map", required=True, type=Path)
    parser.add_argument("--source-site", required=True, type=Path)
    parser.add_argument("--pac", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--scratch", required=True, type=Path)
    args = parser.parse_args()
    require(not args.out.exists(), "Output already exists. Frozen candidates are never overwritten.")
    require(not args.scratch.exists(), "Use fresh private scratch directory.")
    args.out.mkdir(parents=True)
    args.scratch.mkdir(parents=True)
    args.out = existing_short_path(args.out)
    args.scratch = existing_short_path(args.scratch)
    require(sha(args.prior_bundle.read_bytes()) == PRIOR_BUNDLE_SHA, "Historical bundle hash changed")
    previous = args.scratch / "previous"
    safe_extract(args.prior_bundle, previous)
    manifest = read(previous / "install-manifest.json")
    require(manifest["version"] == "3.3.2.6", "Wrong historical source release")
    inventory = read(args.native_exports / "native-archive-inventory.json")
    comparison = read(args.native_exports / "exact-native-source-comparison.json")
    membership = read(args.native_exports / "before-current-native-state.json")
    require(comparison["allCurrentDraftComponentsIncluded"] and
            comparison["allNativeFlowDefinitionsAndReferencesMatch"], "Native baseline not verified")
    private_map = read(args.private_token_map)
    site = read(args.source_site)
    require(sha(args.overlay.read_bytes()) == OVERLAY_SHA, "Sealed automatic overlay changed")
    overlay = read(args.overlay)
    require(len(flatten(overlay["actions"])) == 500, "Not complete automatic candidate")
    template = previous / "current-review-v4.3.1.web.template.docx"
    require(sha(template.read_bytes()) == TEMPLATE_SHA, "Template bytes changed")
    packages, byte_report, action_report, binding_report, env_inventory, components, references = [], [], [], [], {}, [], {}
    pac_log = []
    for spec in manifest["packages"]:
        kind = spec["kind"]
        prior_zip = previous / spec["file"]
        require(sha(prior_zip.read_bytes()) == spec["sha256"], "Historical ZIP hash changed")
        native = args.native_exports / Path(inventory[kind]["receipt"]["path"]).name
        require(sha(native.read_bytes()) == SOURCE_HASHES[kind], "Native export hash changed")
        with zipfile.ZipFile(native) as archive:
            native_members = {n: archive.read(n) for n in archive.namelist()}
        out = args.scratch / (kind + "-unpacked")
        pac_log.append(run_pac(args.pac, "unpack", "--zipfile", prior_zip, "--folder", out,
                               "--packagetype", "Unmanaged", "--errorlevel", "Warning"))
        original_members = {p.relative_to(out).as_posix(): p.read_bytes() for p in out.rglob("*") if p.is_file()}
        envs = set()
        workflows = []
        for wf in spec["workflows"]:
            relative = wf["workflowFile"].replace("\\", "/")
            path = out / relative
            data = read(path)
            native_data = json.loads(native_members[relative])
            baseline = copy.deepcopy(native_data)
            if kind == "automation":
                baseline["properties"]["definition"] = copy.deepcopy(overlay)
                baseline["properties"]["connectionReferences"]["shared_wordonlinebusiness"] = {
                    "runtimeSource": "embedded", "api": {"name": "shared_wordonlinebusiness"},
                    "connection": {"connectionReferenceLogicalName": "psr_AutoReview_Word"}}
            normalized = prior_normalize(baseline, private_map, site, wf["kind"])
            require(normalized == data, "Unexplained native-to-historical difference: " + wf["kind"])
            restored = tree_map(data, constants)
            require(not any(TOKEN.search(k) for k in flatten(restored["properties"]["definition"]["actions"])),
                    "Action identifier altered")
            changes, used = [], set()
            target = bind_tree(restored, used, changes)
            definition = target["properties"]["definition"]
            for token in sorted(used):
                definition["parameters"]["psr_" + token] = {
                    "defaultValue": "", "type": "String", "metadata": {"schemaName": "psr_" + token}}
            require(len(flatten(definition["actions"])) == wf["actionCount"], "Action loss")
            require(target["properties"]["connectionReferences"] == baseline["properties"]["connectionReferences"],
                    "Connection mode/reference mutation")
            envs.update(used)
            write(path, target)
            before_actions = flatten(restored["properties"]["definition"]["actions"])
            after_actions = flatten(definition["actions"])
            for name, action in before_actions.items():
                new = after_actions[name]
                # Structural equality is exact: independently perform value-only transformation.
                test = bind_tree(action, set(), [])
                require(test == new, "Unapproved action edit")
                action_report.append({
                    "flow": wf["kind"], "action": name, "type": action["type"],
                    "sourceSha256": digest(action), "targetSha256": digest(new),
                    "equalAfterDeclaredValueTransform": True,
                    "runAfterPreserved": action.get("runAfter") == new.get("runAfter"),
                    "retryPolicyPreserved": (action.get("inputs", {}).get("retryPolicy")
                                            if isinstance(action.get("inputs"), dict) else None) ==
                                           (new.get("inputs", {}).get("retryPolicy")
                                            if isinstance(new.get("inputs"), dict) else None)})
            binding_report.extend(dict(flow=wf["kind"], **c) for c in changes)
            workflows.append(dict(wf, workflowFile=relative,
                                  definitionSha256=digest(definition),
                                  sourceNativeDefinitionSha256=digest(native_data["properties"]["definition"]),
                                  sourceOverlayDefinitionSha256=digest(baseline["properties"]["definition"]),
                                  environmentVariables=sorted("psr_" + t for t in used)))
        for path in (out / "botcomponents").glob("*/data"):
            text = path.read_text(encoding="utf-8-sig")
            fixed = constants(text)
            require(not TOKEN.search(fixed), "Non-native YAML placeholder remains")
            if fixed != text:
                path.write_text(fixed, encoding="utf-8")
            native_data = yaml.safe_load(native_members[path.relative_to(out).as_posix()])
            target_data = yaml.safe_load(fixed)
            if target_data.get("kind") == "GptComponentMetadata":
                require(target_data == native_data and target_data["aISettings"]["model"] == {"modelNameHint": "GPT5Chat"},
                        "GPT differs from authenticated native model")
            elif ".topic.ReviewTrustedExport/" in path.as_posix():
                expected = copy.deepcopy(native_data)
                for action in expected["beginDialog"]["actions"]:
                    if action.get("id") == "ExplainPrivateIntake":
                        original = action["activity"]
                        action["activity"] = ("Use your own authorized private OneDrive account. " +
                                              original[original.index("Open [your OneDrive for Business]"):])
                require(target_data == expected, "Intake changed beyond prior approved generic message")
            else:
                require(target_data == native_data, "Native botcomponent logic changed")
            meta = ET.parse(path.parent / "botcomponent.xml").getroot()
            components.append({"schemaName": meta.get("schemaname"), "kind": target_data["kind"],
                               "componentType": int(meta.findtext("componenttype")),
                               "sourceSha256": sha(native_members[path.relative_to(out).as_posix()]),
                               "candidateSha256": sha(path.read_bytes()),
                               "dataFile": path.relative_to(out).as_posix(),
                               "nativeSemanticEquality": target_data == native_data,
                               "allowedDifference": None if target_data == native_data else "Existing generic private-intake instruction only"})
        # Restore fixed supported model string in descriptive workflow metadata too.
        for path in out.rglob("*.xml"):
            text = path.read_text(encoding="utf-8-sig")
            fixed = constants(text)
            if text != fixed:
                path.write_text(fixed, encoding="utf-8")
        solution_path = out / "Other/Solution.xml"
        solution = ET.parse(solution_path)
        root = solution.find("SolutionManifest")
        root.find("Version").text = VERSION
        root.find("Descriptions").clear()
        ET.SubElement(root.find("Descriptions"), "Description", description=DESCRIPTION, languagecode="1033")
        # The actual native export uses dynamic-table files, not guessed bot root codes.
        original_roots = [dict(e.attrib) for e in root.find("RootComponents")]
        require(original_roots == comparison["solutions"][kind]["rootComponents"], "Native roots drift")
        if kind == "reviewer":
            envs.add("INSTALLATION_ID")
        for name in sorted(envs):
            env_definition(out, name)
            ET.SubElement(root.find("RootComponents"), "RootComponent", type="380",
                          schemaName="psr_" + name, behavior="0")
            entry = env_inventory.setdefault(name, {"token": name, "schemaName": "psr_" + name,
                                                    "type": "String", "defaultValue": None, "packages": []})
            entry["packages"].append(kind)
        solution.write(solution_path, encoding="utf-8", xml_declaration=True)
        custom = ET.parse(out / "Other/Customizations.xml")
        for ref in custom.findall(".//connectionreference"):
            name = ref.get("connectionreferencelogicalname")
            require(ref.find("connectionid") is None, "Bound source connection")
            record = references.setdefault(name, {"logicalName": name, "connectorId": ref.findtext("connectorid"),
                                                  "packages": [], "binding": "unbound"})
            require(record["connectorId"] == ref.findtext("connectorid"), "Reference connector mismatch")
            record["packages"].append(kind)
        for file in sorted(p for p in out.rglob("*") if p.is_file()):
            relative = file.relative_to(out).as_posix()
            data = file.read_bytes()
            text = data.decode("utf-8-sig")
            require(not TOKEN.search(text), "Unresolved token: " + relative)
            for old in private_map:
                if old in CONSTANTS.values():
                    continue
                require(old.casefold() not in text.casefold(), "Source target identity remains in " + relative)
            require(not re.search(r"(?:sig|access_token|sharedaccesssignature)=[A-Za-z0-9%]", text, re.I),
                    "Credential-like value")
            old = original_members.get(relative)
            byte_report.append({"package": kind, "file": relative, "beforeSha256": sha(old) if old else None,
                                "afterSha256": sha(data), "byteIdenticalToHistorical": old == data,
                                "source": "native-derived historical release" if old else "new native env-variable definition"})
        name = root.findtext("UniqueName")
        filename = name + "_3_3_2_7_unmanaged.zip"
        archive = args.out / filename
        pac_log.append(run_pac(args.pac, "pack", "--zipfile", archive, "--folder", out,
                               "--packagetype", "Unmanaged", "--errorlevel", "Warning"))
        deterministic_zip(archive)
        roundtrip = args.scratch / (kind + "-roundtrip")
        pac_log.append(run_pac(args.pac, "unpack", "--zipfile", archive, "--folder", roundtrip,
                               "--packagetype", "Unmanaged", "--errorlevel", "Warning"))
        members = {p.relative_to(out).as_posix(): p for p in out.rglob("*") if p.is_file()}
        after = {p.relative_to(roundtrip).as_posix(): p for p in roundtrip.rglob("*") if p.is_file()}
        require(members.keys() == after.keys(), "PAC roundtrip lost members")
        for name, before in members.items():
            data, target = before.read_bytes(), after[name].read_bytes()
            if name.endswith(".xml"):
                require(normalized_xml(data) == normalized_xml(target), "PAC changed XML: " + name)
            elif name.endswith(".json"):
                require(json.loads(data) == json.loads(target), "PAC changed JSON: " + name)
            else:
                require(data == target, "PAC changed component body: " + name)
        settings = args.out / (kind + ".settings.json")
        pac_log.append(run_pac(args.pac, "create-settings", "--solution-zip", archive, "--settings-file", settings))
        setup = read(settings)
        require(all(not ref["ConnectionId"] for ref in setup["ConnectionReferences"]), "Bound settings")
        require(all(not e.get("Value") for e in setup.get("EnvironmentVariables", [])), "Default target value")
        # PAC emits a zero AadGroupId as a UI prompt. This is not a real audience
        # and must not be distributed as a fake target. Audience is verified
        # separately after import; settings here contain only genuinely unbound refs.
        setup.pop("CopilotAgents", None)
        write(settings, setup)
        packages.append({"kind": kind, "solutionName": root.findtext("UniqueName"), "file": filename,
                         "sha256": sha(archive.read_bytes()), "workflows": workflows,
                         "settings": settings.name, "nativeCrossTenantImportTested": False,
                         "sourceType": "COMPLETE_NATIVE_DERIVED_IMPORT_FIRST_CANDIDATE",
                         "nativeRootComponentsPreserved": original_roots})
    require(len(components) == 19, "Missing native botcomponents")
    require(len(references) == 8 and len({r["connectorId"] for r in references.values()}) == 6, "Reference inventory mismatch")
    model = {
        "version": VERSION, "status": "OFFLINE_CANDIDATE_NATIVE_IMPORT_NOT_TESTED",
        "releaseDescription": DESCRIPTION, "agentSchema": manifest["agentSchema"],
        "activationParameter": manifest["activationParameter"],
        "controlContractVersion": manifest["controlContractVersion"],
        "kernelSelector": "kernel-selector.json", "kernelSha256": manifest["kernelSha256"],
        "sourceEnvironmentIdSha256": manifest["sourceEnvironmentIdSha256"],
        "packages": packages, "environmentVariables": sorted(env_inventory.values(), key=lambda x: x["schemaName"]),
        "components": components, "connectionReferences": sorted(references.values(), key=lambda x: x["logicalName"]),
        "word": dict(manifest["word"], nativeAutomaticOutputTested=False),
        "constants": CONSTANTS, "sourceArchivesSha256": SOURCE_HASHES,
        "automaticOverlaySha256": OVERLAY_SHA, "previousBundleSha256": sha(args.prior_bundle.read_bytes()),
        "nativeMembershipReconciliation": {
            "nativeReviewerWorkflowRoots": 2, "nativeReviewerBotMembers": 1,
            "nativeReviewerBotComponentMembers": 19, "nativeReviewerReferenceMembers": 4,
            "nativeReviewerDependencyMembers": 4,
            "serialization": "Authentic native bots, botcomponents, Assets and connectionreferences preserved. Native export itself omits dynamic-table members from RootComponents. No environment-specific type codes or fabricated bot GUIDs inserted.",
            "targetMembershipCheckedBySetup": True,
            "targetMembershipVerified": False,
        },
        "validation": {"pacPackUnpack": True, "nativeImport": "NOT RUN", "nativeRuntime": "NOT RUN",
                       "publicationApproval": "NOT REQUESTED OR GRANTED"},
    }
    # Native membership counts are independently checked against source identities.
    component_ids = {c["botcomponentid"] for c in membership["components"]}
    member_ids = {m["objectid"] for m in membership["memberships"]}
    require(component_ids <= member_ids and membership["agent"]["botid"] in member_ids, "Native bot membership missing")
    write(args.out / "release-manifest.json", model)
    write(args.out / "component-inventory.json", {"botSchema": manifest["agentSchema"], "components": components,
                                                "membership": model["nativeMembershipReconciliation"]})
    write(args.out / "connection-inventory.json", model["connectionReferences"])
    write(args.out / "environment-variable-inventory.json", model["environmentVariables"])
    write(args.out / "transformed-byte-report.json", byte_report)
    write(args.out / "action-equivalence-report.json", {"status": "VALUE_TRANSFORM_EQUIVALENCE_OFFLINE_ONLY",
                                                      "nativeToHistoricalReplayExact": True,
                                                      "actions": action_report, "bindings": binding_report})
    write(args.scratch / "pac-results.private.json", pac_log)
    for name in ("kernel-selector.json", "current-review-v4.3.1.web.template.docx"):
        shutil.copyfile(previous / name, args.out / name)
    print(json.dumps({"status": model["status"], "packages": packages,
                      "actionCount": len(action_report), "environmentVariables": len(env_inventory)}, indent=2))


if __name__ == "__main__":
    main()
