"""Independent symbolic WDL check of every rewritten value (no WDL execution claim).

Unlike the builder this parses complete WDL calls and property/index lookups.
It substitutes probe strings into parameters, folds literal concatenation, and
compares the normalized AST with the original template value. Unknown runtime
calls/variables remain symbolic and must match exactly.
"""
import argparse
import copy
import json
from pathlib import Path
import re
import zipfile

from build_release import read, write, require, constants, tree_map, digest, TOKEN


class Parser:
    def __init__(self, text):
        self.text, self.i = text, 0

    def ws(self):
        while self.i < len(self.text) and self.text[self.i].isspace():
            self.i += 1

    def expect(self, char):
        self.ws()
        require(self.text.startswith(char, self.i), "Unexpected WDL grammar")
        self.i += len(char)

    def value(self):
        self.ws()
        require(self.i < len(self.text), "Incomplete WDL expression")
        if self.text[self.i] == "'":
            self.i += 1
            chars = []
            while self.i < len(self.text):
                char = self.text[self.i]
                self.i += 1
                if char != "'":
                    chars.append(char)
                    continue
                if self.text.startswith("'", self.i):
                    chars.append("'")
                    self.i += 1
                    continue
                node = ("literal", "".join(chars))
                break
            else:
                raise ValueError("Unclosed WDL quoted string")
        else:
            match = re.match(r"-?\d+(?:\.\d+)?|[a-zA-Z_$][a-zA-Z0-9_$]*", self.text[self.i:])
            require(match is not None, "Unknown WDL operand")
            name = match[0]
            self.i += len(name)
            self.ws()
            if self.text.startswith("(", self.i):
                self.i += 1
                args = []
                self.ws()
                if not self.text.startswith(")", self.i):
                    while True:
                        args.append(self.value())
                        self.ws()
                        if not self.text.startswith(",", self.i):
                            break
                        self.i += 1
                self.expect(")")
                node = ("call", name.lower(), tuple(args))
            else:
                node = ("atom", name)
        while True:
            self.ws()
            optional = self.text.startswith("?", self.i)
            if optional:
                self.i += 1
            if self.text.startswith("[", self.i):
                self.i += 1
                key = self.value()
                self.expect("]")
                node = ("get", node, key, optional)
            elif self.text.startswith(".", self.i):
                self.i += 1
                name = re.match(r"[a-zA-Z_$][a-zA-Z0-9_$]*", self.text[self.i:])
                require(name is not None, "Invalid WDL property")
                self.i += len(name[0])
                node = ("get", node, ("literal", name[0]), optional)
            else:
                require(not optional, "Dangling WDL optional selector")
                break
        return node

    def parse(self):
        result = self.value()
        self.ws()
        require(self.i == len(self.text), "Trailing WDL text")
        return result


def value_ast(text):
    if text.startswith("@") and not text.startswith("@{") and not text.startswith("@@"):
        return Parser(text[1:]).parse()
    parts, start, i = [], 0, 0
    while i < len(text):
        if not text.startswith("@{", i):
            i += 1
            continue
        if start != i:
            parts.append(("literal", text[start:i]))
        parser = Parser(text[i + 2:])
        expression = parser.value()
        parser.expect("}")
        parts.append(("call", "string", (expression,)))
        i += 2 + parser.i
        start = i
    if start < len(text):
        parts.append(("literal", text[start:]))
    return ("call", "concat", tuple(parts)) if parts else ("literal", "")


def normalize(node, probe, template=False):
    kind = node[0]
    if kind == "literal":
        value = TOKEN.sub(lambda m: probe[m[1]], node[1]) if template else node[1]
        return (kind, value)
    if kind == "atom":
        return node
    if kind == "get":
        return (kind, normalize(node[1], probe, template), normalize(node[2], probe, template), node[3])
    name, args = node[1], tuple(normalize(x, probe, template) for x in node[2])
    if name == "parameters" and len(args) == 1 and args[0][0] == "literal" and args[0][1].startswith("psr_"):
        return ("literal", probe[args[0][1][4:]])
    if name == "string" and len(args) == 1 and args[0][0] == "literal":
        return args[0]
    if name != "concat":
        return (kind, name, args)
    merged = []
    for arg in args:
        children = arg[2] if arg[:2] == ("call", "concat") else (arg,)
        for child in children:
            if merged and merged[-1][0] == "literal" and child[0] == "literal":
                merged[-1] = ("literal", merged[-1][1] + child[1])
            else:
                merged.append(child)
    return merged[0] if len(merged) == 1 else ("call", name, tuple(merged))


def walk(before, after, probe, output, path=""):
    if isinstance(before, dict):
        require(isinstance(after, dict) and before.keys() == after.keys(), "Object fields changed: " + path)
        for key, value in before.items():
            walk(value, after[key], probe, output, path + "/" + key)
    elif isinstance(before, list):
        require(isinstance(after, list) and len(before) == len(after), "Array changed: " + path)
        for i, value in enumerate(before):
            walk(value, after[i], probe, output, path + "/" + str(i))
    elif before != after:
        require(isinstance(before, str) and isinstance(after, str), "Nonstring mutation")
        left = normalize(value_ast(before), probe, template=True)
        right = normalize(value_ast(after), probe)
        require(left == right, "Independent symbolic equivalence failed at " + path)
        output.append({"path": path, "sourceAstSha256": digest(left),
                       "targetAstSha256": digest(right), "equal": True})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidates", required=True, type=Path)
    parser.add_argument("--prior-bundle", required=True, type=Path)
    parser.add_argument("--report", required=True, type=Path)
    args = parser.parse_args()
    manifest = read(args.candidates / "release-manifest.json")
    probe = {v["token"]: "probe/" + v["token"] + "'&%27" for v in manifest["environmentVariables"]}
    findings = []
    with zipfile.ZipFile(args.prior_bundle) as source:
        old_manifest = json.loads(source.read("install-manifest.json"))
        for package in manifest["packages"]:
            old = next(p for p in old_manifest["packages"] if p["kind"] == package["kind"])
            import io
            with zipfile.ZipFile(io.BytesIO(source.read(old["file"]))) as prior, \
                    zipfile.ZipFile(args.candidates / package["file"]) as target:
                for wf in package["workflows"]:
                    before = tree_map(json.loads(prior.read(wf["workflowFile"])), constants)
                    after = json.loads(target.read(wf["workflowFile"]))
                    for key in list(after["properties"]["definition"]["parameters"]):
                        if key.startswith("psr_"):
                            val = after["properties"]["definition"]["parameters"].pop(key)
                            require(val == {"defaultValue": "", "type": "String",
                                            "metadata": {"schemaName": key}}, "Unexpected environment parameter")
                    flow = []
                    walk(before, after, probe, flow)
                    findings.append({"flow": wf["kind"], "changedValues": len(flow),
                                     "fullDefinitionAndReferencesPreservedAfterBindings": True, "values": flow})
    write(args.report, {"status": "PASS_INDEPENDENT_SYMBOLIC_CHECK", "flows": findings,
                        "probeIncludesQuoteAmpersandSlashAndPercent": True,
                        "nativeExpressionEvaluation": "NOT RUN",
                        "scope": "All changed strings independently parsed; unchanged fields exact, new parameters checked; native connector resolution not tested."})
    print(json.dumps({"status": "PASS_INDEPENDENT_SYMBOLIC_CHECK",
                      "changedValues": sum(x["changedValues"] for x in findings)}, indent=2))


if __name__ == "__main__":
    main()
