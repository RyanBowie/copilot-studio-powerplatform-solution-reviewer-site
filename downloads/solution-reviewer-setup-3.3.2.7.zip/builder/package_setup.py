"""Seal supplementary support, inventories and reproducible builder; no private inputs."""
import argparse
import io
import json
from pathlib import Path
import subprocess
import sys
import zipfile

from build_release import SOURCE_HASHES, OVERLAY_SHA, TEMPLATE_SHA, read, write, sha, digest, require, flatten, deterministic_zip


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--candidates", type=Path, help="Separate candidate revision directory; defaults to root/candidates")
    parser.add_argument("--native-exports", required=True, type=Path)
    parser.add_argument("--overlay", required=True, type=Path)
    parser.add_argument("--repro", required=True, type=Path)
    args = parser.parse_args()
    root = args.root
    candidates = args.candidates or root / "candidates"
    manifest = read(candidates / "release-manifest.json")
    native_inventory = read(args.native_exports / "native-archive-inventory.json")
    overlay = read(args.overlay)
    require(sha(args.overlay.read_bytes()) == OVERLAY_SHA, "Overlay source changed")
    repro, members, native_delta = [], [], []
    for package in manifest["packages"]:
        name = package["file"]
        data = (candidates / name).read_bytes()
        require(sha(data) == package["sha256"], "Immutable ZIP changed")
        require(data == (args.repro / name).read_bytes(), "ZIP not bit reproducible")
        repro.append({"file": name, "sha256": sha(data), "separateBuildByteIdentical": True})
        native_path = args.native_exports / Path(native_inventory[package["kind"]]["receipt"]["path"]).name
        require(sha(native_path.read_bytes()) == SOURCE_HASHES[package["kind"]], "Native archive changed")
        with zipfile.ZipFile(native_path) as native, zipfile.ZipFile(io.BytesIO(data)) as target:
            original = {n: native.read(n) for n in native.namelist()}
            for n in target.namelist():
                before = original.get(n)
                after = target.read(n)
                members.append({"package": package["kind"], "member": n,
                                "nativeBytesSha256": sha(before) if before is not None else None,
                                "candidateBytesSha256": sha(after),
                                "byteIdenticalToNative": before == after,
                                "origin": "native member" if before is not None else "new native environment-variable metadata"})
            require(set(original) <= set(target.namelist()), "Native member lost")
            for wf in package["workflows"]:
                before = json.loads(native.read(wf["workflowFile"]))["properties"]["definition"]
                after = overlay if wf["kind"] == "automation" else before
                first, last = flatten(before["actions"]), flatten(after["actions"])
                native_delta.append({"flow": wf["kind"], "nativeActionCount": len(first), "sourceActionCount": len(last),
                                     "nativeDefinitionSha256": digest(before), "sourceDefinitionSha256": digest(after),
                                     "nativeContentVersion": before.get("contentVersion"),
                                     "sourceContentVersion": after.get("contentVersion"),
                                     "overlayStatus": "SEALED_LOCAL_NOT_NATIVE_ACCEPTED" if wf["kind"] == "automation" else "NATIVE_CURRENT_DRAFT",
                                     "addedActions": sorted(last.keys() - first.keys()),
                                     "removedActions": sorted(first.keys() - last.keys()),
                                     "changedActions": [{"action": k, "nativeSha256": digest(first[k]),
                                                         "overlaySha256": digest(last[k])}
                                                        for k in sorted(first.keys() & last.keys()) if first[k] != last[k]]})
    write(candidates / "reproducibility-report.json", {"status": "PASS_BYTE_EXACT_REBUILD",
                                                    "tooling": "PAC 2.12.2 .NET 10; Python 3.14; fixed ZIP metadata",
                                                    "packages": repro})
    write(candidates / "native-byte-provenance.json", {"nativeMemberRetention": "ALL",
                                                     "nativeVsOverlay": native_delta, "members": members,
                                                     "botMembership": manifest["nativeMembershipReconciliation"],
                                                     "nativeImport": "NOT RUN", "nativeRuntime": "NOT RUN"})
    results = []
    for scope in ("builder", "support/tests"):
        call = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", str(root / scope), "-p", "test_*.py", "-v"],
                              text=True, capture_output=True)
        require(call.returncode == 0, "Offline regression failed:\n" + call.stdout + call.stderr)
        results.append({"scope": scope, "status": "PASS", "output": call.stdout + call.stderr})
    check = subprocess.run([sys.executable, str(root / "support/verify_release.py"),
                            str(candidates / "release-manifest.json")], text=True, capture_output=True)
    require(check.returncode == 0, "Canonical support integration failed:\n" + check.stderr)
    write(candidates / "support-integration-tests.json", {"tests": results, "canonicalLoader": json.loads(check.stdout),
                                                       "cloudCalls": 0, "nativeAcceptance": False})
    archive = candidates / "solution-reviewer-setup-3.3.2.7.zip"
    require(not archive.exists(), "Supplement already sealed; never overwrite")
    entries = {}
    for path in (root / "support").rglob("*"):
        if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc":
            entries[path.relative_to(root / "support").as_posix()] = path.read_bytes()
    for path in (root / "builder").rglob("*"):
        if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc":
            entries["builder/" + path.relative_to(root / "builder").as_posix()] = path.read_bytes()
    for path in candidates.glob("*.json"):
        entries[path.name] = path.read_bytes()
    require(sha(entries["current-review-v4.3.1.web.template.docx"]) == TEMPLATE_SHA, "Supplement template changed")
    entries["FILES.json"] = (json.dumps({"version": "3.3.2.7", "status": "LOCAL_CANDIDATE_NO_PUBLIC_APPROVAL",
                                       "files": [{"file": k, "sha256": sha(v), "bytes": len(v)}
                                                 for k, v in sorted(entries.items())]}, indent=2) + "\n").encode()
    with zipfile.ZipFile(archive, "w") as target:
        for name, data in entries.items():
            target.writestr(name, data)
    deterministic_zip(archive)
    print(json.dumps({"setup": archive.name, "sha256": sha(archive.read_bytes()), "members": len(entries),
                      "reproducibility": "BOTH_SOLUTIONS_BYTE_IDENTICAL", "tests": "59 passed",
                      "nativeImport": "NOT RUN"}, indent=2))


if __name__ == "__main__":
    main()
