# Reproducing the 3.3.2.7 import-first candidates

This builder performs **only local filesystem operations and PAC solution
pack/unpack/create-settings**. It does not select an authentication profile,
retrieve tokens, contact an environment, export/import a solution, or enable,
publish, run, or delete a component. Use Python with PyYAML and PAC 2.12.2
(.NET 10). The legacy .NET Framework PAC can fail on long Windows paths while
returning exit code zero; the builder also checks the actual error output.

## Inputs and trust boundary

All source paths are explicit arguments. Retain private sources separately from
the output and never include them in a public archive:

* Historical public `solution-reviewer-word-output-3.3.2.6.bundle.zip`.
* Private, authenticated native export directory with
  `native-archive-inventory.json`, `exact-native-source-comparison.json`,
  `before-current-native-state.json`, and the two native exports named in it.
* The sealed complete `automation-flow.candidate.json`.
* The private source-binding map from the historical release and the native
  `automation-site.json`, used solely to replay and verify the declared
  source-binding substitutions.

Pinned SHA-256 hashes:

| Input | SHA-256 |
|---|---|
| Historical public bundle | `26540297fcd6590845f4b1f32ab7a7278233a74c420c8c9843d6075e237cc849` |
| Native reviewer export | `6ffe125f8459b2ec343cf1a31a8f2e41e0cad8d72a5be46b83daa2c565d39c50` |
| Native automation export | `7eccd5c7c64ea7472de908f7e97ea7d08ba03a4bc1742a956f74993914d735b3` |
| Sealed automatic Word overlay | `acea5101fb52bf4a00af86ba51c5e14631b142b9c6177ae72b19da2c10b428b6` |
| Original generic Word template | `498ee9eb6d1fbd9df4fa719a873fa57237fdbf224fcb6c62c77c96881bac3065` |

Invoke `python build_release.py --help` for the required flags. Supply a new empty
`--out` path and a different new private `--scratch` path. The builder refuses
existing output so a handed-off ZIP cannot silently change. Windows short-path
aliases refer to the same filesystem directories, not external temporary areas.

This is not merely renaming the historical templates: their target tokens are
replaced by native String environment-variable definitions and parameter
references, numeric Word schema keys are restored, the exact authentic GPT5Chat
metadata and stable private caller inbox are restored, installation stamping is
removed, and the canonical solution release identity is static. Target values
remain empty until separately authorized post-import setup. No whole flow,
action, branch, node, input validation, audit output, or Word renderer is dropped.

The builder replays the previous declared private-binding normalization against
the native collector/helper and sealed automatic overlay, and requires full
object equality with the historical complete definitions before proceeding.
All 746 action objects are retained. The collector's entire native definition
has identical canonical JSON hash after restoring the public inbox constant.
For transformed strings, `expression_equivalence.py` independently parses WDL
and proves symbolic equality after binding substitution, including adjacent
tokens, quoted apostrophes, string interpolation, and numeric casts. This is
not native runtime execution or a claim that a connector accepts an empty field.

## Native agent membership

The authentic reviewer export itself lists two workflow RootComponents.
Its authenticated saved source membership also contains the bot, all nineteen
botcomponents, four connection references, and four dependency records. Those
dynamic-table components are serialized through `bots/`, `botcomponents/`,
parent-bot schema references and `Assets/botcomponent_workflowset.xml`.
The exact native serialization is retained. Environment-specific dynamic table
type codes and invented bot IDs are **not** inserted into the manifest. Only
standard type-380 environment-variable definitions are added as new roots.
Each new per-record environment-variable XML file is a declaration-free element
fragment, matching the authentic native source-control record shape. The builder
does not prepend an XML declaration node to these records. A dedicated regression
enforces this boundary; XML parsing and PAC packing alone do not test it.

Therefore the target import-only check must discover the actual imported IDs
and establish full bot/component/dependency membership. File presence and
offline PAC success are not substitutes for that check.

## Offline checks

From this directory:

```powershell
python expression_equivalence.py --help
```

The synthetic regression suites and author-only identity scanner are retained
in the private authoring source, not distributed in this public-support ZIP.
The unchanged private suites and their retained reports cover the public runtime
modules too; the public bundle does not claim to include those test fixtures.
The author-only identity scanner consumes a private audit pattern set but emits only counts,
hashes, and nonsecret relative filenames. Schema validation uses the local
Copilot Studio schema lookup script on all nineteen component bodies.
Environment-aware LanguageServerHost checks are intentionally not run because
this build has no cloud authorization.

PAC-generated deployment settings can include a zero audience GUID; the builder
removes that optional `CopilotAgents` prompt block instead of distributing a fake
target. The actual authenticated audience is reviewed after import, before any
publication/activation.

ZIP entries are sorted with fixed timestamps and container attributes, while
every PAC member's bytes remain unchanged. A separate rebuild must match both
ZIP hashes. Recheck against the exact Python/zlib/PAC versions if a future tool
version changes XML formatting or compression bytes.

The sealed 500-action overlay has not passed native import/runtime acceptance.
The support scripts keep setup stopped/unpublished with Disabled/no-email
control and no authorization. Native import, publication, manual smoke,
automatic exact-source acceptance, and email authorization remain separate
deliberate gates, as described in `INSTALL.md`.
