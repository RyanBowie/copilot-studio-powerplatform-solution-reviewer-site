"""Offline configuration, release fingerprints, and explicit mutation consent."""

import hashlib
import json
from pathlib import Path
import re
import shutil
from uuid import UUID


ROOT = Path(__file__).resolve().parent
APIS = ("shared_sharepointonline", "shared_onedriveforbusiness", "shared_office365users",
        "shared_microsoftcopilotstudio", "shared_office365", "shared_wordonlinebusiness")
VERSION = "3.3.2.7"
RELEASE_DESCRIPTION = "PSR import-first release 3.3.2.7"
SOURCE_ENVIRONMENT_SHA256 = "7a61e881a7b593385c548ea4bfa723c82aa985d5f0114c110996441d6db11677"
MANUAL_INBOX = "PowerPlatformSolutionReviewInbox"
MODEL = "GPT5Chat"
AUTHORIZATIONS = ("acceptedOwnerTest", "manualSmoke", "emailAuthorization", "sourceAuthorization",
                  "publication", "activationAuthorized")


def require(test, message):
    if not test:
        raise ValueError(message)


def digest(value):
    # Matches the original sealed safety-kernel JSON serialization.
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=True,
                                     separators=(", ", ": ")).encode()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def write(path, value):
    path = Path(path)
    pending = path.with_name(path.name + ".pending")
    require(not pending.exists(), "A pending ledger exists; inspect it before retrying.")
    with pending.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")
        stream.flush()
        import os
        os.fsync(stream.fileno())
    pending.replace(path)


def uuid_text(value):
    require(isinstance(value, str), "Expected a nonzero GUID string.")
    result = str(UUID(value))
    require(result != str(UUID(int=0)), "A zero GUID is not a configured target.")
    return result


def consent(config, apply=False, confirm_environment=None):
    require(apply is True and confirm_environment == config["environmentId"],
            "ALL mutations require --apply and exact --confirm-environment.")


def validate(config, manifest):
    require(set(config) == set(read(ROOT / "target.example.json")),
            "Configuration keys differ from target.example.json.")
    require(not re.search(r"__TARGET_[A-Z0-9_]+__", json.dumps(config)), "Replace every __TARGET_*__ placeholder.")
    for name in ("installationId", "tenantId", "environmentId"):
        require(uuid_text(config[name]) == config[name], name + " must be a lowercase complete GUID.")
    environment_hash = hashlib.sha256(config["environmentId"].encode()).hexdigest()
    require(manifest.get("sourceEnvironmentIdSha256") == SOURCE_ENVIRONMENT_SHA256,
            "Missing or changed protected-source environment hash.")
    require(environment_hash != SOURCE_ENVIRONMENT_SHA256, "Refusing the protected source environment.")
    patterns = {
        "dataverseUrl": r"https://[a-z0-9-]+\.crm[0-9]*\.dynamics\.com",
        "siteUrl": r"https://[a-z0-9-]+\.sharepoint\.com/(?:sites|teams)/[A-Za-z0-9_-]+",
        "ownerOneDriveSiteUrl": r"https://[a-z0-9-]+-my\.sharepoint\.com/personal/[A-Za-z0-9_-]+",
        "ownerUpn": r"[A-Za-z0-9._+%-]+@[A-Za-z0-9.-]+",
    }
    for name, pattern in patterns.items():
        require(isinstance(config[name], str) and re.fullmatch(pattern, config[name]),
                "Missing or unsupported target " + name + ".")
    for name in ("libraryName", "jobsListName", "controlListName"):
        require(isinstance(config[name], str) and re.fullmatch(r"[A-Za-z][A-Za-z0-9]{2,39}", config[name]),
                name + " must be a safe 3-40 character name.")
    require(len({config[k] for k in ("libraryName", "jobsListName", "controlListName")}) == 3,
            "Library, jobs and control names must be distinct.")
    require(config["manualInboxName"] == MANUAL_INBOX, "The canonical caller Inbox name is fixed.")
    require(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{1,120}\.docx", config["wordTemplateName"] or ""),
            "wordTemplateName must be an explicit safe DOCX filename.")
    require(set(config["connections"]) == set(APIS), "All six target connector instances are required.")
    require(all(isinstance(v, str) and re.fullmatch(r"[A-Za-z0-9_-]{5,200}", v)
                for v in config["connections"].values()), "Invalid target connection instance ID.")
    require(isinstance(config["model"], dict)
            and set(config["model"]) == {"modelNameHint", "availabilityVerifiedInTarget"}
            and config["model"]["modelNameHint"] == MODEL
            and config["model"]["availabilityVerifiedInTarget"] is True,
            "Verify target GPT5Chat availability/licensing/DLP; model substitution changes the release.")
    require(config["authenticationReviewedInTarget"] is True,
            "Review target authenticated audience and licensing before setup.")
    require(isinstance(config["azureCliPath"], str) and config["azureCliPath"].strip(), "azureCliPath is required.")
    return config


def target_identity(config):
    return {k: config[k] for k in ("installationId", "tenantId", "environmentId", "dataverseUrl", "ownerUpn")}


def target_key(config):
    return digest({k: v for k, v in config.items() if k != "azureCliPath"})


def invalidate(state):
    for name in AUTHORIZATIONS:
        state.pop(name, None)
    state["setupComplete"] = False


def ledger_for(config, path):
    if not Path(path).exists():
        return None
    state = read(path)
    require(state.get("identity") == target_identity(config), "Ledger belongs to a different installation/target/owner.")
    return state


def cli(config, key):
    value = shutil.which(config[key])
    if value:
        return value
    require(Path(config[key]).is_file(), "Required CLI is unavailable: " + config[key])
    return str(Path(config[key]).resolve())


def flatten(actions):
    result = {}
    for name, action in actions.items():
        require(name not in result, "Duplicate workflow action.")
        result[name] = action
        for nested in (action.get("actions", {}), action.get("else", {}).get("actions", {}),
                       action.get("default", {}).get("actions", {})):
            found = flatten(nested)
            require(not set(result).intersection(found), "Duplicate nested workflow action.")
            result.update(found)
        for case in action.get("cases", {}).values():
            found = flatten(case.get("actions", {}))
            require(not set(result).intersection(found), "Duplicate case workflow action.")
            result.update(found)
    return result


def kernel_of(definition, selector):
    actions = flatten(definition["actions"])
    result = {
        "preparationActions": {name: actions[name] for name in selector["preparation"]},
        "firstEligibility": actions["FirstComponentIfPrepared"]["expression"],
        "repairEligibility": actions["RepairComponentIfNeeded"]["expression"],
        "passIdInput": actions["ComponentPassId"]["inputs"], "phases": {},
    }
    for phase, record in selector["phases"].items():
        actual = actions[record["recordAction"]]["inputs"]["value"]
        result["phases"][phase] = {
            "nativeActions": {name: actions[name] for name in record["actions"]},
            "accountingProjection": {key: actual[key] for key in record["accountingKeys"]},
        }
    for name, output in (("secondAttemptReasonAction", "secondAttemptReasonAction"),):
        if name in selector:
            result[output] = actions[selector[name]]
    if "messageActions" in selector:
        result["messageActions"] = {name: actions[name] for name in selector["messageActions"]}
    return result
